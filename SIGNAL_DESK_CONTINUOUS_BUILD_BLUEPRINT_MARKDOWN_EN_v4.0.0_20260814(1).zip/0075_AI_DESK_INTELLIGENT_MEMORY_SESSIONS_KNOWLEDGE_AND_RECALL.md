# 50 — Intelligent Memory, Sessions, Knowledge, and Recall

> **Source basis:** `blueprints/ai-trading-desk/source-material/50_INTELLIGENT_MEMORY_SESSIONS_KNOWLEDGE_AND_RECALL.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Goal

The AI Trading Desk should feel like a persistent assistant that understands prior work while preserving auditability and user control.

## Memory layers

### 1. Conversation Session Memory
Stores:
- user messages;
- agent replies;
- tool calls;
- tool results;
- timestamps;
- session metadata.

Use per-user `session_id`.

### 2. User Preference Memory
Examples:
- preferred language;
- preferred display mode;
- preferred analysis depth;
- favorite symbols;
- preferred default model/provider.

Do NOT let memory silently change:
- active Risk Policy;
- hard position limits;
- strategy promotion;
- live-execution state.

### 3. Trading Decision Memory
Searchable summaries linked to immutable decision/audit IDs:
- why BTC was rejected;
- what strategy was used;
- what Risk Gate failed;
- what Red Team objected to;
- outcome if paper traded.

Memory stores references and summaries, not rewritten historical truth.

### 4. Research Memory
Stores:
- source IDs;
- timestamp;
- research query;
- validated summary;
- entity/symbol tags;
- expiry/freshness.

News memory must age and cannot be treated as current indefinitely.

### 5. Strategy Learning Memory
Stores validated observations:
- strategy conditions;
- failure regimes;
- paper/backtest evidence references.

No automatic strategy promotion from memory.

### 6. Knowledge Base
Searchable:
- product methodology;
- strategy documents;
- risk policy;
- known limitations;
- owner documentation;
- research papers;
- selected external documentation.

## Storage profile for phone

Default:
- SQLite for AgentOS sessions/memories/traces.
- Existing SIGNAL DESK SQLite/domain DB remains authoritative for trading state.
- Separate DB file for AI runtime preferred to reduce coupling.

Example layout:

```text
~/.signaldesk/
├── data/
│   ├── signaldesk.db
│   └── agentos.db
├── knowledge/
├── exports/
├── logs/
└── secrets/
```

## Retrieval

The Supervisor can use:
- session history;
- user memory;
- decision search;
- journal search;
- knowledge search.

Every historical trading fact returned to chat should include decision/journal/audit reference when available.

## Privacy

Memory UI must allow:
- view;
- search;
- edit user preference memories;
- delete user preference memories;
- export;
- clear a chat session.

Trading/audit records are governed separately and should not be deleted through generic AI-memory controls.

## V3 memory independence

Memory belongs to SIGNAL DESK / Agent Runtime, not to the external model vendor.

Changing or deleting Kimi/OpenAI/Ollama must not delete:
- sessions;
- preferences;
- decision memory;
- research memory;
- knowledge;
- calibration/evaluation history.

Provider/model metadata is stored only as provenance for each historical agent run.
