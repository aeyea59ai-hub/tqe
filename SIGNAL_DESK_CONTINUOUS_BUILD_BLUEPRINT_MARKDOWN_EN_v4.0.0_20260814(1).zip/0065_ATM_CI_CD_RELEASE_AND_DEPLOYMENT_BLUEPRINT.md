# CI/CD, Release, and Deployment Blueprint

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/19_CI_CD_RELEASE_AND_DEPLOYMENT_BLUEPRINT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Gate order

| Gate | Content | Success condition |
|---|---|---|
| G0 | source identity/clean tree | exact expected tree |
| G1 | docs/contracts/traceability | no unresolved P0 ambiguity |
| G2 | backend unit/property/schema | all required pass |
| G3 | DB/API/integration/migrations | clean + upgrade path pass |
| G4 | frontend type/unit/i18n/a11y | pass |
| G5 | backtest/replay determinism | same hashes/results |
| G6 | security/forbidden surfaces | zero P0 |
| G7 | semantic verifier/mutations | 100% P0 killed |
| G8 | package/re-extract | byte/hash/layout pass |
| G9 | load/soak/fault injection | targets met or blocked honestly |
| G10 | owner review | explicit approval event |

## 2. Branch/release discipline

- ATM work on dedicated branch.
- no unrelated redesign.
- each phase commit independently reviewable.
- version/hash updates atomic.
- release tag only after G0–G10 on same commit.

## 3. Runtime profiles

- `demo`.
- `replay`.
- `live_public`.
- `test`.
- `release_soak`.

There is no `live_trade` profile.

## 4. Deployment

### Local-first default

- localhost binding.
- SQLite authoritative local state.
- single scheduler leader.
- backups and dry-run restore.

### Cloud future

Do not move the current architecture unchanged onto an ephemeral filesystem. Before a cloud deployment:

- external persistent DB/storage.
- distributed scheduler lock.
- session/rate-limit state review.
- secret management.
- backup/restore redesign.

## 5. Release claim policy

Permitted claims:

- `BLUEPRINT_READY_FOR_IMPLEMENTATION`.
- `IMPLEMENTED_UNVERIFIED`.
- `INTEGRATED_QA_PASS` with evidence.
- `RELEASE_CANDIDATE`.
- `OWNER_APPROVED_RELEASE`.

Forbidden claim: `COMPLETE` based on a ZIP checksum or documentation-only verification.
