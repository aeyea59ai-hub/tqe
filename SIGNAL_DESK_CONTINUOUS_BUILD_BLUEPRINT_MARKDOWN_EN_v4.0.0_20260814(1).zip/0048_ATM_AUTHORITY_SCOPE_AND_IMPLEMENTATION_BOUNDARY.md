# ATM Authority, Scope, and Implementation Boundary

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/02_AUTHORITY_SCOPE_AND_NO_CODE_BOUNDARY.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Authority order

Resolve material conflicts in this order:

1. The owner's latest explicit instruction.
2. Permanent Signal Desk boundaries: local-first, paper-only, no live trading, deterministic numeric truth.
3. Fresh canonical source behavior, configuration, migrations, tests and reproducible evidence.
4. The original 44-school ATM study as the research-logic source.
5. Earlier packages and summaries as supporting evidence.
6. Developer assumptions, clearly labeled and versioned.

## 2. Implementation scope

- integrate ATM inside the existing Signal Desk Strategy Registry;
- preserve historical S01 identity and add a new immutable experimental version;
- implement deterministic ATM features, rule evaluation and research outputs;
- close unknown rules through explicit configuration or disabled feature flags;
- implement strict data contracts and cross-field validators;
- implement API, database, migrations, state machines, scanner integration, UI, security and observability;
- convert all test specifications into executable tests and run them;
- implement the Semantic Verifier and mutation catalog;
- generate traceability, evidence, release and rollback artifacts.

## 3. Implementation boundaries

- ATM remains Research-only until its promotion evidence exists.
- Existing strategies and pages remain available.
- Historical S01 records remain immutable.
- Strategy configuration cannot override the active Risk Policy.
- Unresolved feature flags remain disabled.
- Deterministic code owns all numeric outputs and lifecycle state.
- Live exchange execution and private trading credentials remain outside the product.

## 4. Contradiction handling

Every material conflict between the study, blueprint and current code produces a contradiction record, governing resolution, version impact, regression test and migration impact statement where applicable. Resolutions are visible in traceability and release evidence.
