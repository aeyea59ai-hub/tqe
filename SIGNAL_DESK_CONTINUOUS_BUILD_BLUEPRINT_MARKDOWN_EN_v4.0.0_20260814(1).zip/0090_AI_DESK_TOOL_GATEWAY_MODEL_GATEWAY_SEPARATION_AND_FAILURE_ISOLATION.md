# 66 — Tool Gateway vs Model Gateway Separation and Failure Isolation

> **Source basis:** `blueprints/ai-trading-desk/source-material/66_TOOL_GATEWAY_MODEL_GATEWAY_SEPARATION_AND_FAILURE_ISOLATION.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Required separation

There are two different gateways.

### AI Provider Gateway
Responsible for:
- LLM/model communication;
- provider selection;
- capabilities;
- streaming;
- provider health;
- cost/latency metadata.

### Tool Gateway
Responsible for:
- deterministic market tools;
- strategy tools;
- risk tools;
- backtest tools;
- journal tools;
- paper tools;
- permission enforcement;
- typed schemas;
- human confirmation.

These must not be merged.

## Architecture

```text
                    AGENT RUNTIME
                    /           \
                   /             \
        MODEL POLICY ROUTER      TOOL REGISTRY
                │                    │
        AI PROVIDER GATEWAY       TOOL GATEWAY
                │                    │
       LLM Providers             SIGNAL DESK
                                 deterministic
                                   engines
```

## Failure isolation

If every AI provider is unavailable:

The following must still work:
- Dashboard
- Market Data
- Scanner
- Charts
- Indicators
- Strategies
- Backtests
- Risk
- Paper Trading
- Journal
- Analytics

Only AI-assisted workflows become unavailable.

## Tool result authority

Agents may interpret tool results.

They may not alter authoritative numeric tool output.

## Tool security

Never expose provider-secret management as normal agent tools.

Never expose live-trading tools in base release.
