# State Machines and Lifecycles

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/12_STATE_MACHINES_AND_LIFECYCLES.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Strategy lifecycle

```text
DRAFT
→ NUMERICALLY_DEFINED
→ IMPLEMENTED_UNVERIFIED
→ UNIT_TESTED
→ BACKTESTED
→ OOS_VALIDATED
→ WALK_FORWARD_VALIDATED
→ PAPER_ELIGIBLE
→ PAPER_VALIDATED
→ ENABLED
```

Any operational state may transition to `SUSPENDED`, then `RETIRED`. No jumps and no automatic promotion.

ATM v2 begins at `NUMERICALLY_DEFINED` after blueprint approval. It cannot become `IMPLEMENTED_UNVERIFIED` until implementation code exists.

## 2. Actionability axis

Actionability is independent from lifecycle:

- `RESEARCH_ONLY`
- `PAPER_ACTIONABLE`
- `PUBLISHABLE`

ATM v2 begins `RESEARCH_ONLY`. A mature lifecycle alone does not open actionability; explicit owner approval is required.

## 3. Research Run

`QUEUED → VALIDATING_INPUTS → RUNNING → COMPLETED | FAILED | CANCELLED`

- Dataset or hash failure occurs before RUNNING.
- Partial results remain audit-visible after FAILED.
- A retry creates a new run.

## 4. Research Evaluation

`CREATED → DATA_UNAVAILABLE | INSUFFICIENT_HISTORY | NO_SETUP | WAIT_EXPANSION | RESEARCH_SETUP | RESEARCH_REJECTED → EXPIRED`

- No transition to Candidate or Published.
- `RESEARCH_SETUP` may be reviewed in Replay or Backtest, never converted directly to a Paper Order.

## 5. Promotion Request

`DRAFT → EVIDENCE_COLLECTING → GATES_PASSED → OWNER_REVIEW → APPROVED | REJECTED | EXPIRED`

If any gate becomes FAIL after approval but before release, stop promotion and return to `EVIDENCE_COLLECTING`.

## 6. Semantic Verification

`QUEUED → CONTRACT_CHECK → SOURCE_CHECK → CROSS_FIELD_CHECK → MUTATION_CHECK → PASS | FAIL`

- Any surviving P0 mutation = FAIL.
- Missing application source = `NOT_RUN`, never PASS.

## 7. Release claim

`BLUEPRINT_READY → IMPLEMENTATION_IN_PROGRESS → INTEGRATED_QA → RELEASE_CANDIDATE → OWNER_APPROVED_RELEASE`

`COMPLETE` is not a recognized system state. The permitted final phrase is `OWNER_APPROVED_RELEASE` with version, hash, and evidence.
