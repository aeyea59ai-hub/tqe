# Decision Closure and Feature Flags

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/06_DECISION_CLOSURE_AND_FEATURE_FLAGS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Decision-closure register

| ID | Issue | Governing decision | Status |
|---|---|---|---|
| DC-001 | Standalone ATM app or strategy | Strategy inside Signal Desk | CLOSED |
| DC-002 | New ID or S01 | Preserve S01 and add a new version | CLOSED |
| DC-003 | EMA50 or EMA200 regime | EMA200 location; slope as defined in Rulebook | CLOSED |
| DC-004 | ATR method | Wilder RMA 14 | CLOSED |
| DC-005 | Swing/CHoCH | confirmed pivot k=2 plus close break | CLOSED |
| DC-006 | Target volatility | no invented value; feature OFF | DISABLED |
| DC-007 | Limit entry | limit OFF; next 15m open research fill | CLOSED/DISABLED |
| DC-008 | Fibonacci leg/EMA20 relation | latest confirmed impulse; EMA20 inside 38.2-61.8 zone | CLOSED |
| DC-009 | Trigger | directional candle plus previous high/low close break | CLOSED |
| DC-010 | Stop | swing +/-0.6 ATR, floor 1.2, cap 3.5 | CLOSED |
| DC-011 | TP1/TP2 | trailing-only research; no actionability | CLOSED |
| DC-012 | Partial 40% at 2R | OFF until a separately versioned test | DISABLED |
| DC-013 | Time-stop ambiguity | deterministic exit at next 15m open | CLOSED |
| DC-014 | Funding-exit ambiguity | next 15m open after paid funding >0.3R | CLOSED |
| DC-015 | Macro-event source | feature OFF | DISABLED |
| DC-016 | OI gate | evidence only | DISABLED_AS_GATE |
| DC-017 | Top-trader ratios | OFF; no private API key | DISABLED |
| DC-018 | Historical derivatives | tiered dataset plan | CLOSED |
| DC-019 | Correlation | global conservative bucket v1 | CLOSED |
| DC-020 | Minimum notional | reject; never increase risk | CLOSED |
| DC-021 | Timestamp in content hash | exclude retrieval and observation time | CLOSED |
| DC-022 | `COMPLETE` claim | requires actual app and same-tree gates | CLOSED |

## 2. Default feature-flag set

| Flag | Default | Lock type | Rationale |
|---|---:|---|---|
| `ATM_REGISTERED` | true | structural | visible in Registry |
| `ATM_EVALUATION_ENABLED` | false | owner/version | no run before implementation |
| `ATM_SHADOW_MODE` | false | owner/version | enable only after tests |
| `ATM_ACTIONABLE_DECISIONS` | false | hard promotion guard | prevents candidate/published states |
| `ATM_PAPER_ORDER_FROM_SIGNAL` | false | hard promotion guard | prevents Paper Ticket |
| `ATM_VOLATILITY_TARGETING` | false | versioned | target not established |
| `ATM_OI_HARD_GATE` | false | versioned | long historical dataset unavailable |
| `ATM_TOP_TRADER_RATIO_GATE` | false | security/data | API key and retention constraints |
| `ATM_LIMIT_ENTRY` | false | execution model | ambiguity and slippage |
| `ATM_PARTIAL_EXIT_2R` | false | variant | requires independent backtest |
| `ATM_MACRO_BLACKOUT` | false | provider | no governing provider |
| `ATM_DYNAMIC_CORRELATION` | false | portfolio model | conservative global model |
| `ATM_DERIVATIVES_PROMOTION_MODE` | false | dataset gate | requires eligible manifest |
| `ATM_AI_EXPLANATION` | false | optional | only after fact-bundle validation |

## 3. Feature-flag rules

- Flags are part of the Strategy Version hash.
- Do not change flags during an active evaluation run.
- Each change creates a new Strategy Version or append-only FeatureFlagSet.
- Unknown flag = validation failure.
- Missing flag = fail closed, never default true.
- UI has no control that directly raises actionability.
- `ATM_ACTIONABLE_DECISIONS` and `ATM_PAPER_ORDER_FROM_SIGNAL` can be opened only by a valid Promotion Event, never by a manual toggle.

## 4. Promotion preconditions

Before any transition from Research Only:

1. ATM implementation exists and has been reviewed.
2. Every required executable test passes.
3. P0 semantic mutations are killed 100%.
4. Price-core backtest, OOS, and walk-forward validation pass.
5. Paper Engine supports the exit model deterministically.
6. Risk and Red Team invariants pass.
7. At least 60 closed paper signals after Paper Eligibility.
8. Signed and timestamped owner approval event.
