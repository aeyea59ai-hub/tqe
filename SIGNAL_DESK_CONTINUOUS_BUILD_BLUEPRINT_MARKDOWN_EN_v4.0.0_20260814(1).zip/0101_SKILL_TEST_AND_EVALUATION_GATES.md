# Skill validation, testing, and evaluation gates

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/08_SKILL_TEST_AND_EVALUATION_GATES.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Gate S0 — Parse/schema
- frontmatter/schema valid;
- unique slug;
- allowed classification;
- valid agent/tool references.

## Gate S1 — Policy
- no conflict with determinism policy;
- no live-trading enablement;
- no secret access;
- no Risk Gate override;
- no unsupported write permission.

## Gate S2 — Contract
- required inputs defined;
- outputs typed;
- failures defined;
- missing data behavior defined.

## Gate S3 — Deterministic/tool tests
For ENGINE/HYBRID:
- valid fixture;
- missing input;
- stale input;
- NaN/Infinity;
- unit/timeframe mismatch;
- repeatability;
- tool schema.

## Gate S4 — AI/adversarial
For AI:
- unsupported number;
- unsupported citation;
- prompt injection;
- stale evidence;
- risk override request;
- contradictory evidence;
- abstention behavior.

## Gate S5 — Routing
- smallest sufficient routing;
- no dependency cycle;
- no irrelevant general skill injected.

## Gate S6 — Regression
- core journeys unchanged unless explicitly intended.

## Publish rule

Mandatory gates must be PASS on the exact content hash.
`SKIPPED/BLOCKED` is not PASS.
