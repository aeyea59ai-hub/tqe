# 54 — AI Trading Desk UI Routes and Components

> **Source basis:** `blueprints/ai-trading-desk/source-material/54_AI_TRADING_DESK_UI_ROUTES_AND_COMPONENTS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Routes

Add to the existing SIGNAL DESK navigation:

```text
/ai-desk
/ai-desk/chat
/ai-desk/team
/ai-desk/research
/ai-desk/memory
/ai-desk/tools
/ai-desk/providers
/ai-desk/traces
/ai-desk/settings
```

## Main AI Desk

Layout:

```text
┌─────────────────────────────────────────────┐
│ AI Trading Desk | Provider | Model | Status │
├───────────────┬─────────────────────────────┤
│ Sessions      │ Chat / Stream               │
│ Saved queries │                             │
│ Recent symbols│ tool calls + agent progress │
│ Memories      │ evidence cards              │
│               │ confirmation cards          │
├───────────────┴─────────────────────────────┤
│ Active Agents / Tool Activity / Risk Status │
└─────────────────────────────────────────────┘
```

## Chat features

- streaming responses;
- markdown;
- Arabic/English;
- code/JSON collapse;
- cited source chips;
- tool-call timeline;
- agent handoff status;
- stop/cancel run;
- retry;
- branch conversation;
- copy answer;
- save research;
- pin decision;
- open symbol from answer;
- open decision from answer.

## Paper-action confirmation card

When agent requests `create_paper_signal()`:

UI displays:
- decision ID;
- symbol;
- side;
- entry;
- stop;
- targets;
- R;
- risk;
- size;
- risk verdict;
- source freshness.

Buttons:
- Confirm Paper Signal
- Cancel

No “Live Trade” button exists.

## Provider selector

Top bar:
- provider
- model
- local/cloud badge
- tool-support badge
- latency
- health

Provider selection persists locally by user preference, but secret remains backend-side.

## Memory page

Tabs:
- Conversations
- User Preferences
- Trading Decision Memory
- Research Memory
- Knowledge

Historical trading/audit records cannot be deleted here.

## Tools page

Show:
- tool name
- risk class
- description
- enabled agents
- last call
- latency
- status
- requires confirmation

## Traces page

Show safe structured traces:
- run
- agent
- tool
- duration
- status
- token/cost metadata where available
- sanitized input/output

Never expose hidden reasoning or secrets.

## V3 UI additions

AI Desk Settings must include:
- Provider Gateway
- Model Policies
- Agent-to-Policy bindings
- Capability matrix
- Failover order
- Privacy class/routing
- Context inspector (sanitized)
- Memory retrieval inspector
- Evaluation/calibration dashboard

The Context Inspector must not display raw secrets or hidden reasoning.
