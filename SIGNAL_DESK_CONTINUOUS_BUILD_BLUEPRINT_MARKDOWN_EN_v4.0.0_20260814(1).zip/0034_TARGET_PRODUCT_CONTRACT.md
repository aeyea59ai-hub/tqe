# 30 - Target Product Contract

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/30_TARGET_PRODUCT_CONTRACT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

This file intentionally contains no current-project status narrative. The target is one coherent Signal Desk application with the capabilities defined in this package, the Quiet Grid Terminal design system, the simplified nine-item primary navigation, deterministic financial authority, paper-only execution and an optional provider-independent AI Desk.

The developer must not preserve an old layout merely because a donor implementation used it. They must preserve the functional and safety contracts while building the target UI, routes, motion and module ownership specified here.
