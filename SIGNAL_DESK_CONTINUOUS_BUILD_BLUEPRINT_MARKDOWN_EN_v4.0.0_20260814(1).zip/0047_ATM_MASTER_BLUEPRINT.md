# Signal Desk + ATM Experimental Integration - Master Blueprint

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/01_MASTER_BLUEPRINT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Executive decision

Integrate ATM as a **non-actionable experimental strategy** inside the existing Signal Desk architecture. Do not create a standalone ATM application, do not replace `S02/S03/S07/S14`, and do not redesign the Scanner, Risk Engine, or Paper Engine around ATM as the sole strategy.

Target architecture after implementation:

```text
Signal Desk
├── Market Universe / Scanner / Data / Risk / Red Team / Paper / Replay / Analytics
├── Strategy Registry
│   ├── S01 ATM v1.0.0               [legacy version preserved]
│   ├── S01 ATM v2.0.0-experimental  [new, disabled, research-only]
│   ├── S02 EMA Pullback
│   ├── S03 Breakout-Retest
│   ├── S07 Range Rejection
│   └── S14 VWAP Session Pullback
└── ATM Research Lane
    ├── Shadow evaluations
    ├── Dataset coverage
    ├── Price-core backtests
    ├── Derivatives-augmented backtests
    ├── Promotion gates
    └── Semantic verification evidence
```

## 2. Current implementation truth versus final intent

| Area | Current truth | Governing target |
|---|---|---|
| Strategy ID | `S01` already exists | Preserve `S01`; do not create a competing ID |
| ATM version | `1.0.0` does not fully match the source study | Add `2.0.0-experimental` without rewriting history |
| Actionability | Current S01 is treated as `PAPER_ELIGIBLE` | New ATM version is `RESEARCH_ONLY`, `enabled=false` |
| Regime | Position/slope around EMA50 | Close versus EMA200 with explicitly defined slope |
| Entry | Latest price with fixed geometry | Deterministic pullback/trigger research entry, never publication |
| Exit | Fixed TP1/TP2 | Research-only trailing model; no paper actionability until supported |
| Tests | Existing application tests exist | Add executable ATM tests on the same final tree |
| Verifier | Existing project gates only | Add Semantic Verifier and mutation tests |

## 3. Non-negotiable principles

1. **Deterministic core is authoritative:** deterministic code owns prices, indicators, geometry, and risk; an LLM does not.
2. **Fail closed:** missing or contradictory mandatory data returns `DATA_UNAVAILABLE/REJECTED`; never substitute a guess.
3. **Paper-only:** no real orders, signed trading requests, or trading-key fields.
4. **Immutable versioning:** versions, decisions, snapshots, datasets, backtests, and evidence are identified by version/hash and never silently replaced.
5. **No automatic promotion:** ATM cannot move from Research to Paper or Published without a recorded owner approval event.
6. **Same-tree evidence:** every success claim is tied to the exact tested commit and config/dataset hashes.
7. **No ZIP-only completion:** package integrity is not application correctness.

## 4. Integration layers

| Layer | ATM responsibility | ATM must not do |
|---|---|---|
| Universe | Consume the shared eligible universe | Create a private universe or hide instruments |
| Snapshot | Consume frozen snapshots | Fetch provider data from inside the strategy |
| Feature Engine | Use governing EMA/ATR/swing features | Define conflicting local indicators |
| Regime | Add ATM conditions to the shared regime context | Override the Regime or Risk engines |
| Strategy | Produce a Research Setup | Submit an order or mutate the portfolio |
| Risk | Submit geometry for shared risk observation | Calculate independent leverage or bypass a veto |
| Red Team | Receive deterministic objections | Weaken a veto because the result is desirable |
| Decision | Create a Research Evaluation | Create an actionable card before promotion |
| Backtest | Evaluate explicitly labeled variants | Mix datasets or hide coverage gaps |
| AI | Explain frozen evidence only | Invent values or promote state |

## 5. Versions and initial states

- **Blueprint package:** `1.0.0`
- **Target strategy version:** `S01 2.0.0-experimental`
- **Initial lifecycle:** `NUMERICALLY_DEFINED`
- **Initial actionability:** `RESEARCH_ONLY`
- **Initial runtime flag:** `EVALUATION_DISABLED`
- **Application release status:** advances through implementation and fresh test evidence.

## 6. Required implementation outputs

- Versioned ATM contract in the Strategy Registry.
- Fail-closed feature flags.
- Strict schemas plus cross-field validation.
- A research-evaluation lane with no connection to Paper Order creation.
- Historical dataset manifests and coverage reports.
- Executable tests derived from document `17`.
- Semantic Verifier that kills the mutations in document `18`.
- UI that visibly labels ATM as Experimental and Research Only.
- Same-tree evidence package.

## 7. Definition of first-phase success

Initial success is not profit. It means:

- implementation matches the specification;
- ATM cannot leak into paper trading or publication prematurely;
- outputs are deterministic;
- data and evidence are valid;
- the system can honestly demonstrate that ATM has no edge if results are negative.
