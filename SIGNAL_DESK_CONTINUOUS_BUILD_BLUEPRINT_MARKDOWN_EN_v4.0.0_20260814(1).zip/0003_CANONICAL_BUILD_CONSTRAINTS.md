# Canonical Build Constraints

## Product identity

- Product: **Signal Desk — Crypto Futures Intelligence & Paper Trading**.
- Product UI: Arabic and English with full RTL/LTR support.
- Developer-facing code, tests, identifiers and technical documentation: English.
- Operation: private, local-first, single-owner, research and paper simulation.

## Canonical architecture

- Frontend: React 19, Vite, strict TypeScript, React Router and bundled local assets.
- Backend: Python FastAPI, Pydantic v2, SQLAlchemy 2, Alembic, SQLite, APScheduler and httpx.
- Interfaces: typed REST/OpenAPI and application-domain WebSocket events.
- Domain logic: deterministic, testable and independent from UI, database and provider SDKs.

## Permanent safety limits

- Paper trading only.
- No live exchange order route, signed Binance request, private trading credential, withdrawal, transfer or custody feature.
- Public/keyless market data for the core product.
- Closed candles for deterministic decisions.
- Missing, stale, malformed or contradictory required data produces an explicit non-actionable result.
- AI remains optional, read-only, evidence-bound and unable to override risk or mutate signed state.

## Architecture preservation

FastAPI remains the backend authority. Firebase, Firestore, Supabase, a Node backend replacement, a native Android rewrite, a second strategy engine, a second journal and a parallel replacement application are outside this build contract.
