# 24 - Error Handling and Edge Cases

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/24_ERROR_HANDLING_AND_EDGE_CASES.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

| ID | Code | Trigger | HTTP | User behavior |
| --- | --- | --- | --- | --- |
| ERR001 | AUTH_REQUIRED | No valid local session | 401 | Show login; preserve requested route |
| ERR002 | CSRF_REQUIRED | Write request lacks valid CSRF | 403 | Show safe retry message |
| ERR003 | DATA_STALE | Critical snapshot older than policy | 409 | Block publish/paper; show stale banner |
| ERR004 | DATA_MIXED | Critical fields not coherent in time | 409 | Block decision; show mixed-data detail |
| ERR005 | DATA_UNAVAILABLE | Required market data missing | 503 | Abstain; no candidate |
| ERR006 | PROVIDER_RATE_LIMITED | Provider returned rate limit | 503 | Backoff/circuit state; visible degraded status |
| ERR007 | STRATEGY_INELIGIBLE | Strategy disabled/research-only | 409 | No publish/paper |
| ERR008 | RISK_VETO | Hard risk gate failed | 409 | Display veto reason; no override |
| ERR009 | INVALID_GEOMETRY | Entry/stop/targets invalid | 422 | Reject plan |
| ERR010 | LOW_EFFECTIVE_R | Effective blended R below 2.0 | 409 | Reject plan |
| ERR011 | LIQUIDATION_UNSAFE | Modeled liquidation safety below policy | 409 | Reject plan |
| ERR012 | DAILY_LOCK | Daily realized loss lock active | 409 | Block new paper approval |
| ERR013 | WEEKLY_LOCK | Weekly realized loss lock active | 409 | Block new paper approval |
| ERR014 | CONFIRMATION_REQUIRED | Paper write lacks owner confirmation | 428 | Open confirmation UI |
| ERR015 | HASH_MISMATCH | Decision/config/skill integrity mismatch | 409 | Block use and raise audit event |
| ERR016 | JOURNAL_INTEGRITY_FAILURE | Hash chain fails verification | 500 | Switch to read-only safety mode |
| ERR017 | MODEL_UNAVAILABLE | No compatible healthy model | 503 | AI unavailable only; deterministic app continues |
| ERR018 | LOCAL_PROVIDER_UNAVAILABLE | LOCAL_ONLY task has no local model | 503 | Do not cloud-fallback |
| ERR019 | SKILL_POLICY_CONFLICT | Skill draft requests forbidden permission/policy | 409 | Block publish |
| ERR020 | BACKUP_INTEGRITY_FAILURE | Backup hash/schema invalid | 422 | Abort restore before switching data |

## Required edge cases
Null/non-finite values; missing candles; future bars; stale/mixed timestamps; 429/timeout/provider outage; invalid symbol; delisting; duplicate scan; duplicate paper confirmation; same-candle TP/SL; restart between fill and journal; locked DB; corrupt UI preferences; corrupt backup; AI provider removal while referenced; skill publish conflict; WebSocket gap; offline restart; low disk; thermal/battery heavy-job pause.
