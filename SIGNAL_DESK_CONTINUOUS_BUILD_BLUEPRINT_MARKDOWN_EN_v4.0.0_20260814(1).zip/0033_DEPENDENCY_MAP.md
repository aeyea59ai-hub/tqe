# 29 - Dependency Map

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/29_DEPENDENCY_MAP.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

```mermaid
flowchart LR
  UI["React Web/PWA"] --> API["FastAPI REST + WebSocket"]
  API --> Domain["Deterministic Domain Services"]
  Domain --> DB["SQLite + Alembic"]
  Domain --> Market["Public Market Adapters"]
  Domain --> Scheduler["Scheduler / Jobs"]
  UI --> AgentUI["AI Desk / AG-UI"]
  AgentUI --> AgentRuntime["Agent Runtime"]
  AgentRuntime --> ToolGW["Tool Gateway"]
  ToolGW --> Domain
  AgentRuntime --> ModelRouter["Model Policy Router"]
  ModelRouter --> ProviderGW["AI Provider Gateway"]
  ProviderGW --> Models["Local / Cloud Models"]
```

## Mandatory dependency direction
UI -> API client -> backend application service -> deterministic domain -> repository/provider.
AI Agent -> Tool Gateway -> deterministic domain.
AI Agent -> Model Router -> Provider Gateway -> model.
Provider Gateway must never become a shortcut into domain state.
Skills may guide agents but cannot expand Tool Gateway permissions.
