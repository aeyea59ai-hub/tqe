# 11 - Frontend Component Catalog

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/11_FRONTEND_COMPONENT_CATALOG.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

| Component | Purpose | Variants |
| --- | --- | --- |
| AppRail | 56px primary navigation rail | desktop; compact mobile bottom-nav mapping |
| ContextBar | Global symbol, runtime mode, freshness, language, command entry | desktop sticky; mobile condensed |
| CommandPalette | Search symbol/page/action | default; read-only action; confirmation-forwarding |
| DataStrip | Compact label/value/status row | normal; stale; degraded; unavailable |
| DenseTable | Scanner/decision/order/journal/strategy tables | sortable; selectable; virtualized; mobile row |
| InspectorDrawer | Contextual details without route loss | right drawer; mobile bottom sheet; full page fallback |
| ChartCanvas | Candles, volume, deterministic overlays, decision geometry | market; replay; backtest |
| StatusMark | Text+dot semantic status | healthy; degraded; locked; warning; error; research |
| RiskVerdict | Risk pass/veto with reasons | pass; veto; blocked |
| EvidenceBar | 8-factor evidence score without decorative gauge | raw; degraded cap; missing factor |
| DecisionGeometry | Entry/stop/invalidation/targets/R/costs block | long; short; blocked |
| Timeline | Decision/paper/journal lifecycle | vertical; horizontal desktop |
| PaperTicket | Preview/confirm paper action | preview; confirmation; blocked; expired |
| AgentTrace | Show run stages/tools/skills/provider/evidence | compact; expanded |
| ProviderRow | Provider status/model/policy controls | healthy; degraded; offline; disabled |
| SkillRow | Skill status/version/agent/activation/tests | enabled; disabled; draft; protected |
| MetricCell | Numeric analytics cell with denominator/quality | normal; low-sample; unavailable |
| EmptyState | Honest no-data state | no-data; filtered-empty; offline; unavailable |
| ErrorState | Recoverable/blocking error rendering | inline; panel; full-page |
