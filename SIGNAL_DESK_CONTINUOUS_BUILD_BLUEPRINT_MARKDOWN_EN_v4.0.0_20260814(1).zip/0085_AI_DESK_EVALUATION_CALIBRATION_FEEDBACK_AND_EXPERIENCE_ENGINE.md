# 61 — Evaluation, Calibration, Feedback, and Experience Engine

> **Source basis:** `blueprints/ai-trading-desk/source-material/61_EVALUATION_CALIBRATION_FEEDBACK_AND_EXPERIENCE_ENGINE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Goal

The platform should learn from outcomes without allowing an LLM to rewrite deterministic rules or historical truth.

## Paper outcome feedback record

After a paper position closes, create an evaluation record:

```text
decision_id
symbol
side
strategy_id/version
market_regime
original_evidence
original_agent_reports
original_agent_confidences
original_risk_state
entry
stop
targets
expected_scenario
actual_outcome
realized_R
fees
funding
slippage
MAE
MFE
exit_reason
which_assumptions_failed
which_evidence_helped
evaluation_timestamp
```

## Strategy calibration

Compute deterministic statistics by:
- strategy;
- regime;
- symbol;
- side;
- timeframe;
- funding bucket;
- volatility bucket;
- liquidity bucket;
- sample size.

Example presentation:

```text
S03 — historical/paper sample
Trend regime:
  n = ...
  win rate = ...
  expectancy = ...
Range regime:
  n = ...
  win rate = ...
  expectancy = ...
```

Never convert past sample performance into a guarantee of future profitability.

## Agent calibration

Evaluate each agent using measurable evidence.

### Market Analyst
- confidence calibration;
- unsupported claim rate;
- useful market-context rate;
- contradiction rate.

### Research Agent
- source relevance;
- stale-source rate;
- primary-source rate;
- unsupported-claim rate.

### Strategy Analyst
- strategy-match accuracy;
- backtest-context quality;
- research-only boundary compliance.

### Evidence Agent
- unsupported-number detection;
- missing-evidence detection;
- contradiction detection.

### Red Team
- useful objection rate;
- false-veto / unnecessary objection rate;
- missed-critical-risk rate.

### Supervisor
- tool-plan efficiency;
- unnecessary-tool-call rate;
- failed dependency handling;
- correct escalation/manual-review behavior.

## Evaluation Engine

The evaluation system must include:
- offline deterministic evaluation sets;
- regression prompts;
- adversarial prompts;
- tool-use scenarios;
- memory-recall scenarios;
- provider-switching scenarios;
- exact expected invariants.

## Feedback loop

```text
Paper Outcome
  ↓
Deterministic Analytics
  ↓
Strategy Calibration
  ↓
Agent Evaluation
  ↓
Workflow Recommendation
  ↓
Human Review
  ↓
Versioned configuration change
```

No direct loop:

```text
LLM observation -> silently modify risk/strategy
```

## Allowed learning effects

Evaluation may suggest:
- use Research Agent less for very short horizons;
- require stronger evidence in a regime;
- route Red Team to a different model;
- change memory retrieval ranking;
- change agent confidence display;
- recommend strategy research.

## Forbidden automatic effects

Evaluation cannot automatically:
- increase risk;
- change stop rules;
- increase leverage;
- enable live trading;
- promote a strategy;
- delete losses;
- rewrite journal history;
- bypass Risk Gate.
