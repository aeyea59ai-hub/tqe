# ATM Experimental Integration Architecture

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/04_ATM_INTEGRATION_ARCHITECTURE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. ATM's position in the system

ATM is not a Data Provider, Risk Engine, or Paper Engine. It is a **pure strategy evaluator** that consumes a frozen context and returns a typed Research Evaluation.

```text
Public Providers
      ↓
Validated immutable Market Snapshot
      ↓
Shared Feature + Regime Engines
      ↓
ATM S01 v2 Experimental Evaluator
      ↓
Research Evaluation (non-actionable)
      ↓
Shared Risk + Red Team in observation mode
      ↓
Research UI / Backtest / Replay / Evidence

No path to Paper Order while actionability = RESEARCH_ONLY
```

## 2. Module boundaries

### ATM owns

- asymmetric trend and momentum rules;
- ATM-specific data requirements;
- research setup geometry;
- its strategy-specific exit-model description;
- deterministic pass/fail reasons and explanation fields.

### ATM does not own

- data acquisition;
- wall-clock access or direct timestamps;
- account-equity calculation;
- risk-fraction changes;
- leverage selection;
- liquidation calculation outside the Risk Engine;
- order submission;
- mutation of the shared lifecycle;
- AI approval.

## 3. Shadow path

When `ATM_SHADOW_EVALUATION` is enabled in a future version:

1. Scanner passes a frozen Snapshot.
2. ATM returns Research Setup or No Setup.
3. Risk Engine returns an observation verdict without creating an actionable card.
4. Red Team records objections.
5. Store the result as `ATMResearchEvaluation`.
6. UI displays `RESEARCH_ONLY`.
7. No Paper Ticket button is present.
8. The result is excluded from enabled-strategy hit-rate statistics.

## 4. AI Council integration

The AI Council may read only the frozen Fact Bundle. It may:

- explain why a rule passed or failed;
- summarize Risk and Red Team objections;
- compare ATM with other strategies;
- produce localized Arabic or English user explanations.

It may not:

- calculate prices or indicators;
- change status or score;
- fill missing data;
- convert a Research Evaluation into a Candidate.

## 5. No effect on other strategies

Every ATM requirement must be either:

- a backward-compatible general extension; or
- isolated by strategy version and feature flag.

Do not change the semantics of `S02/S03/S07/S14` to accommodate ATM's trailing-only research model.
