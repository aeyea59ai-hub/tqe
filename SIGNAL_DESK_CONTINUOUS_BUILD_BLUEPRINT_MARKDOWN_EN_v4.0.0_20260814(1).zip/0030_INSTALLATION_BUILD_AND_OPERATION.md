# 26 - Installation, Build and Operation

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/26_INSTALLATION_BUILD_AND_OPERATION.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Developer workstation
Target repository contains Python backend and React frontend with pinned lockfiles. Installation commands are intentionally supplied as starter scripts rather than external documentation.

## Android/Termux target
Use Termux host plus Ubuntu/PRoot compatibility profile. Python 3.12 is the release target for the backend/AI environment. Node is required only for frontend build/development; production serves static assets. Docker is not required on phone.

## Operational scripts
`STARTER_KIT/scripts/termux_install.sh`
`STARTER_KIT/scripts/run_local.sh`
`STARTER_KIT/scripts/stop_local.sh`
`STARTER_KIT/scripts/doctor.sh`

The scripts are build-time controllers. The final implementation must pin exact package versions before release and rerun clean-install acceptance on the target phone profile.
