# Security Threat Model and Forbidden Surfaces

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/16_SECURITY_THREAT_MODEL_AND_FORBIDDEN_SURFACES.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Assets

- strategy, risk, and config versions;
- market snapshots and datasets;
- journal and audit chain;
- owner session;
- paper account;
- backtest and evidence artifacts;
- release packages.

## 2. Primary threats

| Threat | Control |
|---|---|
| Data poisoning | provider allowlist, validation, source hashes, anomaly reasons |
| Stale presented as fresh | data-class SLA plus cross-field validation |
| Hash confusion | separate content and instance identity |
| Config tampering | immutable versions plus approval events |
| Strategy escapes to Paper | hard actionability guard plus negative API tests |
| AI hallucination | frozen Fact Bundle plus numeric/evidence validator |
| Private endpoint creep | endpoint classification plus forbidden-surface scan |
| Secret leakage | no key fields, secret scan, redacted logs |
| Replay/lookahead | closed bars, replay clock, causal swings |
| Archive/path traversal | safe extraction plus package validation |
| SSRF or unexpected egress | explicit public-provider allowlist |
| SQL/API injection | typed validation plus parameterized persistence |
| CSRF/session abuse | existing session, CSRF, and rate-limit controls |

## 3. Forbidden P0 surface

- create, modify, cancel, or test exchange orders;
- signed Binance requests;
- withdrawal, transfer, account-balance, or private-position endpoints;
- private API-key or secret input fields;
- copy trading or live execution;
- exchange-action UI buttons;
- hidden remote-AI egress;
- client-supplied canonical prices.

## 4. Read-only API-key decision

Top-trader ratios may require an API key. The first version does not request one and keeps the feature OFF. If approved later:

- key has no trading or withdrawal permissions;
- use an isolated provider process;
- never store it in the repository, SQLite backups, or logs;
- require separate owner approval and threat review.

## 5. Security release gates

- forbidden-surface scan;
- secret scan;
- dependency review;
- auth and CSRF negative tests;
- backup/restore tamper tests;
- WebSocket authentication, backpressure, and reconnect tests;
- semantic mutation adds a trade endpoint and must be detected.
