# Skill Control Plane — authoritative V4 design

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/00_SKILL_CONTROL_PLANE_OVERVIEW.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Objective

Give the owner full operational control over skills **without allowing ordinary editing to break the active system**.

## Core law

`SOURCE ≠ DRAFT ≠ PUBLISHED VERSION ≠ ACTIVE PROFILE`

The imported source pack is immutable reference material.

The application never edits an installed published skill in place.

## Architecture

```text
Immutable Source Packs
        ↓
Canonical Skill Registry
        ↓
Classification / Permission Layer
        ↓
Published Skill Versions  ← immutable
        ↓
Skill Profiles
        ↓
Minimal Skill Router
        ↓
Agents

Editing path:
Published vN
  → Clone to Draft vN+1
  → Validate
  → Unit/contract tests
  → Adversarial tests when applicable
  → Impact analysis
  → Owner publish
  → Atomic profile switch
  → Monitor
  → Rollback if needed
```

## Skill classes

- `ENGINE_BACKED` — deterministic/data service capability.
- `ENGINE_BACKED_ANALYSIS` — numbers from deterministic tools; AI may interpret.
- `DETERMINISTIC_ENGINE` — no LLM numeric authority.
- `AI_REASONING` — LLM advisory reasoning.
- `QA_GUARD` — testing/security/evidence checks.
- `ADMIN_AI` — developer/admin workflows only.
- `OPTIONAL_MARKET_SKILL` — installed but disabled by default.
- `HYBRID_RESEARCH` — external context plus validated deterministic facts.

## Non-negotiable

No skill prompt can:
- create real trading access;
- bypass Risk Engine;
- expose provider secrets;
- alter immutable journal history;
- override market data authority;
- turn an AI-generated number into deterministic truth.
