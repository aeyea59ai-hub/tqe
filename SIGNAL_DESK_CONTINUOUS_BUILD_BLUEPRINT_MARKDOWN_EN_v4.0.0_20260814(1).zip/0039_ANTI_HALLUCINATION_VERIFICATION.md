# 35 - Anti-Hallucination Verification

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/35_ANTI_HALLUCINATION_VERIFICATION.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

Before claiming a module complete, verify: file exists, route exists, schema exists, formula matches locked policy, test actually executed, provider/model actually connected, data actually fresh, skill version actually active, and package hash actually computed.

Required truth labels in build/review reports: `CONFIRMED`, `INFERENCE`, `ASSUMPTION`, `UNKNOWN`, `BLOCKED`.

Forbidden claims without evidence: connected provider, current market data, successful tool call, passing test, full release, production-ready, complete security, successful fallback, valid backup/restore.

The final release evidence must come from the exact packaged tree, not historical logs from another source hash.
