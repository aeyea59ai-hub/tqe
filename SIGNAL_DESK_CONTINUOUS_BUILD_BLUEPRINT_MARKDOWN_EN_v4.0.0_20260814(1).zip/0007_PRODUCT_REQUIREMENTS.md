# 03 - Product Requirements

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/03_PRODUCT_REQUIREMENTS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

| ID | Title | Category | Priority | Lock | Requirement |
| --- | --- | --- | --- | --- | --- |
| REQ-001 | Local Owner Authentication | Foundation | P0 | LOCKED | Single-owner local session protection. First setup creates owner credential; writes require authenticated session and CSRF. |
| REQ-002 | Runtime Profiles | Foundation | P0 | LOCKED | Explicit DEMO, REPLAY, LIVE_PUBLIC, TEST and SOAK separation. No profile may silently masquerade as another profile. |
| REQ-003 | Arabic/English RTL/LTR | Foundation | P1 | CONFIGURABLE_WITH_VERSIONING | Bilingual UI with numeric/ticker isolation. Arabic layout RTL; market symbols, prices and timestamps remain LTR. |
| REQ-004 | Command Palette | UX | P2 | CONFIGURABLE_WITH_VERSIONING | Fast page/symbol/action navigation. Read-only actions may execute directly; write actions open their normal confirmation flow. |
| REQ-005 | Workspace Layout Preferences | UX | P2 | CONFIGURABLE_WITH_VERSIONING | Persist owner layout and density preferences. Corrupt preference data resets safely without affecting domain records. |
| REQ-006 | Dynamic Futures Universe | Market | P0 | LOCKED | Discover eligible public USD-margined perpetual instruments. Eligibility is derived from provider metadata; delisted/ineligible instruments cannot publish. |
| REQ-007 | Market Snapshot | Market | P0 | LOCKED | Create immutable coherent snapshot for analysis. Critical fields must meet freshness/coherence rules. |
| REQ-008 | Closed Candle Pipeline | Market | P0 | LOCKED | Use only finalized candles for decisions. Forming candles may display but never enter authoritative calculations. |
| REQ-009 | Candlestick Chart | Market | P1 | CONFIGURABLE_WITH_VERSIONING | Price/volume chart with overlays and decision geometry. Chart visuals do not own calculations. |
| REQ-010 | Indicator Engine | Market | P0 | LOCKED | EMA, RSI, MACD, ATR, VWAP and volume features. All values deterministic and versioned. |
| REQ-011 | Market Structure | Market | P0 | LOCKED | HH/HL/LH/LL, pivots, BOS/CHoCH, zones and sweeps. Confirmed-pivot rules must be non-repainting. |
| REQ-012 | Funding Context | Derivatives | P1 | CONFIGURABLE_WITH_VERSIONING | Display and evaluate funding. Funding is evidence, not standalone trade authority. |
| REQ-013 | Open Interest Context | Derivatives | P1 | CONFIGURABLE_WITH_VERSIONING | Display OI level/change and price-OI relationship. Stale OI cannot support a decision. |
| REQ-014 | Liquidity & Depth | Derivatives | P1 | CONFIGURABLE_WITH_VERSIONING | Spread/depth/liquidity evidence and paper-fill support. Insufficient depth blocks final paper approval when required. |
| REQ-015 | Market Breadth & Heatmap | Market | P2 | CONFIGURABLE_WITH_VERSIONING | Cross-universe market context. Derived from eligible universe and current snapshots. |
| REQ-016 | Staged Scanner | Scanner | P0 | LOCKED | Deterministic multi-stage full-universe scanning. Every exclusion reason must be visible and auditable. |
| REQ-017 | Scanner Ranking | Scanner | P0 | LOCKED | Rank candidates by deterministic score and tie-breaks. Same inputs/config produce same ordering. |
| REQ-018 | Manual & Scheduled Scan | Scanner | P1 | CONFIGURABLE_WITH_VERSIONING | Owner-triggered and scheduled scans. Only one effective scheduler instance per job. |
| REQ-019 | Evidence Score | Decision | P0 | LOCKED | Eight-factor deterministic evidence score. Missing optional data cannot increase score; degraded cap enforced. |
| REQ-020 | Decision Card | Decision | P0 | LOCKED | Immutable complete decision object. Card pins versions, evidence, risk, provenance and integrity hash. |
| REQ-021 | Decision Lifecycle | Decision | P0 | LOCKED | Track create/watch/reject/publish/expire/invalidate states. Invalid transitions rejected and audited. |
| REQ-022 | Red Team R1-R6 | Decision | P0 | LOCKED | Deterministic veto/objection layer. Hard objections are non-overridable. |
| REQ-023 | Six-Agent Council | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Supervisor, Research, Market, Strategy, Evidence, Red Team. Agents are advisory; deterministic services own numbers and final hard gates. |
| REQ-024 | Strategy Registry | Strategies | P0 | LOCKED | Versioned strategy inventory and eligibility. Research-only strategies cannot publish. |
| REQ-025 | Primary Strategies | Strategies | P0 | LOCKED | S01, S02, S03, S07 and S14. Numeric rules and versions are immutable once published. |
| REQ-026 | Research Strategies | Strategies | P1 | CONFIGURABLE_WITH_VERSIONING | SC01-SC08 isolated experimentation. Status RESEARCH_ONLY; no publication/paper promotion without governance. |
| REQ-027 | Strategy Draft & Validation | Strategies | P1 | CONFIGURABLE_WITH_VERSIONING | Edit drafts and validate schema/rules before publish. Published versions are immutable. |
| REQ-028 | Backtesting | Research | P0 | LOCKED | Reproducible event-driven historical evaluation. No lookahead; dataset manifest/cost model pinned. |
| REQ-029 | Replay | Research | P1 | CONFIGURABLE_WITH_VERSIONING | Step historical data through current engines. Replay mode never labels data live. |
| REQ-030 | Strategy Performance | Research | P1 | CONFIGURABLE_WITH_VERSIONING | Performance metrics by strategy/regime/symbol/side. Every metric shows sample size and cost assumptions. |
| REQ-031 | Position Sizing | Risk | P0 | LOCKED | Compute quantity from equity, risk and stop distance. Decimal precision and exchange step constraints enforced. |
| REQ-032 | Leverage Gate | Risk | P0 | LOCKED | Cap leverage by side/policy. LONG <=5x; SHORT <=3x under v1.0. |
| REQ-033 | Liquidation Safety | Risk | P0 | LOCKED | Modeled liquidation-distance safety gate. Minimum liquidation distance = 3x stop distance or block. |
| REQ-034 | Effective R Gate | Risk | P0 | LOCKED | Require cost-adjusted blended reward/risk. Minimum 2.0 effective blended R. |
| REQ-035 | Daily/Weekly Locks | Risk | P0 | LOCKED | Stop new paper approvals after loss limits. Daily -2R; weekly -6R. |
| REQ-036 | Loss Reducer | Risk | P0 | LOCKED | Reduce risk after two realized losses. Risk becomes 0.25% until next realized win. |
| REQ-037 | Calibration Risk | Risk | P0 | LOCKED | Reduce risk for first 30 closed paper trades. 0.25% risk through first 30 closed trades. |
| REQ-038 | Correlation Gate | Risk | P0 | LOCKED | Limit highly correlated concurrent positions. Maximum two BTC-correlated positions under active policy. |
| REQ-039 | Paper Preview & Confirmation | Paper | P0 | LOCKED | Preview exact deterministic paper order before owner confirmation. Confirmation uses hash/version binding and cannot call exchange. |
| REQ-040 | Paper Orders/Fills | Paper | P0 | LOCKED | Paper-only order/fill simulation. 50% TP1, move to BE, 50% TP2; no real order path. |
| REQ-041 | Paper Positions | Paper | P0 | LOCKED | Position lifecycle and PnL accounting. Append-only financial events reconcile. |
| REQ-042 | Manual Paper Close | Paper | P1 | CONFIGURABLE_WITH_VERSIONING | Owner closes paper position only. Close creates journaled event and updates locks in same cycle. |
| REQ-043 | Journal Hash Chain | Journal | P0 | LOCKED | Immutable event history and integrity verification. Losses/rejections cannot be deleted; corrections append. |
| REQ-044 | Portfolio & Risk View | Paper | P1 | CONFIGURABLE_WITH_VERSIONING | Equity, exposure, heat, open risk and PnL. Derived from journal/positions, not independent mutable totals. |
| REQ-045 | Analytics V2 | Analytics | P1 | CONFIGURABLE_WITH_VERSIONING | Ledger-derived analytics across multiple dimensions. No synthetic outcome series. |
| REQ-046 | Calibration Analytics | Analytics | P2 | CONFIGURABLE_WITH_VERSIONING | Compare confidence/evidence with realized paper outcomes. Low sample warnings mandatory. |
| REQ-047 | Data Quality Analytics | Analytics | P2 | CONFIGURABLE_WITH_VERSIONING | Measure stale/degraded/missing data impact. Shows denominators and blocked percentage. |
| REQ-048 | Alerts | Operations | P2 | CONFIGURABLE_WITH_VERSIONING | Local alerts for decisions, risk locks, provider/data health. Dedup/cooldown required; external writes disabled in base release. |
| REQ-049 | Daily Brief | Operations | P2 | CONFIGURABLE_WITH_VERSIONING | Daily deterministic/AI-assisted summary. Numeric facts come from deterministic services. |
| REQ-050 | Provider Health | Operations | P1 | CONFIGURABLE_WITH_VERSIONING | Market and AI provider status. Health state must reflect actual checks, never assumed connectivity. |
| REQ-051 | Audit Log | Operations | P0 | LOCKED | Security/config/decision/provider/skill audit trail. Sensitive values redacted. |
| REQ-052 | Backup & Restore | Operations | P1 | CONFIGURABLE_WITH_VERSIONING | Local data/config backup and integrity restore. Secrets excluded; restore validates before switch. |
| REQ-053 | Methodology & Limitations | Operations | P2 | CONFIGURABLE_WITH_VERSIONING | Explain rules, assumptions and known limitations in-app. No profitability promise. |
| REQ-054 | AI Chat | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Evidence-bound conversational interface. Read-only; numeric claims must be grounded or abstained. |
| REQ-055 | Tool Gateway | AI | P0 | LOCKED | Typed permissioned bridge from agents to deterministic services. Prompts cannot grant permissions. |
| REQ-056 | AI Provider Gateway | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Replaceable model-provider abstraction. Provider can be disabled/deleted without changing agents/tools/memory. |
| REQ-057 | Provider Routing Policies | AI | P1 | CONFIGURABLE_WITH_VERSIONING | AUTO/LOCAL_ONLY/QUALITY/COST/SPEED/MANUAL routing. Privacy class constrains fallback. |
| REQ-058 | Custom AI Provider | AI | P2 | CONFIGURABLE_WITH_VERSIONING | Add tested compatible provider. SSRF and capability validation required. |
| REQ-059 | AI Memory | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Session/preferences/research memory. Trading/journal truth stays in domain tables. |
| REQ-060 | Knowledge Base | AI | P2 | CONFIGURABLE_WITH_VERSIONING | Local searchable methodology/strategy/risk docs. Versioned source and freshness metadata. |
| REQ-061 | Skill Registry | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Install and classify skills without auto-routing all of them. Source packs immutable. |
| REQ-062 | Skill Draft/Test/Publish/Rollback | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Safely control skill changes. Edit creates draft; published version immutable. |
| REQ-063 | Skill Traceability | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Show skills used per AI run. Exact version/hash pinned. |
| REQ-064 | Agent Run Traces | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Plan/tool/provider/evidence trace without hidden chain-of-thought. Show structured execution facts only. |
| REQ-065 | Agent Evaluations | AI | P2 | CONFIGURABLE_WITH_VERSIONING | Assess evidence/agent workflow quality. Cannot silently modify risk/strategy. |
| REQ-066 | Web/News Research Adapter | AI | P2 | CONFIGURABLE_WITH_VERSIONING | Optional public research context. External text is untrusted and never market numeric authority. |
| REQ-067 | Offline Demo | Runtime | P0 | LOCKED | Full direct local demo with deterministic fixtures. No network dependency for DEMO. |
| REQ-068 | Termux Runtime | Runtime | P1 | CONFIGURABLE_WITH_VERSIONING | Android-first local operation profile. Loopback-only services; AI failure isolated. |
| REQ-069 | Health/Doctor Tools | Runtime | P1 | CONFIGURABLE_WITH_VERSIONING | Check app, DB, providers, scheduler, disk and runtime. Read-only health checks. |
| REQ-070 | Evidence Export | Operations | P1 | CONFIGURABLE_WITH_VERSIONING | Export decision/audit/test evidence bundle. No secrets; hashes included. |
| REQ-NFR-001 | Deterministic repeatability | NFR | P0 | LOCKED | Same valid input + same versions/configuration must produce the same decision-critical outputs and hashes. |
| REQ-NFR-002 | Fail closed | NFR | P0 | LOCKED | Stale, malformed, non-finite, mixed, future or missing critical data cannot improve evidence or produce paper approval. |
| REQ-NFR-003 | Phone-safe resource bounds | NFR | P1 | LOCKED | All scanner, agent, backtest, log, queue and memory workloads are bounded for Android/Termux operation. |
| REQ-NFR-004 | Accessibility | NFR | P1 | LOCKED | Keyboard, focus, reduced motion, 200% zoom, screen-reader smoke, chart alternatives and mobile widths are mandatory release tests. |
| REQ-NFR-005 | No secret leakage | NFR | P0 | LOCKED | Secrets never enter frontend bundles, logs, memory, journal, exported evidence, skill prompts or release packages. |
| REQ-NFR-006 | Traceable claims | NFR | P0 | LOCKED | Every reported PASS, provider connection, data freshness, test result and AI numeric claim must have evidence. |
