# 67 — Provider Gateway Security, SSRF, Secrets, and Data Egress

> **Source basis:** `blueprints/ai-trading-desk/source-material/67_PROVIDER_GATEWAY_SECURITY_SSRF_SECRETS_AND_DATA_EGRESS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Configurable base URL risk

Custom provider URLs create SSRF risk.

Validate:
- scheme;
- hostname/IP policy;
- DNS resolution;
- redirects;
- local/private ranges;
- timeout;
- TLS;
- port policy.

## Local model endpoints

Explicitly approved loopback endpoints may be allowed, for example:
- `127.0.0.1`
- `localhost`

Do not allow arbitrary LAN/private-network scanning through Custom Provider configuration.

## Secrets

API keys:
- backend only;
- masked in UI;
- never returned after save;
- centralized redaction;
- excluded from backups;
- excluded from memory;
- excluded from traces;
- excluded from model context.

## Data egress policy

Before sending content to a cloud provider:
- classify privacy;
- remove secrets;
- minimize context;
- apply user/provider policy.

## Local-only content

Examples:
- private journal notes;
- sensitive user metadata;
- secrets;
- optionally selected strategy documents.

LOCAL_ONLY policy must be enforceable.

## Provider deletion

Delete credential material immediately from active secret store.

Audit:
- provider ID;
- timestamp;
- user;
- affected routing policies.

Do not retain the raw credential in audit.
