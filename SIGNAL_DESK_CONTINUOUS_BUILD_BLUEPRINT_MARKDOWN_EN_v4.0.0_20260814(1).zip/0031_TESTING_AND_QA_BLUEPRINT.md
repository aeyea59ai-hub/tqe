# 27 - Testing and QA Blueprint

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/27_TESTING_AND_QA_BLUEPRINT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

| ID | Category | Priority | Test | Expected |
| --- | --- | --- | --- | --- |
| TC-SEC-001 | Security | P0 | Search final tree for live-order/signed/private-key/withdrawal surfaces | Zero forbidden surface |
| TC-DATA-001 | Data | P0 | Closed-candle enforcement | Forming/future candle rejected from decision path |
| TC-DATA-002 | Data | P0 | Freshness boundary 119.999/120/120.001s | Policy boundary exact |
| TC-RISK-001 | Risk | P0 | Effective R boundary 1.99/2.00/2.01 | Only >=2.00 can pass this gate |
| TC-RISK-002 | Risk | P0 | Liquidation ratio 2.999/3.000/3.001 | Only >=3.000 passes |
| TC-RISK-003 | Risk | P0 | Calibration count 29/30/31 | Risk reduction applied through policy boundary |
| TC-RISK-004 | Risk | P0 | Newest two losses activate reducer | Reducer active; older losses do not falsely trigger |
| TC-PAPER-001 | Paper | P0 | TP1 -> BE -> TP2 50/50 accounting | Ledger and analytics reconcile |
| TC-PAPER-002 | Paper | P0 | TP1 -> BE -> SL accounting | Ledger and analytics reconcile |
| TC-PAPER-003 | Paper | P0 | Duplicate confirmation | Idempotent; no duplicate order/event |
| TC-JRN-001 | Journal | P0 | Tamper event payload | Hash-chain verifier finds first mismatch |
| TC-STRAT-001 | Strategy | P0 | Each S01/S02/S03/S07/S14 gate fail/pass fixtures | Deterministic exact rule behavior |
| TC-BT-001 | Backtest | P0 | Lookahead probe | Future data cannot influence signal |
| TC-BT-002 | Backtest | P1 | OOS/walk-forward/cost stress | Results labeled with sample/assumptions |
| TC-AI-001 | AI | P0 | Unsupported numeric claim | Evidence validator rejects or abstains |
| TC-AI-002 | AI | P0 | Prompt injection from research source | Instructions ignored; data treated untrusted |
| TC-AI-003 | AI | P0 | LOCAL_ONLY local model offline | No cloud fallback |
| TC-SKILL-001 | Skills | P0 | Protected skill disable | Rejected |
| TC-SKILL-002 | Skills | P1 | Draft tested hash differs before publish | Publish rejected |
| TC-PROV-001 | Provider | P1 | Delete optional provider | Agents/tools/memory unaffected; bindings validated |
| TC-WS-001 | Realtime | P1 | Disconnect + sequence gap | REST reconciliation before current state |
| TC-RTL-001 | UI | P1 | Arabic 320px and 200% zoom | No clipped primary content; finance numerics LTR |
| TC-A11Y-001 | UI | P1 | Keyboard/focus/reduced motion | All core flows accessible |
| TC-OFF-001 | Offline | P0 | Network disabled DEMO launch | Full deterministic demo without fake LIVE |
| TC-BKP-001 | Backup | P1 | Corrupt backup | Restore aborts before current data switch |
| TC-SOAK-001 | Reliability | P1 | 24-hour soak on release candidate | No duplicate scheduler, unbounded growth, stale-to-signal, integrity failure |

## Layers
L0 static/schema/import/build/security scans; L1 unit; L2 property/golden/mutation for critical domain modules; L3 integration API/DB/provider/jobs/backup; L4 browser/E2E/accessibility; L5 performance/chaos; L6 clean install/package/soak. A mandatory test that is skipped, blocked or failed prevents release PASS.
