# 05 - User Roles and Permissions

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/05_USER_ROLES_AND_PERMISSIONS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## V1 user model
The base release is a local single-owner application. There is no multi-tenant role hierarchy. The only authenticated human role is `OWNER`. System actors are services, not human roles.

| Actor | Read market | Change settings | Publish strategy/skill | Paper write | Change risk | Live trade | Read secrets |
|---|---:|---:|---:|---:|---:|---:|---:|
| OWNER | yes | yes | gated | confirmed only | versioned policy workflow only | no | masked/manage only |
| AI Agent | scoped | no | no | proposal only | no | no | no |
| Deterministic Service | owned domain | owned config | service-specific | paper service only | enforces | no | no |
| Scheduler | scoped jobs | no | no | lifecycle only | enforces | no | no |

Prompts never grant permissions. Tool Gateway and backend authorization are authoritative.
