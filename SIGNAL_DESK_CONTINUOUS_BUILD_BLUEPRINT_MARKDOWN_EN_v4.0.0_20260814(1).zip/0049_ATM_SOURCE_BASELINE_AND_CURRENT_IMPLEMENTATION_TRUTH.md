# Source Baseline and Current Implementation Truth

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/03_SOURCE_BASELINE_AND_CURRENT_IMPLEMENTATION_TRUTH.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Source identities

| Source | SHA-256 / Git identity |
|---|---|
| Signal Desk canonical Git tree | `e23d2d4add989ffabb5dab93a98388523254a762` |
| Full application + reverse-engineered blueprint ZIP | `7d783d9629c6faf2fd59e92a07dfd04bc3cd2e40485d64dea5d4f21d3c37a07f` |
| Signal Desk v1.1.0 source ZIP | `381959e841f95a1978fd22317f66e40cb7288aab72e30405f7d64dd672b9e02f` |
| ATM 44-school handover v1.1.0 ZIP | `23e32c5548e58e3c13c0aab51a30dbad5ee5e3be561e6108d8be88503154350e` |

## 2. Existing Signal Desk structure to preserve

- Backend: FastAPI plus deterministic domain services.
- Frontend: React/Vite/TypeScript with terminal UI and RTL support.
- Storage: local SQLAlchemy/Alembic/SQLite.
- Pipeline: Provider -> Snapshot -> Feature -> Regime -> Strategy -> Risk -> Red Team -> Decision -> Paper -> Journal -> Analytics/Replay/Backtest.
- Registry: `S01, S02, S03, S07, S14` plus `SC01-SC08` Research Only candidates.
- Active risk policy: `signal-desk-risk v1.0.0`.
- Forbidden surface: live trading and signed exchange actions.

## 3. Future integration locations

| Area | Current location |
|---|---|
| Strategy registry | `backend/app/domain/strategies/registry.py` |
| ATM implementation | `backend/app/domain/strategies/s01.py` |
| ATM config | `config/strategies/s01.yaml` |
| Strategy contract | `backend/app/domain/strategies/base.py` |
| Feature/structure definitions | `backend/app/domain/features/` |
| Risk authority | `backend/app/domain/risk/` |
| Paper lifecycle | `backend/app/domain/paper/lifecycle.py` |
| Scanner integration | `backend/app/services/scanner.py` |
| Decision pipeline | `backend/app/services/decisions.py` |
| Persistence | `backend/app/storage/models.py` |
| Strategy API | `backend/app/api/routes/strategies.py` |
| Strategy UI | `frontend/src/pages/Strategies.tsx`, `StrategyDetail.tsx` |
| Backtest UI/API | `Backtest.tsx`, strategy routes and services |

## 4. P0 reconciliation matrix - current S01 versus governing ATM

| Rule | Current S01 | Governing ATM v2 | Integration decision |
|---|---|---|---|
| Long regime | close/EMA50 + EMA50 slope | close > EMA200 + EMA50 10-day slope > 0 | New version; no silent edit |
| Short regime | close/EMA50 + slope | close < EMA200 + EMA200 10-day slope <= 0 + CHoCH | New version |
| High volatility | percentile 97 | percentile >=90 rejects | ATM v2 |
| Low volatility | percentile 5 | percentile <15 waits | ATM v2 |
| No chase | 1.5 ATR | 2.0 ATR | ATM v2 |
| Entry | current close | swing/Fibonacci/EMA20 + 15m trigger + next-open research fill | ATM v2 |
| Stop | fixed 2.0 ATR | confirmed swing +/-0.6 ATR; floor 1.2; cap 3.5 | ATM v2 |
| Exit | TP1 1.5R / TP2 3R | Chandelier + time/regime/funding exits | ATM v2 research-only |
| Partial exit | fixed paper lifecycle conventions | disabled; optional 40% at 2R only in a later version | flag OFF |
| Expiry | 16 x 4H | 12 x 4H | ATM v2 |
| Actionability | default paper eligible | research-only | hard guard |

## 5. Impact of the decision

Preserve `S01 v1.0.0` for audit and reproduction. Do not change its payload or hash. Create a separate `S01 v2.0.0-experimental` version and keep it disabled until implementation and tests are complete.
