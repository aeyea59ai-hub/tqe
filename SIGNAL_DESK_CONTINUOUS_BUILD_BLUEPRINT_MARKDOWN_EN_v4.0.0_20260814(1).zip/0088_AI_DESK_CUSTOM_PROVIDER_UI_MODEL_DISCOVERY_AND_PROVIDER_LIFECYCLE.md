# 64 — Custom Provider UI, Model Discovery, and Provider Lifecycle

> **Source basis:** `blueprints/ai-trading-desk/source-material/64_CUSTOM_PROVIDER_UI_MODEL_DISCOVERY_AND_PROVIDER_LIFECYCLE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Provider Settings UI

```text
AI PROVIDERS

[Enabled] Ollama Local
Model: ...
Status: Connected
Priority: 1
[Test] [Models] [Disable] [Remove]

[Enabled] Kimi
Model: ...
Status: Connected
Priority: 2
[Test] [Models] [Disable] [Remove]

[Disabled] OpenAI
[Test] [Enable] [Remove]

[ + Add Provider ]
```

## Add Custom Provider

Fields:

```text
Name
Adapter / Protocol
Base URL
API Key
Default Model
Timeout
Streaming
Tool Support Override
Structured Output Override
Vision Override
Privacy Classification
```

Protocols may include:

```text
OpenAI-compatible
Open Responses-compatible
Ollama
Anthropic-compatible
Custom adapter
```

A protocol choice is not proof of full compatibility.

The provider must pass capability tests.

## Provider lifecycle

```text
ADDED
→ UNTESTED
→ HEALTHY
→ DEGRADED
→ DISABLED
→ REMOVED
```

## Health check

Test:
- endpoint reachability;
- authentication;
- model existence;
- basic generation;
- streaming if enabled;
- tools if enabled;
- structured output if enabled.

## Model discovery

If provider supports model listing:
- fetch models;
- cache with timestamp;
- allow manual refresh.

If not:
- manual model ID entry;
- validate through test request.

## Remove provider

Before removal:
- show affected agent overrides;
- switch them to fallback/AUTO;
- delete stored credential;
- retain historical run metadata such as provider/model names for audit;
- never delete agent memories or trading data.

## Default four-slot recommendation

```text
1 LOCAL
  Ollama Local

2 PRIMARY CLOUD
  Kimi / selected provider

3 SECONDARY CLOUD
  Ollama Cloud / selected provider

4 OPTIONAL
  OpenAI / other provider
```

This is a default policy, not a hard-coded vendor requirement.
