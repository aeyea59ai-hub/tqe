# 39 - Skill Control Plane

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/39_SKILL_CONTROL_PLANE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

Source library size: 166 market skills. Source pack is immutable.

## Skill classes
SYSTEM, ENGINE_BACKED, ENGINE_BACKED_ANALYSIS, DETERMINISTIC_ENGINE, AI_REASONING, HYBRID_RESEARCH, QA_GUARD, ADMIN_AI.

## Lifecycle
Imported -> Classified -> Draft -> Validated -> Tested -> Published -> Active/Disabled -> Deprecated. Published versions are immutable. Edit clones to a draft.

## Publish gate
Schema + policy + contract + exact-hash tests + adversarial tests when AI + routing/dependency checks + impact analysis + owner publish.

## Protected boundaries
Skill editor cannot enable live trading, change root Tool Gateway permissions, bypass Risk, expose secrets, rewrite journal history or change market-data authority.

## Trace
Every AI run records exact skill slug/version/hash.
