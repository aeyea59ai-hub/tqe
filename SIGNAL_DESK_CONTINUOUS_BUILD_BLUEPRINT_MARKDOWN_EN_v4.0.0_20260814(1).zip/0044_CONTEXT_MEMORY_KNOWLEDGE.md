# 40 - Context, Memory and Knowledge

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/40_CONTEXT_MEMORY_KNOWLEDGE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Context bundle
Current owner request, page, symbol/timeframe, runtime profile, fresh market snapshot, active strategies, recent decisions, paper portfolio/risk locks, relevant journal references, relevant memory, available tools, provider policy.

Precedence: explicit current instruction > current UI selection > session > preferences > historical memory. Historical memory never overrides fresh market facts.

## Memory classes
1 Session conversation
2 User preferences
3 Decision references
4 Research memory with freshness/expiry
5 Strategy observations/calibration
6 Knowledge documents

Journal/decision truth is not stored as editable AI memory. V1 retrieval can use local SQLite FTS/BM25; embeddings are optional and must be versioned if added.
