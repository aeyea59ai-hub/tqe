# 15 - Database Architecture

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/15_DATABASE_ARCHITECTURE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

SQLite-first with WAL, foreign keys, versioned Alembic migrations and bounded transactions. Domain records and AI/skill records share one installation but have separate ownership boundaries.

| Table | Purpose | Owner | Retention |
| --- | --- | --- | --- |
| app_users | Local owner identity | Auth | INDEFINITE |
| sessions | Local authenticated sessions and CSRF | Auth | SESSION_LIFETIME |
| configuration_versions | Versioned app policies/config | Config | INDEFINITE |
| approval_events | Owner approvals with hash chain | Governance | INDEFINITE |
| schema_migrations | Migration ledger | Database | INDEFINITE |
| instruments | Eligible market symbols/metadata | Market | INDEFINITE |
| market_snapshots | Immutable decision snapshots | Market | INDEFINITE |
| candles_cache | Validated historical/current closed candles | Market | CACHE_POLICY |
| provider_health | Market provider health history | Providers | 30_DAYS |
| scanner_runs | Scan job state/config | Scanner | INDEFINITE |
| scanner_candidates | Candidate scores/ranks | Scanner | INDEFINITE |
| scanner_exclusions | Stage rejection reasons | Scanner | INDEFINITE |
| strategy_versions | Published strategy versions | Strategies | INDEFINITE |
| strategy_drafts | Editable strategy drafts | Strategies | UNTIL_PUBLISHED_OR_DELETED |
| backtest_runs | Backtest run metadata | Backtest | INDEFINITE |
| backtest_trades | Backtest trade events | Backtest | INDEFINITE |
| replay_runs | Replay sessions | Replay | 90_DAYS |
| decisions | Immutable decision cards | Decision | INDEFINITE |
| decision_evidence | Evidence/provenance links | Evidence | INDEFINITE |
| decision_objections | Red Team objections | Red Team | INDEFINITE |
| decision_events | Decision lifecycle events | Decision | INDEFINITE |
| paper_orders | Paper orders | Paper | INDEFINITE |
| paper_fills | Paper fills | Paper | INDEFINITE |
| paper_positions | Paper positions | Paper | INDEFINITE |
| paper_position_events | Paper lifecycle/accounting events | Paper | INDEFINITE |
| journal_events | Append-only journal hash chain | Journal | INDEFINITE |
| portfolio_snapshots | Derived portfolio snapshots | Portfolio | 365_DAYS |
| alerts | Local alerts | Alerts | 180_DAYS |
| audit_events | Security/config/skill/provider audit | Audit | INDEFINITE |
| backup_records | Backup manifests and hashes | Backup | KEEP_WITH_BACKUP |
| ai_providers | Provider metadata and secret reference only | AI Provider | INDEFINITE |
| ai_models | Discovered model inventory | AI Provider | CURRENT_PLUS_HISTORY |
| ai_provider_capabilities | Model/provider capabilities | AI Provider | CURRENT_PLUS_HISTORY |
| ai_routing_policies | Routing policies | AI Provider | INDEFINITE |
| ai_request_logs | Sanitized AI request metadata | AI | 14_DAYS |
| ai_provider_health | AI provider health | AI Provider | 30_DAYS |
| ai_sessions | AI conversation sessions | AI | 90_DAYS |
| ai_messages | Conversation messages after privacy policy | AI | 90_DAYS |
| ai_memories | Editable AI memory records | Memory | POLICY |
| knowledge_documents | Local knowledge metadata/content | Knowledge | INDEFINITE |
| agent_runs | Agent run metadata | AI | 14_DAYS |
| agent_tool_calls | Sanitized tool trace | AI | 14_DAYS |
| agent_evaluations | Run evaluation/calibration | AI | 365_DAYS |
| skill_sources | Immutable imported skill pack records | Skills | INDEFINITE |
| skill_versions | Immutable published skill versions | Skills | INDEFINITE |
| skill_drafts | Editable skill drafts | Skills | UNTIL_PUBLISHED_OR_DELETED |
| skill_profiles | Named skill activation profiles | Skills | INDEFINITE |
| skill_profile_bindings | Profile-to-version bindings | Skills | INDEFINITE |
| skill_agent_bindings | Agent-skill bindings | Skills | INDEFINITE |
| skill_tool_bindings | Server-side tool permissions | Skills | INDEFINITE |
| skill_test_runs | Exact-hash test evidence | Skills | INDEFINITE |
| skill_audit_events | Skill lifecycle audit | Skills | INDEFINITE |
