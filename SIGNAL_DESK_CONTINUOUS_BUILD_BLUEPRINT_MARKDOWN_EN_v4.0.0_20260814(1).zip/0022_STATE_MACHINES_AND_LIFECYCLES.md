# 18 - State Machines and Lifecycles

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/18_STATE_MACHINES_AND_LIFECYCLES.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

```json
{
  "decision": [
    "CREATED",
    "DATA_UNAVAILABLE",
    "NO_TRADE",
    "REJECTED",
    "LOCKED",
    "WATCHLIST",
    "CANDIDATE",
    "MANUAL_REVIEW",
    "PUBLISHED",
    "EXPIRED",
    "INVALIDATED"
  ],
  "signal_monitoring": [
    "PUBLISHED",
    "WAITING_FOR_ENTRY",
    "NO_CHASE",
    "EXPIRED",
    "INVALIDATED",
    "TRIGGERED"
  ],
  "paper_position": [
    "PENDING_FILL",
    "OPEN",
    "PARTIAL_TP1",
    "BE_PROTECTED",
    "TP2_CLOSED",
    "SL_CLOSED",
    "MANUAL_CLOSED",
    "INVALIDATION_CLOSED",
    "EXPIRED_UNFILLED",
    "CANCELLED",
    "INVALIDATED_UNFILLED",
    "REVIEWED"
  ],
  "quality": [
    "VALID",
    "VALID_WITH_OPTIONAL_MISSING",
    "DEGRADED",
    "INVALID",
    "STALE",
    "UNAVAILABLE"
  ],
  "skill": [
    "IMPORTED",
    "CLASSIFIED",
    "DRAFT",
    "VALIDATED",
    "TESTED",
    "PUBLISHED",
    "ACTIVE",
    "DISABLED",
    "DEPRECATED"
  ],
  "provider": [
    "UNTESTED",
    "HEALTHY",
    "DEGRADED",
    "RATE_LIMITED",
    "AUTH_ERROR",
    "OFFLINE",
    "DISABLED",
    "REMOVED"
  ]
}
```

## Paper lifecycle
```mermaid
stateDiagram-v2
  [*] --> PENDING_FILL
  PENDING_FILL --> OPEN
  PENDING_FILL --> EXPIRED_UNFILLED
  PENDING_FILL --> CANCELLED
  PENDING_FILL --> INVALIDATED_UNFILLED
  OPEN --> PARTIAL_TP1
  OPEN --> SL_CLOSED
  OPEN --> MANUAL_CLOSED
  OPEN --> INVALIDATION_CLOSED
  PARTIAL_TP1 --> BE_PROTECTED
  BE_PROTECTED --> TP2_CLOSED
  BE_PROTECTED --> SL_CLOSED
  BE_PROTECTED --> MANUAL_CLOSED
  TP2_CLOSED --> REVIEWED
  SL_CLOSED --> REVIEWED
  MANUAL_CLOSED --> REVIEWED
  INVALIDATION_CLOSED --> REVIEWED
```
