# API Blueprint - ATM Research Integration

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/10_API_BLUEPRINT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Compatibility rule

Preserve all current endpoints. ATM additions live in a research namespace and do not change contracts for other strategies.

## 2. Proposed endpoints

### Strategy Registry extensions

| Method/path | Purpose | Actionability |
|---|---|---|
| GET `/api/v1/strategies/S01/experimental-status` | version, lifecycle, flags, blockers | read-only |
| GET `/api/v1/strategies/S01/versions/2.0.0-experimental` | contract, version, hash | read-only |
| GET `/api/v1/strategies/S01/promotion-gates` | state and evidence for every gate | read-only |

### Research runs

| Method/path | Purpose |
|---|---|
| POST `/api/v1/research/atm/runs` | start an authenticated/CSRF-protected shadow, replay, or backtest research run |
| GET `/api/v1/research/atm/runs` | list runs |
| GET `/api/v1/research/atm/runs/{id}` | counts, status, hashes, and errors |
| GET `/api/v1/research/atm/evaluations` | filter by symbol, state, and dataset mode |
| GET `/api/v1/research/atm/evaluations/{id}` | complete rules, evidence, risk, and Red Team result |
| GET `/api/v1/research/atm/coverage` | data coverage matrix |

### Verification and data

| Method/path | Purpose |
|---|---|
| GET `/api/v1/data/datasets` | manifests and eligibility |
| GET `/api/v1/data/datasets/{id}` | coverage, gaps, and hashes |
| GET `/api/v1/verification/semantic` | latest Semantic Verification status |
| GET `/api/v1/verification/mutations` | mutation kill report |

## 3. Forbidden API surfaces

- No direct endpoint to enable `ATM_ACTIONABLE_DECISIONS`.
- No endpoint to create a Paper Order from ATM v2.
- No endpoint accepts client-computed canonical price or indicator values.
- No endpoint mutates the payload of a used strategy version.
- No endpoint accepts Binance credentials or creates signed exchange requests.

## 4. Typed error codes

| Code | Meaning |
|---|---|
| `ATM_DISABLED` | evaluation flag is off |
| `ATM_RESEARCH_ONLY` | actionability is blocked |
| `ATM_VERSION_IMMUTABLE` | attempted mutation of a used version |
| `ATM_DATASET_INELIGIBLE` | coverage or provenance failed |
| `ATM_INSUFFICIENT_HISTORY` | warm-up is incomplete |
| `ATM_TRAILING_EXIT_UNSUPPORTED` | Paper Engine does not support the exit model |
| `ATM_PROMOTION_GATE_FAILED` | one or more promotion gates are incomplete |
| `SEMANTIC_VERIFICATION_REQUIRED` | verifier evidence is absent |
| `CONTENT_HASH_MISMATCH` | integrity failure |
| `FEATURE_FLAG_UNKNOWN` | unknown feature flag |

## 5. Response-contract rules

- Use decimal strings for money and prices.
- Include version, hash, and source fields in every research response.
- `paper_only=true` is not sufficient; ATM responses also carry `actionability=RESEARCH_ONLY`.
- Never return raw stack traces.
- Pagination is bounded.
- Every write is idempotent or explicitly modeled as job creation.
