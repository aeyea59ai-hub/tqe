# 10 - Frontend Architecture

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/10_FRONTEND_ARCHITECTURE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Target stack
React 19 + Vite + strict TypeScript + React Router. Frontend owns presentation, navigation, owner preferences and transient interaction state. It does not own authoritative market/risk/strategy/paper/accounting calculations.

## Layers
```text
src/
  app/            bootstrap, router, providers
  shell/          rail, context bar, command palette
  pages/          route-level composition
  features/       market, scan, decision, strategy, paper, journal, analytics, ai, system
  components/     reusable primitives
  api/            typed REST client and WebSocket client
  state/          UI/symbol/runtime/preferences only
  i18n/           Arabic/English
  theme/          tokens and motion
  utils/          formatting only; no domain finance logic
```

## State separation
- Server state: fetched from backend and cached with explicit freshness metadata.
- UI state: active symbol, tab, filters, open inspector, density, language.
- Persisted UI preferences: local storage with schema version and safe migration.
- Domain truth: never reconstructed from local storage.

## Error boundary
Route-level error boundary renders a precise recoverable state without clearing persisted domain data.

## WebSocket
Events update caches only after sequence/dedup validation. On gap/reconnect, reconcile with REST snapshot before showing current state.
