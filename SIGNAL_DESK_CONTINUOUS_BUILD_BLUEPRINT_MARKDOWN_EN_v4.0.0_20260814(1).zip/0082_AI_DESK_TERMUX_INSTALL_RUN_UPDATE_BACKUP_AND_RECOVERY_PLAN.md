# 57 — Termux Install, Run, Update, Backup, and Recovery Plan

> **Source basis:** `blueprints/ai-trading-desk/source-material/57_TERMUX_INSTALL_RUN_UPDATE_BACKUP_AND_RECOVERY_PLAN.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Deliverable

The final implementation must include a phone installer and doctor script.

This blueprint does not claim the exact commands have already been tested.

## Installation stages

### Stage 0 — Device checks

Detect:
- Android architecture;
- Termux prefix;
- available RAM/storage;
- Python/Node versions;
- ports in use;
- network state;
- existing installation.

### Stage 1 — Termux host dependencies

Expected classes:
- git
- curl
- openssl
- nodejs
- tmux
- proot-distro
- build tools only where required

### Stage 2 — Ubuntu compatibility environment

Install/enter Ubuntu via `proot-distro`.

Inside compatibility runtime:
- pinned Python 3.12 via `uv` or approved method;
- virtualenv;
- backend dependencies;
- Agno/AgentOS;
- AG-UI protocol Python dependency;
- search/provider extras selected by owner.

### Stage 3 — Application

- extract/copy exact verified source;
- verify release checksum;
- install frontend dependencies and build once;
- install backend dependencies;
- initialize DB/migrations;
- create configuration from templates;
- never copy secrets from release package.

### Stage 4 — Provider setup

Through UI or env:
- choose local/cloud;
- add provider;
- test;
- select model.

### Stage 5 — Smoke

- primary API health;
- AgentOS status;
- AG-UI stream;
- DB session persistence;
- memory write/read;
- deterministic scanner;
- risk tool;
- chat tool call;
- web search if network enabled;
- paper confirmation;
- app restart and session recall.

## Update

`phone-update.sh`:
- backup DBs;
- validate new release checksum;
- stop services;
- migrate;
- run smoke;
- rollback automatically on migration/startup failure where safe.

## Backup

`phone-backup.sh`:
- DBs;
- non-secret config;
- journal/audit;
- memories/knowledge according to policy;
- manifest/checksum.

Provider keys excluded.

## Recovery

`phone-doctor.sh` checks:
- process duplication;
- stale PID files;
- ports;
- Python environment;
- broken packages;
- DB integrity;
- migrations;
- disk space;
- AgentOS health;
- frontend assets;
- provider status.

## No public exposure

Do not add Cloudflare Tunnel, ngrok, or public port forwarding in default phone setup.

Remote access is a separate security decision.
