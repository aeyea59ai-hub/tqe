# 41 - Motion and Interaction System

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/41_MOTION_AND_INTERACTION_SYSTEM.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

```json
{
  "principle": "Motion confirms hierarchy and state. No bouncing, decorative parallax, or attention-seeking loops.",
  "durations_ms": {
    "instant": 70,
    "fast": 110,
    "standard": 160,
    "drawer": 220,
    "modal": 180,
    "page": 180,
    "price_flash": 520
  },
  "easing": {
    "standard": "cubic-bezier(0.2,0,0,1)",
    "exit": "cubic-bezier(0.4,0,1,1)"
  },
  "patterns": {
    "page_change": "opacity 0->1 and translateY 4px->0",
    "drawer": "translateX 16px->0 and opacity 0->1",
    "dialog": "scale .985->1 and opacity 0->1",
    "row_selection": "background interpolation only",
    "price_tick": "single semantic background flash; no number bounce",
    "risk_veto": "one border-color transition; no repeated pulse",
    "chart_loading": "static skeleton bands with low-opacity pulse",
    "command_palette": "fade + 6px vertical settle"
  },
  "reduced_motion": "Disable transforms and animated scrolling; retain immediate state color changes only."
}
```

## Interaction rules
- Click a table row: select row and open inspector without page jump.
- Double activation is never required; mobile uses single tap.
- Escape closes overlay/drawer, never discards a committed change.
- Destructive or paper-write actions use explicit confirmation.
- Long asynchronous jobs show stage, elapsed time, cancel action and last verified output.
- Price changes use semantic flash only; do not animate digit position.
- Risk veto appears immediately and stays static until input changes.
