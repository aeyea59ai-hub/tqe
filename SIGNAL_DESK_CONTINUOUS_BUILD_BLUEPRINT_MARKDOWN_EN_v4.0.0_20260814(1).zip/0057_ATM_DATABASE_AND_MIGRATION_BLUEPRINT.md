# Database and Migration Blueprint

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/11_DATABASE_AND_MIGRATION_BLUEPRINT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Reuse before adding

The current source already contains StrategyVersion, StrategyStatusEvent, FeatureArtifact, SetupMatchRow, DecisionCard, Dataset, BacktestTrial/Artifact, PromotionRequest, and AuditEvent. Reuse them when they satisfy the required invariants instead of duplicating entities.

## 2. Logical additions

### FeatureFlagSet

- id, version, and hash;
- strategy_id and strategy version;
- immutable flag map;
- created_by and effective time;
- approval-event reference.

### ATMResearchRun

- run identity, type, and status;
- source commit, config, dataset, and universe hashes;
- replay clock range;
- counts and error;
- created, started, and finished times.

### ATMResearchEvaluation

- run, snapshot, and strategy references;
- rule-result payload hash;
- state, side, and actionability;
- geometry and exit-model references;
- risk and Red Team references;
- immutable result.

### DatasetManifest and DatasetPartition

- provenance, license, and coverage;
- partition hashes and root hash;
- completeness metrics;
- promotion eligibility.

### SemanticVerificationRun

- source tree hash;
- contract version;
- checks and findings;
- status;
- evidence root hash.

### MutationResult

- mutation ID, category, and severity;
- expected detector;
- actual detection;
- killed or survived;
- evidence reference.

## 3. Constraints

- unique strategy_id plus version;
- unique content hash within each artifact type where appropriate;
- Research Evaluation cannot reference PaperOrder;
- append-only status transitions;
- enforced foreign keys;
- no cascade delete for audit, evidence, or history;
- decimal strings or exact decimal DB types, never float for money;
- UTC timestamps with one consistent serialization.

## 4. Migration strategy

- The next revision follows current migration `0003`; the developer assigns the actual revision ID.
- Historical migrations must not import current ORM metadata to create tables.
- Use explicit table, column, index, and constraint operations.
- Test upgrade from a clean DB and an existing v1.1 DB.
- Document downgrade policy; audit data may be forward-only.
- Take a pre-migration backup and run a dry run.
- Expose schema version in `/version` and evidence.

## 5. Data retention

- Retain market and raw dataset partitions according to storage policy.
- Never automatically delete strategy versions, evaluations, backtests, audit, or journal history.
- A UI delete action, if present, must archive or retire, never physically delete authoritative history.
