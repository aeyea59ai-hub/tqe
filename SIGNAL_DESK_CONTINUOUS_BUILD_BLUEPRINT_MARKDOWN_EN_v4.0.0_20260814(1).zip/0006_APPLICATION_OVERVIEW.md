# 02 - Application Overview

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/02_APPLICATION_OVERVIEW.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

SIGNAL DESK is a local-first crypto futures intelligence, strategy research, deterministic decision, risk-control and paper-trading workstation. It is not a live-execution terminal. Public market data and deterministic domain code own prices, indicators, strategy pass/fail, evidence score, sizing, leverage, liquidation safety, fees, funding, slippage, paper fills, journal accounting and analytics. AI is an optional advisory layer that can research, interpret, critique, orchestrate tools and explain evidence without becoming numeric market truth. The product is designed as one owner-operated Web/PWA application with an Android/Termux-compatible runtime profile.

## Product domains
- Market truth and data quality
- Deterministic indicators and market structure
- Scanner and candidate ranking
- Versioned strategy engine
- Decision cards, evidence and Red Team
- Deterministic risk and portfolio controls
- Paper orders, fills, positions and journal
- Backtest, replay, analytics and calibration
- AI Trading Desk with six top-level agents
- Provider Gateway, Tool Gateway, Memory, Skills and Traces
- Local operations, alerts, audit, backup and offline demo

## Safety boundary
There is no live order capability in the base product. Private exchange keys, signed order requests, withdrawals and transfers are outside the application contract.

## Architecture
```mermaid
flowchart LR
  UI["React Web/PWA"] --> API["FastAPI REST + WebSocket"]
  API --> Domain["Deterministic Domain Services"]
  Domain --> DB["SQLite + Alembic"]
  Domain --> Market["Public Market Adapters"]
  Domain --> Scheduler["Scheduler / Jobs"]
  UI --> AgentUI["AI Desk / AG-UI"]
  AgentUI --> AgentRuntime["Agent Runtime"]
  AgentRuntime --> ToolGW["Tool Gateway"]
  ToolGW --> Domain
  AgentRuntime --> ModelRouter["Model Policy Router"]
  ModelRouter --> ProviderGW["AI Provider Gateway"]
  ProviderGW --> Models["Local / Cloud Models"]
```
