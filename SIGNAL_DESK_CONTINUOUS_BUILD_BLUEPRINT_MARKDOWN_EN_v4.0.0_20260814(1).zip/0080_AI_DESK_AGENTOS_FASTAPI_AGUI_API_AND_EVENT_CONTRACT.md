# 55 — AgentOS / FastAPI / AG-UI API and Event Contract

> **Source basis:** `blueprints/ai-trading-desk/source-material/55_AGENTOS_FASTAPI_AGUI_API_AND_EVENT_CONTRACT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Integration rule

SIGNAL DESK domain APIs stay authoritative.

AgentOS is an orchestration service consuming those APIs/tools.

## Local endpoints

Conceptual:

```text
GET  /api/ai/config
GET  /api/ai/providers
POST /api/ai/providers/test
POST /api/ai/providers
PATCH /api/ai/providers/{id}
DELETE /api/ai/providers/{id}

GET  /api/ai/sessions
GET  /api/ai/memories
GET  /api/ai/tools
GET  /api/ai/traces

POST /agent/agui
GET  /agent/status
```

Exact AgentOS routes should follow the installed version's official API.

Do not duplicate upstream APIs unnecessarily.

## AG-UI events used by SIGNAL DESK

Map protocol events into UI state:

- run started
- text/message content
- tool call started
- tool call result
- custom evidence event
- custom risk event
- custom paper-confirmation event
- run finished
- run error

## Custom event examples

`MarketScanProgressEvent`
- stage
- scanned_count
- total_count
- current_symbol

`EvidenceCardEvent`
- decision_id
- evidence_ids
- summary

`RiskVetoEvent`
- decision_id
- reason_codes
- immutable = true

`PaperConfirmationEvent`
- decision_id
- paper_plan
- confirmation_token

## Session identity

Every chat run includes:
- user_id
- session_id
- request_id
- runtime profile
- active provider/model

## Authorization

Local single-user mode still requires a session boundary between browser and backend.

If AgentOS authorization is enabled, integrate identity with existing SIGNAL DESK auth rather than creating a separate user identity.

Do not expose a second uncontrolled auth system.
