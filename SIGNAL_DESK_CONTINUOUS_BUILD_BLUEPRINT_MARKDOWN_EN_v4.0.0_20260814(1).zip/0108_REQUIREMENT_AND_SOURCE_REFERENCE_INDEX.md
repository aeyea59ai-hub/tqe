# Requirement and Source Reference Index

This table records the source basis for every specification or reference file in this package. It is informational and does not impose an intake or conversation workflow.

| Number | File | Description | Source basis |
|---:|---|---|---|
| 0001 | `0001_PACKAGE_OVERVIEW.md` | Package Overview | `curated continuous-build core` |
| 0002 | `0002_CONTINUOUS_BUILD_MODE.md` | Continuous Build Mode | `curated continuous-build core` |
| 0003 | `0003_CANONICAL_BUILD_CONSTRAINTS.md` | Canonical Build Constraints | `curated continuous-build core` |
| 0004 | `0004_BASELINE_AND_TARGET_WORK_ITEMS.md` | Baseline And Target Work Items | `curated continuous-build core` |
| 0005 | `0005_SOURCE_AUTHORITY_AND_CONFLICT_RESOLUTION.md` | Source Authority And Conflict Resolution | `curated continuous-build core` |
| 0006 | `0006_APPLICATION_OVERVIEW.md` | Application Overview | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/02_APPLICATION_OVERVIEW.md` |
| 0007 | `0007_PRODUCT_REQUIREMENTS.md` | Product Requirements | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/03_PRODUCT_REQUIREMENTS.md` |
| 0008 | `0008_COMPLETE_FEATURE_CATALOG.md` | Complete Feature Catalog | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/04_COMPLETE_FEATURE_CATALOG.md` |
| 0009 | `0009_USER_ROLES_AND_PERMISSIONS.md` | User Roles And Permissions | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/05_USER_ROLES_AND_PERMISSIONS.md` |
| 0010 | `0010_USER_FLOWS.md` | User Flows | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/06_USER_FLOWS.md` |
| 0011 | `0011_SCREEN_AND_ROUTE_CATALOG.md` | Screen And Route Catalog | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/07_SCREEN_AND_ROUTE_CATALOG.md` |
| 0012 | `0012_UI_UX_BLUEPRINT.md` | Ui Ux Blueprint | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/08_UI_UX_BLUEPRINT.md` |
| 0013 | `0013_DESIGN_SYSTEM.md` | Design System | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/09_DESIGN_SYSTEM.md` |
| 0014 | `0014_FRONTEND_ARCHITECTURE.md` | Frontend Architecture | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/10_FRONTEND_ARCHITECTURE.md` |
| 0015 | `0015_FRONTEND_COMPONENT_CATALOG.md` | Frontend Component Catalog | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/11_FRONTEND_COMPONENT_CATALOG.md` |
| 0016 | `0016_BACKEND_ARCHITECTURE.md` | Backend Architecture | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/12_BACKEND_ARCHITECTURE.md` |
| 0017 | `0017_API_CONTRACTS.md` | Api Contracts | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/13_API_CONTRACTS.md` |
| 0018 | `0018_WEBSOCKET_REALTIME_ARCHITECTURE.md` | Websocket Realtime Architecture | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/14_WEBSOCKET_REALTIME_ARCHITECTURE.md` |
| 0019 | `0019_DATABASE_ARCHITECTURE.md` | Database Architecture | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/15_DATABASE_ARCHITECTURE.md` |
| 0020 | `0020_DATABASE_SCHEMA_AND_ERD.md` | Database Schema And Erd | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/16_DATABASE_SCHEMA_AND_ERD.md` |
| 0021 | `0021_BUSINESS_LOGIC_AND_ALGORITHMS.md` | Business Logic And Algorithms | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/17_BUSINESS_LOGIC_AND_ALGORITHMS.md` |
| 0022 | `0022_STATE_MACHINES_AND_LIFECYCLES.md` | State Machines And Lifecycles | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/18_STATE_MACHINES_AND_LIFECYCLES.md` |
| 0023 | `0023_DATA_FLOW_ARCHITECTURE.md` | Data Flow Architecture | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/19_DATA_FLOW_ARCHITECTURE.md` |
| 0024 | `0024_PROVIDERS_AND_INTEGRATIONS.md` | Providers And Integrations | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/20_PROVIDERS_AND_INTEGRATIONS.md` |
| 0025 | `0025_LIVE_DEMO_MOCK_REPLAY_DATA.md` | Live Demo Mock Replay Data | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/21_LIVE_DEMO_MOCK_REPLAY_DATA.md` |
| 0026 | `0026_CONFIGURATION_AND_ENVIRONMENT.md` | Configuration And Environment | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/22_CONFIGURATION_AND_ENVIRONMENT.md` |
| 0027 | `0027_SECURITY_ARCHITECTURE.md` | Security Architecture | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/23_SECURITY_ARCHITECTURE.md` |
| 0028 | `0028_ERROR_HANDLING_AND_EDGE_CASES.md` | Error Handling And Edge Cases | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/24_ERROR_HANDLING_AND_EDGE_CASES.md` |
| 0029 | `0029_RUNTIME_ARCHITECTURE.md` | Runtime Architecture | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/25_RUNTIME_ARCHITECTURE.md` |
| 0030 | `0030_INSTALLATION_BUILD_AND_OPERATION.md` | Installation Build And Operation | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/26_INSTALLATION_BUILD_AND_OPERATION.md` |
| 0031 | `0031_TESTING_AND_QA_BLUEPRINT.md` | Testing And Qa Blueprint | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/27_TESTING_AND_QA_BLUEPRINT.md` |
| 0032 | `0032_REPOSITORY_AND_MODULE_MAP.md` | Repository And Module Map | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/28_REPOSITORY_AND_MODULE_MAP.md` |
| 0033 | `0033_DEPENDENCY_MAP.md` | Dependency Map | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/29_DEPENDENCY_MAP.md` |
| 0034 | `0034_TARGET_PRODUCT_CONTRACT.md` | Target Product Contract | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/30_TARGET_PRODUCT_CONTRACT.md` |
| 0035 | `0035_FIGMA_DESIGN_SPECIFICATION.md` | Figma Design Specification | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/31_FIGMA_HANDOFF.md` |
| 0036 | `0036_CONTRADICTIONS_AND_DESIGN_RESOLUTIONS.md` | Contradictions And Design Resolutions | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/32_CONTRADICTIONS_AND_DESIGN_RESOLUTIONS.md` |
| 0037 | `0037_REQUIREMENTS_TRACEABILITY_MATRIX.md` | Requirements Traceability Matrix | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/33_REQUIREMENTS_TRACEABILITY_MATRIX.md` |
| 0038 | `0038_RECONSTRUCTION_MASTER_PLAN.md` | Reconstruction Master Plan | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/34_RECONSTRUCTION_MASTER_PLAN.md` |
| 0039 | `0039_ANTI_HALLUCINATION_VERIFICATION.md` | Anti Hallucination Verification | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/35_ANTI_HALLUCINATION_VERIFICATION.md` |
| 0040 | `0040_COMPLETE_MASTER_BLUEPRINT.md` | Complete Master Blueprint | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/36_COMPLETE_MASTER_BLUEPRINT.md` |
| 0041 | `0041_AI_TRADING_DESK.md` | Ai Trading Desk | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/37_AI_TRADING_DESK.md` |
| 0042 | `0042_AI_PROVIDER_GATEWAY.md` | Ai Provider Gateway | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/38_AI_PROVIDER_GATEWAY.md` |
| 0043 | `0043_SKILL_CONTROL_PLANE.md` | Skill Control Plane | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/39_SKILL_CONTROL_PLANE.md` |
| 0044 | `0044_CONTEXT_MEMORY_KNOWLEDGE.md` | Context Memory Knowledge | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/40_CONTEXT_MEMORY_KNOWLEDGE.md` |
| 0045 | `0045_MOTION_AND_INTERACTION_SYSTEM.md` | Motion And Interaction System | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/41_MOTION_AND_INTERACTION_SYSTEM.md` |
| 0046 | `0046_TERMUX_PHONE_RUNTIME.md` | Termux Phone Runtime | `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/42_TERMUX_PHONE_RUNTIME.md` |
| 0047 | `0047_ATM_MASTER_BLUEPRINT.md` | Atm Master Blueprint | `ATM_EXPERIMENTAL_INTEGRATION/01_MASTER_BLUEPRINT.md` |
| 0048 | `0048_ATM_AUTHORITY_SCOPE_AND_IMPLEMENTATION_BOUNDARY.md` | Atm Authority Scope And Implementation Boundary | `ATM_EXPERIMENTAL_INTEGRATION/02_AUTHORITY_SCOPE_AND_NO_CODE_BOUNDARY.md` |
| 0049 | `0049_ATM_SOURCE_BASELINE_AND_CURRENT_IMPLEMENTATION_TRUTH.md` | Atm Source Baseline And Current Implementation Truth | `ATM_EXPERIMENTAL_INTEGRATION/03_SOURCE_BASELINE_AND_CURRENT_IMPLEMENTATION_TRUTH.md` |
| 0050 | `0050_ATM_INTEGRATION_ARCHITECTURE.md` | Atm Integration Architecture | `ATM_EXPERIMENTAL_INTEGRATION/04_ATM_INTEGRATION_ARCHITECTURE.md` |
| 0051 | `0051_ATM_CANONICAL_RULEBOOK_V2.md` | Atm Canonical Rulebook V2 | `ATM_EXPERIMENTAL_INTEGRATION/05_ATM_CANONICAL_RULEBOOK_V2.md` |
| 0052 | `0052_ATM_DECISION_CLOSURE_AND_FEATURE_FLAGS.md` | Atm Decision Closure And Feature Flags | `ATM_EXPERIMENTAL_INTEGRATION/06_DECISION_CLOSURE_AND_FEATURE_FLAGS.md` |
| 0053 | `0053_ATM_DATA_CONTRACTS_AND_CROSS_FIELD_VALIDATION.md` | Atm Data Contracts And Cross Field Validation | `ATM_EXPERIMENTAL_INTEGRATION/07_DATA_CONTRACTS_AND_CROSS_FIELD_VALIDATION.md` |
| 0054 | `0054_ATM_CONTENT_IDENTITY_AND_DETERMINISM.md` | Atm Content Identity And Determinism | `ATM_EXPERIMENTAL_INTEGRATION/08_CONTENT_IDENTITY_AND_DETERMINISM.md` |
| 0055 | `0055_ATM_HISTORICAL_DERIVATIVES_DATA_PLAN.md` | Atm Historical Derivatives Data Plan | `ATM_EXPERIMENTAL_INTEGRATION/09_HISTORICAL_DERIVATIVES_DATA_PLAN.md` |
| 0056 | `0056_ATM_API_BLUEPRINT.md` | Atm Api Blueprint | `ATM_EXPERIMENTAL_INTEGRATION/10_API_BLUEPRINT.md` |
| 0057 | `0057_ATM_DATABASE_AND_MIGRATION_BLUEPRINT.md` | Atm Database And Migration Blueprint | `ATM_EXPERIMENTAL_INTEGRATION/11_DATABASE_AND_MIGRATION_BLUEPRINT.md` |
| 0058 | `0058_ATM_STATE_MACHINES_AND_LIFECYCLES.md` | Atm State Machines And Lifecycles | `ATM_EXPERIMENTAL_INTEGRATION/12_STATE_MACHINES_AND_LIFECYCLES.md` |
| 0059 | `0059_ATM_SCANNER_DECISION_RISK_REDTEAM_INTEGRATION.md` | Atm Scanner Decision Risk Redteam Integration | `ATM_EXPERIMENTAL_INTEGRATION/13_SCANNER_DECISION_RISK_REDTEAM_INTEGRATION.md` |
| 0060 | `0060_ATM_BACKTEST_REPLAY_PAPER_RESEARCH_BLUEPRINT.md` | Atm Backtest Replay Paper Research Blueprint | `ATM_EXPERIMENTAL_INTEGRATION/14_BACKTEST_REPLAY_PAPER_RESEARCH_BLUEPRINT.md` |
| 0061 | `0061_ATM_UI_UX_BLUEPRINT.md` | Atm Ui Ux Blueprint | `ATM_EXPERIMENTAL_INTEGRATION/15_UI_UX_BLUEPRINT.md` |
| 0062 | `0062_ATM_SECURITY_THREAT_MODEL_AND_FORBIDDEN_SURFACES.md` | Atm Security Threat Model And Forbidden Surfaces | `ATM_EXPERIMENTAL_INTEGRATION/16_SECURITY_THREAT_MODEL_AND_FORBIDDEN_SURFACES.md` |
| 0063 | `0063_ATM_TEST_IMPLEMENTATION_BLUEPRINT.md` | Atm Test Implementation Blueprint | `ATM_EXPERIMENTAL_INTEGRATION/17_TEST_IMPLEMENTATION_BLUEPRINT.md` |
| 0064 | `0064_ATM_SEMANTIC_VERIFIER_AND_MUTATION_PLAN.md` | Atm Semantic Verifier And Mutation Plan | `ATM_EXPERIMENTAL_INTEGRATION/18_SEMANTIC_VERIFIER_AND_MUTATION_PLAN.md` |
| 0065 | `0065_ATM_CI_CD_RELEASE_AND_DEPLOYMENT_BLUEPRINT.md` | Atm Ci Cd Release And Deployment Blueprint | `ATM_EXPERIMENTAL_INTEGRATION/19_CI_CD_RELEASE_AND_DEPLOYMENT_BLUEPRINT.md` |
| 0066 | `0066_ATM_TRACEABILITY_AND_ACCEPTANCE_MATRIX.md` | Atm Traceability And Acceptance Matrix | `ATM_EXPERIMENTAL_INTEGRATION/20_TRACEABILITY_AND_ACCEPTANCE_MATRIX.md` |
| 0067 | `0067_ATM_OPEN_RISKS_AND_OWNER_DECISIONS.md` | Atm Open Risks And Owner Decisions | `ATM_EXPERIMENTAL_INTEGRATION/22_OPEN_RISKS_AND_OWNER_DECISIONS.md` |
| 0068 | `0068_ATM_STATUS_AND_TRUTHFUL_CLAIMS.md` | Atm Status And Truthful Claims | `ATM_EXPERIMENTAL_INTEGRATION/23_STATUS_AND_TRUTHFUL_CLAIMS.md` |
| 0069 | `0069_ATM_SOURCE_REGISTER.md` | Atm Source Register | `ATM_EXPERIMENTAL_INTEGRATION/24_SOURCE_REGISTER.md` |
| 0070 | `0070_ATM_CHANGE_IMPACT_MAP.md` | Atm Change Impact Map | `ATM_EXPERIMENTAL_INTEGRATION/26_CHANGE_IMPACT_MAP.md` |
| 0071 | `0071_AI_TRADING_DESK_AGNO_AGENTOS_AGUI_ARCHITECTURE.md` | Ai Trading Desk Agno Agentos Agui Architecture | `blueprints/ai-trading-desk/source-material/46_AI_TRADING_DESK_AGNO_AGENTOS_AGUI_ARCHITECTURE.md` |
| 0072 | `0072_AI_AGENT_ROSTER_SIX_AGENTS_AND_AUTHORITY.md` | Ai Agent Roster Six Agents And Authority | `blueprints/ai-trading-desk/source-material/47_AI_AGENT_ROSTER_SIX_AGENTS_AND_AUTHORITY.md` |
| 0073 | `0073_AI_DESK_DETERMINISTIC_TOOL_REGISTRY_AND_PERMISSION_MODEL.md` | Ai Desk Deterministic Tool Registry And Permission Model | `blueprints/ai-trading-desk/source-material/48_DETERMINISTIC_TOOL_REGISTRY_AND_PERMISSION_MODEL.md` |
| 0074 | `0074_AI_PROVIDER_REGISTRY_AND_ANY_MODEL_ROUTING.md` | Ai Provider Registry And Any Model Routing | `blueprints/ai-trading-desk/source-material/49_AI_PROVIDER_REGISTRY_AND_ANY_MODEL_ROUTING.md` |
| 0075 | `0075_AI_DESK_INTELLIGENT_MEMORY_SESSIONS_KNOWLEDGE_AND_RECALL.md` | Ai Desk Intelligent Memory Sessions Knowledge And Recall | `blueprints/ai-trading-desk/source-material/50_INTELLIGENT_MEMORY_SESSIONS_KNOWLEDGE_AND_RECALL.md` |
| 0076 | `0076_AI_DESK_WEB_RESEARCH_NEWS_AND_FUTURES_CHAT_EXPERIENCE.md` | Ai Desk Web Research News And Futures Chat Experience | `blueprints/ai-trading-desk/source-material/51_WEB_RESEARCH_NEWS_AND_FUTURES_CHAT_EXPERIENCE.md` |
| 0077 | `0077_AI_DESK_TERMUX_ANDROID_RUNTIME_ARCHITECTURE.md` | Ai Desk Termux Android Runtime Architecture | `blueprints/ai-trading-desk/source-material/52_TERMUX_ANDROID_RUNTIME_ARCHITECTURE.md` |
| 0078 | `0078_AI_DESK_PHONE_PROVIDER_SECRETS_AND_API_KEY_SECURITY.md` | Ai Desk Phone Provider Secrets And Api Key Security | `blueprints/ai-trading-desk/source-material/53_PHONE_PROVIDER_SECRETS_AND_API_KEY_SECURITY.md` |
| 0079 | `0079_AI_TRADING_DESK_UI_ROUTES_AND_COMPONENTS.md` | Ai Trading Desk Ui Routes And Components | `blueprints/ai-trading-desk/source-material/54_AI_TRADING_DESK_UI_ROUTES_AND_COMPONENTS.md` |
| 0080 | `0080_AI_DESK_AGENTOS_FASTAPI_AGUI_API_AND_EVENT_CONTRACT.md` | Ai Desk Agentos Fastapi Agui Api And Event Contract | `blueprints/ai-trading-desk/source-material/55_AGENTOS_FASTAPI_AGUI_API_AND_EVENT_CONTRACT.md` |
| 0081 | `0081_AI_DESK_SEARCH_MEMORY_AND_TOOL_SECURITY_TESTS.md` | Ai Desk Search Memory And Tool Security Tests | `blueprints/ai-trading-desk/source-material/56_AI_DESK_SEARCH_MEMORY_AND_TOOL_SECURITY_TESTS.md` |
| 0082 | `0082_AI_DESK_TERMUX_INSTALL_RUN_UPDATE_BACKUP_AND_RECOVERY_PLAN.md` | Ai Desk Termux Install Run Update Backup And Recovery Plan | `blueprints/ai-trading-desk/source-material/57_TERMUX_INSTALL_RUN_UPDATE_BACKUP_AND_RECOVERY_PLAN.md` |
| 0083 | `0083_AI_DESK_RESEARCH_VERIFICATION_NOTES.md` | Ai Desk Research Verification Notes | `blueprints/ai-trading-desk/source-material/59_AI_DESK_RESEARCH_VERIFICATION_NOTES.md` |
| 0084 | `0084_AI_DESK_CONTEXT_ENGINE_AGENT_LOOP_SELF_CHECK_AND_TASK_PLANNING.md` | Ai Desk Context Engine Agent Loop Self Check And Task Planning | `blueprints/ai-trading-desk/source-material/60_CONTEXT_ENGINE_AGENT_LOOP_SELF_CHECK_AND_TASK_PLANNING.md` |
| 0085 | `0085_AI_DESK_EVALUATION_CALIBRATION_FEEDBACK_AND_EXPERIENCE_ENGINE.md` | Ai Desk Evaluation Calibration Feedback And Experience Engine | `blueprints/ai-trading-desk/source-material/61_EVALUATION_CALIBRATION_FEEDBACK_AND_EXPERIENCE_ENGINE.md` |
| 0086 | `0086_AI_PROVIDER_GATEWAY_INTERNAL_CONTRACT_AND_ADAPTERS.md` | Ai Provider Gateway Internal Contract And Adapters | `blueprints/ai-trading-desk/source-material/62_AI_PROVIDER_GATEWAY_INTERNAL_CONTRACT_AND_ADAPTERS.md` |
| 0087 | `0087_AI_DESK_MODEL_POLICY_ROUTER_CAPABILITY_DETECTION_FAILOVER_AND_PRIVACY.md` | Ai Desk Model Policy Router Capability Detection Failover And Privacy | `blueprints/ai-trading-desk/source-material/63_MODEL_POLICY_ROUTER_CAPABILITY_DETECTION_FAILOVER_AND_PRIVACY.md` |
| 0088 | `0088_AI_DESK_CUSTOM_PROVIDER_UI_MODEL_DISCOVERY_AND_PROVIDER_LIFECYCLE.md` | Ai Desk Custom Provider Ui Model Discovery And Provider Lifecycle | `blueprints/ai-trading-desk/source-material/64_CUSTOM_PROVIDER_UI_MODEL_DISCOVERY_AND_PROVIDER_LIFECYCLE.md` |
| 0089 | `0089_AI_DESK_PROVIDER_INDEPENDENT_AGENT_MODEL_BINDING_AND_RUNTIME_SWITCHING.md` | Ai Desk Provider Independent Agent Model Binding And Runtime Switching | `blueprints/ai-trading-desk/source-material/65_PROVIDER_INDEPENDENT_AGENT_MODEL_BINDING_AND_RUNTIME_SWITCHING.md` |
| 0090 | `0090_AI_DESK_TOOL_GATEWAY_MODEL_GATEWAY_SEPARATION_AND_FAILURE_ISOLATION.md` | Ai Desk Tool Gateway Model Gateway Separation And Failure Isolation | `blueprints/ai-trading-desk/source-material/66_TOOL_GATEWAY_MODEL_GATEWAY_SEPARATION_AND_FAILURE_ISOLATION.md` |
| 0091 | `0091_AI_DESK_PROVIDER_GATEWAY_SECURITY_SSRF_SECRETS_AND_DATA_EGRESS.md` | Ai Desk Provider Gateway Security Ssrf Secrets And Data Egress | `blueprints/ai-trading-desk/source-material/67_PROVIDER_GATEWAY_SECURITY_SSRF_SECRETS_AND_DATA_EGRESS.md` |
| 0092 | `0092_AI_DESK_CONTEXT_MEMORY_PROVIDER_AND_AGENT_E2E_TEST_MATRIX.md` | Ai Desk Context Memory Provider And Agent E2E Test Matrix | `blueprints/ai-trading-desk/source-material/68_CONTEXT_MEMORY_PROVIDER_AND_AGENT_E2E_TEST_MATRIX.md` |
| 0093 | `0093_SKILL_CONTROL_PLANE_OVERVIEW.md` | Skill Control Plane Overview | `blueprints/skill-control-plane/source-material/skill_control_plane/00_SKILL_CONTROL_PLANE_OVERVIEW.md` |
| 0094 | `0094_SKILL_LIFECYCLE_VERSIONING_AND_ROLLBACK.md` | Skill Lifecycle Versioning And Rollback | `blueprints/skill-control-plane/source-material/skill_control_plane/01_SKILL_LIFECYCLE_VERSIONING_AND_ROLLBACK.md` |
| 0095 | `0095_SKILL_MANAGER_UI_SPEC.md` | Skill Manager Ui Spec | `blueprints/skill-control-plane/source-material/skill_control_plane/02_SKILL_MANAGER_UI_SPEC.md` |
| 0096 | `0096_SKILL_ROUTING_AND_CONTEXT_LOADING_POLICY.md` | Skill Routing And Context Loading Policy | `blueprints/skill-control-plane/source-material/skill_control_plane/03_SKILL_ROUTING_AND_CONTEXT_LOADING_POLICY.md` |
| 0097 | `0097_SKILL_PERMISSION_AND_AUTHORITY_MATRIX.md` | Skill Permission And Authority Matrix | `blueprints/skill-control-plane/source-material/skill_control_plane/04_SKILL_PERMISSION_AND_AUTHORITY_MATRIX.md` |
| 0098 | `0098_SKILL_IMPACT_ANALYSIS_AND_SAFE_PUBLISH.md` | Skill Impact Analysis And Safe Publish | `blueprints/skill-control-plane/source-material/skill_control_plane/05_SKILL_IMPACT_ANALYSIS_AND_SAFE_PUBLISH.md` |
| 0099 | `0099_SKILL_DATABASE_SCHEMA.md` | Skill Database Schema | `blueprints/skill-control-plane/source-material/skill_control_plane/06_SKILL_DATABASE_SCHEMA.md` |
| 0100 | `0100_SKILL_MANAGER_API_CONTRACT.md` | Skill Manager Api Contract | `blueprints/skill-control-plane/source-material/skill_control_plane/07_SKILL_MANAGER_API_CONTRACT.md` |
| 0101 | `0101_SKILL_TEST_AND_EVALUATION_GATES.md` | Skill Test And Evaluation Gates | `blueprints/skill-control-plane/source-material/skill_control_plane/08_SKILL_TEST_AND_EVALUATION_GATES.md` |
| 0102 | `0102_SKILL_CONTROL_GENERAL_150_SKILLS_ISOLATION_POLICY.md` | Skill Control General 150 Skills Isolation Policy | `blueprints/skill-control-plane/source-material/skill_control_plane/09_GENERAL_150_SKILLS_ISOLATION_POLICY.md` |
| 0103 | `0103_SKILL_CONTROL_OWNER_SAFE_CONTROL_RULES.md` | Skill Control Owner Safe Control Rules | `blueprints/skill-control-plane/source-material/skill_control_plane/10_OWNER_SAFE_CONTROL_RULES.md` |
| 0104 | `0104_SKILL_CONTROL_DEFAULT_SIGNAL_DESK_SKILL_PROFILE.md` | Skill Control Default Signal Desk Skill Profile | `blueprints/skill-control-plane/source-material/skill_control_plane/DEFAULT_SIGNAL_DESK_SKILL_PROFILE.json` |
| 0105 | `0105_SKILL_REGISTRY.md` | Skill Registry | `blueprints/skill-control-plane/source-material/skill_control_plane/SKILL_REGISTRY.json` |
| 0106 | `0106_SKILL_CONTROL_SYSTEM_POLICY_LOCKS.md` | Skill Control System Policy Locks | `blueprints/skill-control-plane/source-material/skill_control_plane/SYSTEM_POLICY_LOCKS.json` |
| 0107 | `0107_COMPLETE_TEST_SPECIFICATION_CATALOG.md` | Complete Test Specification Catalog | `0038_TEST_SPECIFICATIONS_VOLUME_01.md` |
