# Skill routing and context loading

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/03_SKILL_ROUTING_AND_CONTEXT_LOADING_POLICY.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Do not load all 166 skills

The Supervisor receives only compact registry metadata.

The router selects the smallest sufficient skill set.

Only selected skills' full published instructions are loaded into the task context.

## Routing inputs

- user intent;
- current page;
- selected symbol;
- instrument class;
- runtime mode;
- requested horizon;
- required tools;
- risk state;
- data availability;
- profile;
- agent role.

## Example

User:
`Analyze SOLUSDT and explain whether there is a strong paper setup.`

Possible route:

```text
market-snapshot-builder
data-freshness-coherence
multi-timeframe-analysis
trend-regime-analysis
ema-analysis
vwap-analysis
rsi-analysis
macd-analysis
atr-volatility-analysis
market-structure-bos-choch
volume-analysis
crypto-perpetual-futures
funding-rate-analysis
open-interest-analysis
derivatives-crowding-composite
deterministic-signal-engine
strategy-validation
risk-engine
decision-card-integrity
Evidence Agent
Red Team
```

The router may omit any skill that is unnecessary.

## Conflict law

Priority:

1. system policies;
2. deterministic engine results;
3. active profile configuration;
4. published skill instructions;
5. agent narrative.

A skill prompt cannot override a higher layer.
