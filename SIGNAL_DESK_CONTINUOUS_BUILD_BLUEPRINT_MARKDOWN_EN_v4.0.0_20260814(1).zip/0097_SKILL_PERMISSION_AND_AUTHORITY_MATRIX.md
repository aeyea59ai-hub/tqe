# Skill permission and authority matrix

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/04_SKILL_PERMISSION_AND_AUTHORITY_MATRIX.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

| Class | May read deterministic facts | May call read tools | May call compute tools | May request paper write | May alter risk | May alter system policy |
|---|---:|---:|---:|---:|---:|---:|
| ENGINE_BACKED | yes | yes | service-owned | no | no | no |
| ENGINE_BACKED_ANALYSIS | yes | yes | through tools | no | no | no |
| DETERMINISTIC_ENGINE | yes | internal | yes | service-owned | policy-bound | no |
| AI_REASONING | yes | yes | request tools | proposal only | no | no |
| QA_GUARD | yes | yes | test-only | no | no | no |
| ADMIN_AI | scoped | scoped | scoped | no | no | no |
| OPTIONAL_MARKET_SKILL | profile-dependent | scoped | scoped | no | no | no |

## Root permission rule

Prompts do not grant permissions.

Permissions live in server-side configuration and code.

Changing text like “you may call X” does not make X callable unless the Tool Gateway binding permits it.
