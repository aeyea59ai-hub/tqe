# 65 — Provider-Independent Agent/Model Binding and Runtime Switching

> **Source basis:** `blueprints/ai-trading-desk/source-material/65_PROVIDER_INDEPENDENT_AGENT_MODEL_BINDING_AND_RUNTIME_SWITCHING.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Principle

Agent configuration and model configuration are separate entities.

## AgentConfig

```text
agent_id
role
system_prompt_version
tool_permissions
memory_policy
context_policy
output_schema
guardrails
evaluation_policy
model_policy_id
```

## ModelPolicy

```text
policy_id
routing_mode
preferred_provider
preferred_model
fallbacks
privacy_class
required_capabilities
cost_limit
latency_limit
```

## Runtime switching

The user may change:

```text
Market Analyst:
Kimi
  ↓
Qwen Local
  ↓
Ollama Cloud
```

without changing:
- prompt;
- tools;
- memory;
- permissions;
- role;
- trace identity.

## Session behavior

Each agent run records the actual provider/model selected.

Switching a provider mid-session must not rewrite historical turns.

## Agent Settings UI

```text
AGENTS

Supervisor
Provider Policy: [AUTO ▼]
Model: [AUTO ▼]

Research
Provider Policy: [Kimi ▼]
Model: [model ▼]

Market Analyst
Provider Policy: [AUTO ▼]

Strategy Analyst
Provider Policy: [BEST QUALITY ▼]

Evidence
Provider Policy: [STRICT STRUCTURED ▼]

Red Team
Provider Policy: [DIFFERENT MODEL PREFERRED ▼]
```

## Provider outage

If the current model fails:
- apply policy;
- choose permitted fallback;
- continue only if capability/privacy requirements still hold;
- log failover;
- otherwise return MODEL_UNAVAILABLE.

Deterministic platform features continue regardless.
