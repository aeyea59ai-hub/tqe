# 68 — Context, Memory, Provider, and Agent E2E Test Matrix

> **Source basis:** `blueprints/ai-trading-desk/source-material/68_CONTEXT_MEMORY_PROVIDER_AND_AGENT_E2E_TEST_MATRIX.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Context Engine

- current page resolves pronouns safely;
- selected symbol changes context;
- stale UI symbol does not override explicit user symbol;
- relevant memory retrieved, unrelated memory excluded;
- risk locks included;
- current runtime mode included;
- context size remains bounded.

## Agent loop

- plan exists before high-cost execution;
- tool dependencies execute in valid order;
- tool error causes plan adaptation;
- critical data failure blocks paper proposal;
- self-check runs before final answer;
- manual review state is visible.

## Evaluation / calibration

- closed paper trade creates evaluation record;
- strategy calibration reconciles journal;
- no future-profit claim;
- agent metrics use defined denominators;
- low sample warnings;
- calibration cannot mutate risk automatically.

## Provider Gateway

- add/remove provider;
- switch provider without agent rewrite;
- provider outage fallback;
- LOCAL_ONLY refuses cloud fallback;
- capability mismatch rejected;
- structured-output requirement enforced;
- model history preserves actual provider/model.

## Custom provider

- valid endpoint;
- invalid endpoint;
- auth failure;
- model not found;
- incompatible tool format;
- incompatible streaming;
- incompatible structured output;
- SSRF attempt;
- redirect to forbidden network;
- TLS failure.

## AI-independent operation

With all AI providers disabled:
- scanner works;
- chart works;
- strategies work;
- risk works;
- backtest works;
- paper works;
- journal works;
- analytics works;
- AI Desk displays model-unavailable state without breaking app.

## Model-independent memory

Create session with Provider A.
Switch to Provider B.
Verify:
- same application session;
- relevant memory remains available;
- historical turns retain original provider metadata;
- no raw provider secret appears.

## Red Team independence

Where configured:
- primary analyst uses model/provider A;
- Red Team uses B;
- if B unavailable, policy behavior is explicit;
- deterministic risk remains final authority.
