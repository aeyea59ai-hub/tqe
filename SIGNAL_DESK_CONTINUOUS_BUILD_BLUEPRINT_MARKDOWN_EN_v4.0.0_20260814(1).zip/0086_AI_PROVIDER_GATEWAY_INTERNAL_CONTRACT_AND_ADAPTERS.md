# 62 — AI Provider Gateway, Internal Contract, and Adapters

> **Source basis:** `blueprints/ai-trading-desk/source-material/62_AI_PROVIDER_GATEWAY_INTERNAL_CONTRACT_AND_ADAPTERS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Core principle

Agents belong to SIGNAL DESK.

Models are replaceable engines.

Do not create:
- OpenAI Agent
- Kimi Agent
- Ollama Agent

Create:
- Supervisor Agent
- Research Agent
- Market Analyst
- Strategy Analyst
- Evidence Agent
- Red Team

Each agent is independent of the model vendor.

## Architecture

```text
SIGNAL DESK
   │
AI TRADING DESK
   │
AGENT ENGINE
   │
MODEL POLICY ROUTER
   │
AI PROVIDER GATEWAY
   │
   ├── Ollama Local
   ├── Ollama Cloud
   ├── Kimi / Moonshot
   ├── OpenAI
   ├── Anthropic
   ├── Gemini
   ├── Groq
   ├── DeepSeek
   ├── OpenRouter
   └── Custom Compatible Provider
```

## Internal provider contract

Do not make the application depend directly on one vendor SDK contract.

Conceptual interface:

```ts
interface AIProvider {
  id: string;
  name: string;

  listModels(): Promise<ModelInfo[]>;
  healthCheck(): Promise<ProviderHealth>;

  generate(request: AIRequest): Promise<AIResponse>;
  stream?(request: AIRequest): AsyncIterable<AIEvent>;

  getCapabilities(modelId: string): Promise<ModelCapabilities>;
}
```

## Internal request contract

```text
request_id
agent_id
task_type
messages
structured_context
tool_schemas
response_schema
provider_policy
privacy_class
max_output_tokens
timeout
stream
```

## Internal response contract

```text
provider_id
model_id
request_id
content
structured_output
tool_calls
usage
latency
finish_reason
warnings
raw_provider_metadata_sanitized
```

## Adapter directory

Conceptual:

```text
providers/
├── ollama_local/
├── ollama_cloud/
├── kimi/
├── openai/
├── anthropic/
├── gemini/
├── groq/
├── deepseek/
├── openrouter/
└── custom_compatible/
```

## Compatibility rule

“OpenAI-compatible” does not mean feature-identical.

Adapters normalize differences in:
- tool calls;
- streaming;
- structured output;
- reasoning fields;
- multimodal input;
- errors;
- token usage;
- model discovery;
- response semantics.

## Independence guarantee

Deleting a provider must not delete or change:
- agent prompts;
- agent roles;
- agent memory;
- tool permissions;
- trading tools;
- Risk Engine;
- Scanner;
- Journal;
- Evaluation history.

The only change is model routing.
