# 36 - COMPLETE MASTER BLUEPRINT

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/36_COMPLETE_MASTER_BLUEPRINT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

This is the standalone developer contract for SIGNAL DESK. It contains the full target product, new UI/UX direction, architecture, business rules, data contracts, AI/skill systems, runtime and implementation plan. It intentionally omits current-project status/history.


---

# INCLUDED: 01_START_HERE.md

# 01 - Start Here

## Delivery intent
SIGNAL DESK is a local-first crypto futures intelligence, strategy research, deterministic decision, risk-control and paper-trading workstation. It is not a live-execution terminal. Public market data and deterministic domain code own prices, indicators, strategy pass/fail, evidence score, sizing, leverage, liquidation safety, fees, funding, slippage, paper fills, journal accounting and analytics. AI is an optional advisory layer that can research, interpret, critique, orchestrate tools and explain evidence without becoming numeric market truth. The product is designed as one owner-operated Web/PWA application with an Android/Termux-compatible runtime profile.

## Owner override
This package is a target development contract, not a reverse-engineering report. It deliberately omits historical/current-project narration. Functional scope and safety are preserved, while information architecture, visual design, interaction patterns and motion are newly specified.

## Visual direction
The target visual system is intentionally different from the earlier dense panel/card approach. The new direction, **Quiet Grid Terminal**, uses an open dark canvas, one thin navigation rail, one context bar, table-first information, a single contextual inspector and restrained semantic color. Major pages avoid nested cards. Detail appears in drawers/sheets instead of permanent columns. Motion is short and functional: 110-220 ms, no bounce, no glow loops, no decorative parallax. The primary interaction is symbol/context continuity plus a command palette.

## Reading order
1. 02 Application Overview
2. 03 Product Requirements
3. 07 Screen and Route Catalog
4. 09 Design System
5. 17 Business Logic and Algorithms
6. 23 Security
7. 37-42 AI/Skills/Motion/Termux
8. 34 Reconstruction Master Plan
9. 44 Build Execution Controller
10. 36 Complete Master Blueprint for one-file handoff

## Authority order
1. Owner safety and scope constraints in this package.
2. Machine-readable contracts under `CONTRACTS/`.
3. Numbered Blueprint files.
4. Starter code contracts.
5. Visual mockups.

A visual mockup never overrides a business rule. A prompt never overrides a server-side permission. AI never overrides deterministic risk.


---

# INCLUDED: 02_APPLICATION_OVERVIEW.md

# 02 - Application Overview

SIGNAL DESK is a local-first crypto futures intelligence, strategy research, deterministic decision, risk-control and paper-trading workstation. It is not a live-execution terminal. Public market data and deterministic domain code own prices, indicators, strategy pass/fail, evidence score, sizing, leverage, liquidation safety, fees, funding, slippage, paper fills, journal accounting and analytics. AI is an optional advisory layer that can research, interpret, critique, orchestrate tools and explain evidence without becoming numeric market truth. The product is designed as one owner-operated Web/PWA application with an Android/Termux-compatible runtime profile.

## Product domains
- Market truth and data quality
- Deterministic indicators and market structure
- Scanner and candidate ranking
- Versioned strategy engine
- Decision cards, evidence and Red Team
- Deterministic risk and portfolio controls
- Paper orders, fills, positions and journal
- Backtest, replay, analytics and calibration
- AI Trading Desk with six top-level agents
- Provider Gateway, Tool Gateway, Memory, Skills and Traces
- Local operations, alerts, audit, backup and offline demo

## Safety boundary
There is no live order capability in the base product. Private exchange keys, signed order requests, withdrawals and transfers are outside the application contract.

## Architecture
```mermaid
flowchart LR
  UI["React Web/PWA"] --> API["FastAPI REST + WebSocket"]
  API --> Domain["Deterministic Domain Services"]
  Domain --> DB["SQLite + Alembic"]
  Domain --> Market["Public Market Adapters"]
  Domain --> Scheduler["Scheduler / Jobs"]
  UI --> AgentUI["AI Desk / AG-UI"]
  AgentUI --> AgentRuntime["Agent Runtime"]
  AgentRuntime --> ToolGW["Tool Gateway"]
  ToolGW --> Domain
  AgentRuntime --> ModelRouter["Model Policy Router"]
  ModelRouter --> ProviderGW["AI Provider Gateway"]
  ProviderGW --> Models["Local / Cloud Models"]
```


---

# INCLUDED: 03_PRODUCT_REQUIREMENTS.md

# 03 - Product Requirements

| ID | Title | Category | Priority | Lock | Requirement |
| --- | --- | --- | --- | --- | --- |
| REQ-001 | Local Owner Authentication | Foundation | P0 | LOCKED | Single-owner local session protection. First setup creates owner credential; writes require authenticated session and CSRF. |
| REQ-002 | Runtime Profiles | Foundation | P0 | LOCKED | Explicit DEMO, REPLAY, LIVE_PUBLIC, TEST and SOAK separation. No profile may silently masquerade as another profile. |
| REQ-003 | Arabic/English RTL/LTR | Foundation | P1 | CONFIGURABLE_WITH_VERSIONING | Bilingual UI with numeric/ticker isolation. Arabic layout RTL; market symbols, prices and timestamps remain LTR. |
| REQ-004 | Command Palette | UX | P2 | CONFIGURABLE_WITH_VERSIONING | Fast page/symbol/action navigation. Read-only actions may execute directly; write actions open their normal confirmation flow. |
| REQ-005 | Workspace Layout Preferences | UX | P2 | CONFIGURABLE_WITH_VERSIONING | Persist owner layout and density preferences. Corrupt preference data resets safely without affecting domain records. |
| REQ-006 | Dynamic Futures Universe | Market | P0 | LOCKED | Discover eligible public USD-margined perpetual instruments. Eligibility is derived from provider metadata; delisted/ineligible instruments cannot publish. |
| REQ-007 | Market Snapshot | Market | P0 | LOCKED | Create immutable coherent snapshot for analysis. Critical fields must meet freshness/coherence rules. |
| REQ-008 | Closed Candle Pipeline | Market | P0 | LOCKED | Use only finalized candles for decisions. Forming candles may display but never enter authoritative calculations. |
| REQ-009 | Candlestick Chart | Market | P1 | CONFIGURABLE_WITH_VERSIONING | Price/volume chart with overlays and decision geometry. Chart visuals do not own calculations. |
| REQ-010 | Indicator Engine | Market | P0 | LOCKED | EMA, RSI, MACD, ATR, VWAP and volume features. All values deterministic and versioned. |
| REQ-011 | Market Structure | Market | P0 | LOCKED | HH/HL/LH/LL, pivots, BOS/CHoCH, zones and sweeps. Confirmed-pivot rules must be non-repainting. |
| REQ-012 | Funding Context | Derivatives | P1 | CONFIGURABLE_WITH_VERSIONING | Display and evaluate funding. Funding is evidence, not standalone trade authority. |
| REQ-013 | Open Interest Context | Derivatives | P1 | CONFIGURABLE_WITH_VERSIONING | Display OI level/change and price-OI relationship. Stale OI cannot support a decision. |
| REQ-014 | Liquidity & Depth | Derivatives | P1 | CONFIGURABLE_WITH_VERSIONING | Spread/depth/liquidity evidence and paper-fill support. Insufficient depth blocks final paper approval when required. |
| REQ-015 | Market Breadth & Heatmap | Market | P2 | CONFIGURABLE_WITH_VERSIONING | Cross-universe market context. Derived from eligible universe and current snapshots. |
| REQ-016 | Staged Scanner | Scanner | P0 | LOCKED | Deterministic multi-stage full-universe scanning. Every exclusion reason must be visible and auditable. |
| REQ-017 | Scanner Ranking | Scanner | P0 | LOCKED | Rank candidates by deterministic score and tie-breaks. Same inputs/config produce same ordering. |
| REQ-018 | Manual & Scheduled Scan | Scanner | P1 | CONFIGURABLE_WITH_VERSIONING | Owner-triggered and scheduled scans. Only one effective scheduler instance per job. |
| REQ-019 | Evidence Score | Decision | P0 | LOCKED | Eight-factor deterministic evidence score. Missing optional data cannot increase score; degraded cap enforced. |
| REQ-020 | Decision Card | Decision | P0 | LOCKED | Immutable complete decision object. Card pins versions, evidence, risk, provenance and integrity hash. |
| REQ-021 | Decision Lifecycle | Decision | P0 | LOCKED | Track create/watch/reject/publish/expire/invalidate states. Invalid transitions rejected and audited. |
| REQ-022 | Red Team R1-R6 | Decision | P0 | LOCKED | Deterministic veto/objection layer. Hard objections are non-overridable. |
| REQ-023 | Six-Agent Council | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Supervisor, Research, Market, Strategy, Evidence, Red Team. Agents are advisory; deterministic services own numbers and final hard gates. |
| REQ-024 | Strategy Registry | Strategies | P0 | LOCKED | Versioned strategy inventory and eligibility. Research-only strategies cannot publish. |
| REQ-025 | Primary Strategies | Strategies | P0 | LOCKED | S01, S02, S03, S07 and S14. Numeric rules and versions are immutable once published. |
| REQ-026 | Research Strategies | Strategies | P1 | CONFIGURABLE_WITH_VERSIONING | SC01-SC08 isolated experimentation. Status RESEARCH_ONLY; no publication/paper promotion without governance. |
| REQ-027 | Strategy Draft & Validation | Strategies | P1 | CONFIGURABLE_WITH_VERSIONING | Edit drafts and validate schema/rules before publish. Published versions are immutable. |
| REQ-028 | Backtesting | Research | P0 | LOCKED | Reproducible event-driven historical evaluation. No lookahead; dataset manifest/cost model pinned. |
| REQ-029 | Replay | Research | P1 | CONFIGURABLE_WITH_VERSIONING | Step historical data through current engines. Replay mode never labels data live. |
| REQ-030 | Strategy Performance | Research | P1 | CONFIGURABLE_WITH_VERSIONING | Performance metrics by strategy/regime/symbol/side. Every metric shows sample size and cost assumptions. |
| REQ-031 | Position Sizing | Risk | P0 | LOCKED | Compute quantity from equity, risk and stop distance. Decimal precision and exchange step constraints enforced. |
| REQ-032 | Leverage Gate | Risk | P0 | LOCKED | Cap leverage by side/policy. LONG <=5x; SHORT <=3x under v1.0. |
| REQ-033 | Liquidation Safety | Risk | P0 | LOCKED | Modeled liquidation-distance safety gate. Minimum liquidation distance = 3x stop distance or block. |
| REQ-034 | Effective R Gate | Risk | P0 | LOCKED | Require cost-adjusted blended reward/risk. Minimum 2.0 effective blended R. |
| REQ-035 | Daily/Weekly Locks | Risk | P0 | LOCKED | Stop new paper approvals after loss limits. Daily -2R; weekly -6R. |
| REQ-036 | Loss Reducer | Risk | P0 | LOCKED | Reduce risk after two realized losses. Risk becomes 0.25% until next realized win. |
| REQ-037 | Calibration Risk | Risk | P0 | LOCKED | Reduce risk for first 30 closed paper trades. 0.25% risk through first 30 closed trades. |
| REQ-038 | Correlation Gate | Risk | P0 | LOCKED | Limit highly correlated concurrent positions. Maximum two BTC-correlated positions under active policy. |
| REQ-039 | Paper Preview & Confirmation | Paper | P0 | LOCKED | Preview exact deterministic paper order before owner confirmation. Confirmation uses hash/version binding and cannot call exchange. |
| REQ-040 | Paper Orders/Fills | Paper | P0 | LOCKED | Paper-only order/fill simulation. 50% TP1, move to BE, 50% TP2; no real order path. |
| REQ-041 | Paper Positions | Paper | P0 | LOCKED | Position lifecycle and PnL accounting. Append-only financial events reconcile. |
| REQ-042 | Manual Paper Close | Paper | P1 | CONFIGURABLE_WITH_VERSIONING | Owner closes paper position only. Close creates journaled event and updates locks in same cycle. |
| REQ-043 | Journal Hash Chain | Journal | P0 | LOCKED | Immutable event history and integrity verification. Losses/rejections cannot be deleted; corrections append. |
| REQ-044 | Portfolio & Risk View | Paper | P1 | CONFIGURABLE_WITH_VERSIONING | Equity, exposure, heat, open risk and PnL. Derived from journal/positions, not independent mutable totals. |
| REQ-045 | Analytics V2 | Analytics | P1 | CONFIGURABLE_WITH_VERSIONING | Ledger-derived analytics across multiple dimensions. No synthetic outcome series. |
| REQ-046 | Calibration Analytics | Analytics | P2 | CONFIGURABLE_WITH_VERSIONING | Compare confidence/evidence with realized paper outcomes. Low sample warnings mandatory. |
| REQ-047 | Data Quality Analytics | Analytics | P2 | CONFIGURABLE_WITH_VERSIONING | Measure stale/degraded/missing data impact. Shows denominators and blocked percentage. |
| REQ-048 | Alerts | Operations | P2 | CONFIGURABLE_WITH_VERSIONING | Local alerts for decisions, risk locks, provider/data health. Dedup/cooldown required; external writes disabled in base release. |
| REQ-049 | Daily Brief | Operations | P2 | CONFIGURABLE_WITH_VERSIONING | Daily deterministic/AI-assisted summary. Numeric facts come from deterministic services. |
| REQ-050 | Provider Health | Operations | P1 | CONFIGURABLE_WITH_VERSIONING | Market and AI provider status. Health state must reflect actual checks, never assumed connectivity. |
| REQ-051 | Audit Log | Operations | P0 | LOCKED | Security/config/decision/provider/skill audit trail. Sensitive values redacted. |
| REQ-052 | Backup & Restore | Operations | P1 | CONFIGURABLE_WITH_VERSIONING | Local data/config backup and integrity restore. Secrets excluded; restore validates before switch. |
| REQ-053 | Methodology & Limitations | Operations | P2 | CONFIGURABLE_WITH_VERSIONING | Explain rules, assumptions and known limitations in-app. No profitability promise. |
| REQ-054 | AI Chat | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Evidence-bound conversational interface. Read-only; numeric claims must be grounded or abstained. |
| REQ-055 | Tool Gateway | AI | P0 | LOCKED | Typed permissioned bridge from agents to deterministic services. Prompts cannot grant permissions. |
| REQ-056 | AI Provider Gateway | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Replaceable model-provider abstraction. Provider can be disabled/deleted without changing agents/tools/memory. |
| REQ-057 | Provider Routing Policies | AI | P1 | CONFIGURABLE_WITH_VERSIONING | AUTO/LOCAL_ONLY/QUALITY/COST/SPEED/MANUAL routing. Privacy class constrains fallback. |
| REQ-058 | Custom AI Provider | AI | P2 | CONFIGURABLE_WITH_VERSIONING | Add tested compatible provider. SSRF and capability validation required. |
| REQ-059 | AI Memory | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Session/preferences/research memory. Trading/journal truth stays in domain tables. |
| REQ-060 | Knowledge Base | AI | P2 | CONFIGURABLE_WITH_VERSIONING | Local searchable methodology/strategy/risk docs. Versioned source and freshness metadata. |
| REQ-061 | Skill Registry | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Install and classify skills without auto-routing all of them. Source packs immutable. |
| REQ-062 | Skill Draft/Test/Publish/Rollback | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Safely control skill changes. Edit creates draft; published version immutable. |
| REQ-063 | Skill Traceability | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Show skills used per AI run. Exact version/hash pinned. |
| REQ-064 | Agent Run Traces | AI | P1 | CONFIGURABLE_WITH_VERSIONING | Plan/tool/provider/evidence trace without hidden chain-of-thought. Show structured execution facts only. |
| REQ-065 | Agent Evaluations | AI | P2 | CONFIGURABLE_WITH_VERSIONING | Assess evidence/agent workflow quality. Cannot silently modify risk/strategy. |
| REQ-066 | Web/News Research Adapter | AI | P2 | CONFIGURABLE_WITH_VERSIONING | Optional public research context. External text is untrusted and never market numeric authority. |
| REQ-067 | Offline Demo | Runtime | P0 | LOCKED | Full direct local demo with deterministic fixtures. No network dependency for DEMO. |
| REQ-068 | Termux Runtime | Runtime | P1 | CONFIGURABLE_WITH_VERSIONING | Android-first local operation profile. Loopback-only services; AI failure isolated. |
| REQ-069 | Health/Doctor Tools | Runtime | P1 | CONFIGURABLE_WITH_VERSIONING | Check app, DB, providers, scheduler, disk and runtime. Read-only health checks. |
| REQ-070 | Evidence Export | Operations | P1 | CONFIGURABLE_WITH_VERSIONING | Export decision/audit/test evidence bundle. No secrets; hashes included. |
| REQ-NFR-001 | Deterministic repeatability | NFR | P0 | LOCKED | Same valid input + same versions/configuration must produce the same decision-critical outputs and hashes. |
| REQ-NFR-002 | Fail closed | NFR | P0 | LOCKED | Stale, malformed, non-finite, mixed, future or missing critical data cannot improve evidence or produce paper approval. |
| REQ-NFR-003 | Phone-safe resource bounds | NFR | P1 | LOCKED | All scanner, agent, backtest, log, queue and memory workloads are bounded for Android/Termux operation. |
| REQ-NFR-004 | Accessibility | NFR | P1 | LOCKED | Keyboard, focus, reduced motion, 200% zoom, screen-reader smoke, chart alternatives and mobile widths are mandatory release tests. |
| REQ-NFR-005 | No secret leakage | NFR | P0 | LOCKED | Secrets never enter frontend bundles, logs, memory, journal, exported evidence, skill prompts or release packages. |
| REQ-NFR-006 | Traceable claims | NFR | P0 | LOCKED | Every reported PASS, provider connection, data freshness, test result and AI numeric claim must have evidence. |


---

# INCLUDED: 04_COMPLETE_FEATURE_CATALOG.md

# 04 - Complete Feature Catalog

| ID | Feature | Category | Priority | UI | Modules | Rules |
| --- | --- | --- | --- | --- | --- | --- |
| F001 | Local Owner Authentication | Foundation | P0 | System | Auth/API/DB | First setup creates owner credential; writes require authenticated session and CSRF. |
| F002 | Runtime Profiles | Foundation | P0 | Global | Runtime/Config | No profile may silently masquerade as another profile. |
| F003 | Arabic/English RTL/LTR | Foundation | P1 | Global | Frontend/i18n | Arabic layout RTL; market symbols, prices and timestamps remain LTR. |
| F004 | Command Palette | UX | P2 | Global | Frontend | Read-only actions may execute directly; write actions open their normal confirmation flow. |
| F005 | Workspace Layout Preferences | UX | P2 | Market | Frontend/Storage | Corrupt preference data resets safely without affecting domain records. |
| F006 | Dynamic Futures Universe | Market | P0 | Market/Scan | Market Data | Eligibility is derived from provider metadata; delisted/ineligible instruments cannot publish. |
| F007 | Market Snapshot | Market | P0 | Market | Market Data/Domain | Critical fields must meet freshness/coherence rules. |
| F008 | Closed Candle Pipeline | Market | P0 | Market/Scan | Market Data | Forming candles may display but never enter authoritative calculations. |
| F009 | Candlestick Chart | Market | P1 | Market | Frontend/Chart | Chart visuals do not own calculations. |
| F010 | Indicator Engine | Market | P0 | Market | Domain | All values deterministic and versioned. |
| F011 | Market Structure | Market | P0 | Market | Domain | Confirmed-pivot rules must be non-repainting. |
| F012 | Funding Context | Derivatives | P1 | Market/Scan | Market Data/Domain | Funding is evidence, not standalone trade authority. |
| F013 | Open Interest Context | Derivatives | P1 | Market/Scan | Market Data/Domain | Stale OI cannot support a decision. |
| F014 | Liquidity & Depth | Derivatives | P1 | Market/Paper | Market Data/Domain | Insufficient depth blocks final paper approval when required. |
| F015 | Market Breadth & Heatmap | Market | P2 | Home/Market | Domain/Frontend | Derived from eligible universe and current snapshots. |
| F016 | Staged Scanner | Scanner | P0 | Scan | Scanner/Domain | Every exclusion reason must be visible and auditable. |
| F017 | Scanner Ranking | Scanner | P0 | Scan | Scanner/Domain | Same inputs/config produce same ordering. |
| F018 | Manual & Scheduled Scan | Scanner | P1 | Scan | Scheduler/Scanner | Only one effective scheduler instance per job. |
| F019 | Evidence Score | Decision | P0 | Scan/Decisions | Evidence Engine | Missing optional data cannot increase score; degraded cap enforced. |
| F020 | Decision Card | Decision | P0 | Decisions | Decision Engine/DB | Card pins versions, evidence, risk, provenance and integrity hash. |
| F021 | Decision Lifecycle | Decision | P0 | Decisions | Decision Engine | Invalid transitions rejected and audited. |
| F022 | Red Team R1-R6 | Decision | P0 | Decisions | Red Team | Hard objections are non-overridable. |
| F023 | Six-Agent Council | AI | P1 | AI/Decisions | AI Runtime | Agents are advisory; deterministic services own numbers and final hard gates. |
| F024 | Strategy Registry | Strategies | P0 | Strategies | Strategy Engine/DB | Research-only strategies cannot publish. |
| F025 | Primary Strategies | Strategies | P0 | Strategies | Strategy Engine | Numeric rules and versions are immutable once published. |
| F026 | Research Strategies | Strategies | P1 | Strategies | Strategy Engine | Status RESEARCH_ONLY; no publication/paper promotion without governance. |
| F027 | Strategy Draft & Validation | Strategies | P1 | Strategies | Strategy Engine | Published versions are immutable. |
| F028 | Backtesting | Research | P0 | Backtest | Backtest Engine | No lookahead; dataset manifest/cost model pinned. |
| F029 | Replay | Research | P1 | Replay | Replay Engine | Replay mode never labels data live. |
| F030 | Strategy Performance | Research | P1 | Analytics/Strategies | Analytics | Every metric shows sample size and cost assumptions. |
| F031 | Position Sizing | Risk | P0 | Paper/Decisions | Risk Engine | Decimal precision and exchange step constraints enforced. |
| F032 | Leverage Gate | Risk | P0 | Paper/Decisions | Risk Engine | LONG <=5x; SHORT <=3x under v1.0. |
| F033 | Liquidation Safety | Risk | P0 | Paper/Decisions | Risk Engine | Minimum liquidation distance = 3x stop distance or block. |
| F034 | Effective R Gate | Risk | P0 | Paper/Decisions | Risk Engine | Minimum 2.0 effective blended R. |
| F035 | Daily/Weekly Locks | Risk | P0 | Home/Paper | Risk Engine | Daily -2R; weekly -6R. |
| F036 | Loss Reducer | Risk | P0 | Paper | Risk Engine | Risk becomes 0.25% until next realized win. |
| F037 | Calibration Risk | Risk | P0 | Paper | Risk Engine | 0.25% risk through first 30 closed trades. |
| F038 | Correlation Gate | Risk | P0 | Paper/Risk | Risk Engine | Maximum two BTC-correlated positions under active policy. |
| F039 | Paper Preview & Confirmation | Paper | P0 | Paper | Paper Engine/API | Confirmation uses hash/version binding and cannot call exchange. |
| F040 | Paper Orders/Fills | Paper | P0 | Paper | Paper Engine/DB | 50% TP1, move to BE, 50% TP2; no real order path. |
| F041 | Paper Positions | Paper | P0 | Paper | Paper Engine/DB | Append-only financial events reconcile. |
| F042 | Manual Paper Close | Paper | P1 | Paper | Paper Engine | Close creates journaled event and updates locks in same cycle. |
| F043 | Journal Hash Chain | Journal | P0 | Journal/Audit | Journal/DB | Losses/rejections cannot be deleted; corrections append. |
| F044 | Portfolio & Risk View | Paper | P1 | Paper | Portfolio/Risk | Derived from journal/positions, not independent mutable totals. |
| F045 | Analytics V2 | Analytics | P1 | Analytics | Analytics | No synthetic outcome series. |
| F046 | Calibration Analytics | Analytics | P2 | Analytics | Analytics | Low sample warnings mandatory. |
| F047 | Data Quality Analytics | Analytics | P2 | Analytics | Analytics | Shows denominators and blocked percentage. |
| F048 | Alerts | Operations | P2 | System | Alerts/Scheduler | Dedup/cooldown required; external writes disabled in base release. |
| F049 | Daily Brief | Operations | P2 | Home/System | Brief/AI | Numeric facts come from deterministic services. |
| F050 | Provider Health | Operations | P1 | Home/System/AI | Providers | Health state must reflect actual checks, never assumed connectivity. |
| F051 | Audit Log | Operations | P0 | System | Audit/DB | Sensitive values redacted. |
| F052 | Backup & Restore | Operations | P1 | System | Backup/DB | Secrets excluded; restore validates before switch. |
| F053 | Methodology & Limitations | Operations | P2 | System | Docs/UI | No profitability promise. |
| F054 | AI Chat | AI | P1 | AI | AI Runtime | Read-only; numeric claims must be grounded or abstained. |
| F055 | Tool Gateway | AI | P0 | AI | Tool Gateway | Prompts cannot grant permissions. |
| F056 | AI Provider Gateway | AI | P1 | AI Providers | Provider Gateway | Provider can be disabled/deleted without changing agents/tools/memory. |
| F057 | Provider Routing Policies | AI | P1 | AI Providers | Provider Gateway | Privacy class constrains fallback. |
| F058 | Custom AI Provider | AI | P2 | AI Providers | Provider Gateway/Security | SSRF and capability validation required. |
| F059 | AI Memory | AI | P1 | AI Memory | Memory | Trading/journal truth stays in domain tables. |
| F060 | Knowledge Base | AI | P2 | AI Memory | Knowledge | Versioned source and freshness metadata. |
| F061 | Skill Registry | AI | P1 | AI Skills | Skill Control | Source packs immutable. |
| F062 | Skill Draft/Test/Publish/Rollback | AI | P1 | AI Skills | Skill Control | Edit creates draft; published version immutable. |
| F063 | Skill Traceability | AI | P1 | AI Traces | Skill Control/Audit | Exact version/hash pinned. |
| F064 | Agent Run Traces | AI | P1 | AI Traces | AI Runtime/Audit | Show structured execution facts only. |
| F065 | Agent Evaluations | AI | P2 | AI Traces | Evaluation | Cannot silently modify risk/strategy. |
| F066 | Web/News Research Adapter | AI | P2 | AI | Research Adapter | External text is untrusted and never market numeric authority. |
| F067 | Offline Demo | Runtime | P0 | Global | Runtime/Fixtures | No network dependency for DEMO. |
| F068 | Termux Runtime | Runtime | P1 | System | Runtime/Scripts | Loopback-only services; AI failure isolated. |
| F069 | Health/Doctor Tools | Runtime | P1 | System | Runtime/Ops | Read-only health checks. |
| F070 | Evidence Export | Operations | P1 | Audit/System | Export | No secrets; hashes included. |


---

# INCLUDED: 05_USER_ROLES_AND_PERMISSIONS.md

# 05 - User Roles and Permissions

## V1 user model
The base release is a local single-owner application. There is no multi-tenant role hierarchy. The only authenticated human role is `OWNER`. System actors are services, not human roles.

| Actor | Read market | Change settings | Publish strategy/skill | Paper write | Change risk | Live trade | Read secrets |
|---|---:|---:|---:|---:|---:|---:|---:|
| OWNER | yes | yes | gated | confirmed only | versioned policy workflow only | no | masked/manage only |
| AI Agent | scoped | no | no | proposal only | no | no | no |
| Deterministic Service | owned domain | owned config | service-specific | paper service only | enforces | no | no |
| Scheduler | scoped jobs | no | no | lifecycle only | enforces | no | no |

Prompts never grant permissions. Tool Gateway and backend authorization are authoritative.


---

# INCLUDED: 06_USER_FLOWS.md

# 06 - User Flows

| ID | Flow | Steps | Success |
| --- | --- | --- | --- |
| FLOW001 | First local launch | Open app -> owner setup/login -> DEMO default -> Home loads deterministic fixtures -> health shown -> no cloud required | Usable local app with explicit DEMO label |
| FLOW002 | Find a market | Ctrl+K or symbol control -> search -> select symbol -> /market/:symbol -> snapshot/candles/features load -> stale/degraded state shown if needed | Single-symbol workspace |
| FLOW003 | Run scan | Scan -> Run -> universe/data/liquidity/regime/features/strategy/derivatives/trade-plan/risk/evidence/red-team stages -> ranking table -> open candidate inspector | Ranked auditable candidates and exclusions |
| FLOW004 | Inspect decision | Decision row -> detail -> geometry -> evidence -> red team -> risk -> provenance -> lifecycle -> related strategy/backtest | Complete auditable decision understanding |
| FLOW005 | Create paper position | Eligible decision -> paper preview -> preview hash -> owner confirm -> paper order -> fill lifecycle -> position -> journal -> portfolio/risk same-cycle update | Paper-only position; no exchange write |
| FLOW006 | Paper TP1 to BE | Position open -> TP1 touch -> 50% fill -> fees/slippage/funding journaled -> stop moved to cost-adjusted BE -> risk/portfolio refreshed | BE-protected partial position |
| FLOW007 | Backtest strategy | Strategy detail -> Backtest -> dataset/time/cost config -> run -> manifest/hash -> metrics/trades/equity/OOS panels -> compare with promotion gates | Reproducible evidence artifact |
| FLOW008 | Replay strategy | Strategy -> Replay -> choose dataset -> step clock -> inspect feature/rule/risk state -> compare resulting decisions | Deterministic historical walkthrough |
| FLOW009 | AI market question | AI Desk -> context resolves current symbol/page -> Supervisor selects skills/tools -> deterministic tool calls -> specialists -> Evidence -> Red Team if decision-related -> answer + trace | Grounded answer with tool/skill/provider trace |
| FLOW010 | Change AI provider | AI Providers -> select/add provider -> test endpoint/model/capabilities -> enable -> routing policy -> future AI run selects it if policy allows | Provider changed without changing agents/tools/memory |
| FLOW011 | Edit a skill safely | AI Skills -> skill detail -> Create Draft -> edit -> validate -> tests -> impact -> publish -> profile atomic switch -> trace pins version -> rollback available | Controlled skill change |
| FLOW012 | Provider outage | Health check fails -> provider state degraded/offline -> allowed fallback evaluated -> LOCAL_ONLY blocks cloud fallback -> AI shows unavailable if needed -> deterministic app remains functional | Failure isolated and truthful |
| FLOW013 | Backup and restore | System -> Backup -> atomic DB/config export -> checksums -> restore validate -> integrity/schema/reconcile -> explicit confirm -> switch -> health checks | Recoverable local state without secrets in backup |


---

# INCLUDED: 07_SCREEN_AND_ROUTE_CATALOG.md

# 07 - Screen and Route Catalog

The target visual system is intentionally different from the earlier dense panel/card approach. The new direction, **Quiet Grid Terminal**, uses an open dark canvas, one thin navigation rail, one context bar, table-first information, a single contextual inspector and restrained semantic color. Major pages avoid nested cards. Detail appears in drawers/sheets instead of permanent columns. Motion is short and functional: 110-220 ms, no bounce, no glow loops, no decorative parallax. The primary interaction is symbol/context continuity plus a command palette.

| ID | Screen | Route | Purpose | Sections | Desktop | Mobile |
| --- | --- | --- | --- | --- | --- | --- |
| UI001 | Home | /home | High-signal operating overview: market pulse, scan status, active paper risk, recent decisions, provider health. | Pulse strip; candidate rail; open paper positions; risk locks; provider state; daily brief preview | One open canvas with two horizontal bands and one narrow right inspector | Single scroll with sticky symbol/command bar |
| UI002 | Market Workspace | /market/:symbol | One symbol workspace combining chart, facts, derivatives, liquidity, structure and strategy context. | Context bar; chart canvas; feature strip; derivatives strip; depth/liquidity drawer; decision history | Chart dominates; inspector toggles instead of permanent card columns | Chart first; inspector becomes bottom sheet |
| UI003 | Scanner | /scan | Run or inspect staged universe scans and deterministic candidate ranking. | Scan command bar; stage progress; ranking table; exclusions drawer; candidate quick inspect | Full-width dense table; no card grid | Ranked rows; stage filters in sheet |
| UI004 | Decisions | /decisions | Canonical signal/decision queue and lifecycle. | State tabs; decision table; evidence score; risk verdict; lifecycle; filters | Table-first; details open in side inspector | List rows with full-screen detail |
| UI005 | Decision Detail | /decisions/:id | Complete auditable decision card and evidence trail. | Identity; geometry; evidence factors; risk; Red Team; provenance; agents; lifecycle timeline | Two-column document layout | Single document flow |
| UI006 | Strategy Lab | /strategies | Strategy registry, versioning, tests, promotion status and research strategy isolation. | Registry table; version drawer; validation; promotion gates; performance summary | Table + right inspector | List + full-screen detail |
| UI007 | Strategy Detail | /strategies/:id | Rules, parameters, version history, backtest/replay access and eligibility. | Rules; parameters; data needs; version history; tests; backtest/replay actions | Document + compact action rail | Single document flow |
| UI008 | Backtest | /strategies/:id/backtest | Run reproducible historical evaluations with cost, bias and dataset manifests. | Run config; dataset manifest; results; equity; R distribution; costs; OOS/walk-forward | Config rail + analysis canvas | Wizard-like stacked sections |
| UI009 | Replay | /strategies/:id/replay | Step deterministic market history through the exact strategy and risk pipeline. | Replay clock; chart; feature values; rule states; decision events; paper simulation controls | Chart + timeline rail | Chart + collapsible timeline |
| UI010 | Paper Desk | /paper | Paper-only preview, confirmation, orders, fills, positions and portfolio. | Preview ticket; confirmation; positions; orders; fills; portfolio summary; risk trace | Split canvas: ticket left, ledger center, risk inspector right | Tabs: Ticket / Positions / Orders / Portfolio |
| UI011 | Journal | /journal | Append-only trade and decision record with audit-safe corrections. | Journal stream; filters; outcome detail; linked evidence; export | Chronological table/stream | Timeline list |
| UI012 | Analytics | /analytics | Ledger-derived analytics, calibration, funnel, execution, risk and data quality. | Overview; Trades; Strategy; Symbol; Regime; Side; Risk/Costs; Execution; Red Team; Data Quality; Calibration | Segmented top nav with chart/table canvas | Horizontal tab rail |
| UI013 | AI Desk | /ai | Read-only AI orchestration workspace around deterministic tools. | Chat; six agents; tool trace; evidence; skill trace; provider/model; memory references | Conversation canvas + trace inspector | Chat + switchable trace sheet |
| UI014 | AI Skills | /ai/skills | Owner-controlled skill registry, drafts, tests, publish and rollback. | Skills table; filters; detail; versions; tools; tests; impact; audit | Table + detail inspector | List + detail page |
| UI015 | AI Providers | /ai/providers | Provider registry, models, capabilities, privacy routing, health and cost policy. | Provider list; test; models; capability matrix; routing policies; usage; health | Provider rows with inspector | Provider cards only where row format cannot fit |
| UI016 | Memory & Knowledge | /ai/memory | Inspect and control conversation, preference, research and knowledge memory without altering immutable trading records. | Memory scopes; search; retention; knowledge documents; delete/export controls | Search + split list/detail | Search + stacked list |
| UI017 | Traces & Evaluations | /ai/traces | Inspect agent run plan, tools, skills, provider/model, evidence and evaluation. | Run list; execution graph; evidence; tool calls; skill versions; evaluation result | Run table + trace canvas | Run list + detail |
| UI018 | System | /system | Operational health, alerts, audit, settings, methodology and limitations. | Data Health; Provider Health; Alerts; Audit; Settings; Methodology; Limitations; Daily Brief | Vertical settings index + content | Settings list + subpages |


---

# INCLUDED: 08_UI_UX_BLUEPRINT.md

# 08 - UI/UX Blueprint

The target visual system is intentionally different from the earlier dense panel/card approach. The new direction, **Quiet Grid Terminal**, uses an open dark canvas, one thin navigation rail, one context bar, table-first information, a single contextual inspector and restrained semantic color. Major pages avoid nested cards. Detail appears in drawers/sheets instead of permanent columns. Motion is short and functional: 110-220 ms, no bounce, no glow loops, no decorative parallax. The primary interaction is symbol/context continuity plus a command palette.

## Shell
- 56px left rail on desktop.
- 48px context bar across the top.
- Main workspace is an open canvas; panels appear only where information needs framing.
- One 336px inspector drawer is reused across scanner rows, decisions, strategies, providers and skills.
- Command palette is the fastest way to switch symbol, page or read-only command.
- Mobile replaces the rail with five-item bottom navigation and uses bottom sheets for inspectors.

## Density
Tables, market facts and logs are compact. Forms, confirmations and explanatory text use wider spacing. No bento layout. No nested card stacks.

## Information hierarchy
1. Context and safety state.
2. Primary task or data.
3. Decision/risk state.
4. Supporting evidence.
5. Deep diagnostics in inspector/drawer.

## Status display
Status uses a small dot + precise text, never color alone. LONG and SHORT colors are reserved for directional information; warnings and locks use separate semantics.

## Responsive rules
- >=1180px: rail + canvas + optional inspector.
- 768-1179px: rail collapses to icons; inspector overlays.
- <768px: bottom nav; context bar condensed; tables become row lists; chart remains full-width.


---

# INCLUDED: 09_DESIGN_SYSTEM.md

# 09 - Design System

## Tokens
```json
{
  "design_name": "Quiet Grid Terminal",
  "principles": [
    "open layouts",
    "few containers",
    "hairline separators",
    "dense where useful",
    "quiet motion",
    "clear data hierarchy",
    "no ornamental card grid"
  ],
  "colors": {
    "canvas": "#090D10",
    "surface": "#0D1418",
    "surfaceRaised": "#121C21",
    "surfaceHover": "#162229",
    "border": "#223038",
    "text": "#E8F0F2",
    "textMuted": "#8A9A9F",
    "textDim": "#5F7076",
    "accent": "#7DE2C4",
    "focus": "#8AB4F8",
    "long": "#2ED09A",
    "short": "#FF6B73",
    "warning": "#F7C967",
    "danger": "#FF5A67",
    "info": "#78A9FF",
    "locked": "#B29BFF",
    "overlay": "rgba(3,7,9,0.78)"
  },
  "typography": {
    "ui": "Inter, system-ui, sans-serif",
    "numeric": "IBM Plex Mono, ui-monospace, monospace",
    "sizes_px": {
      "xs": 11,
      "sm": 12,
      "md": 13,
      "body": 14,
      "lg": 16,
      "xl": 20,
      "xxl": 28,
      "hero": 36
    },
    "weights": {
      "regular": 400,
      "medium": 500,
      "semibold": 600,
      "bold": 700
    },
    "line_heights": {
      "tight": 1.15,
      "normal": 1.4,
      "relaxed": 1.6
    }
  },
  "spacing_px": [
    4,
    8,
    12,
    16,
    20,
    24,
    32,
    40,
    48,
    64
  ],
  "radii_px": {
    "control": 4,
    "panel": 6,
    "dialog": 8,
    "pill": 999
  },
  "borders": {
    "default": "1px solid #223038",
    "strong": "1px solid #33464F"
  },
  "elevation": {
    "none": "none",
    "float": "0 12px 40px rgba(0,0,0,.28)"
  },
  "layout": {
    "rail_width": 56,
    "context_bar_height": 48,
    "inspector_width": 336,
    "content_max_width": 1920,
    "grid_gap": 12
  },
  "breakpoints_px": {
    "mobile": 0,
    "tablet": 768,
    "desktop": 1180,
    "wide": 1600
  }
}
```

## Component philosophy
Use open bands, rows, tables, canvases and one inspector. Cards are reserved for confirmations or compact summaries that cannot be expressed as rows.

## Semantic states
LONG=#2ED09A, SHORT=#FF6B73, warning=#F7C967, info=#78A9FF, locked=#B29BFF. Every status includes text.

## Focus
All interactive elements receive a 2px focus ring using #8AB4F8 with 2px offset.

## Numeric typography
Prices, quantities, percentages, R values and timestamps use the numeric font with tabular figures.


---

# INCLUDED: 10_FRONTEND_ARCHITECTURE.md

# 10 - Frontend Architecture

## Target stack
React 19 + Vite + strict TypeScript + React Router. Frontend owns presentation, navigation, owner preferences and transient interaction state. It does not own authoritative market/risk/strategy/paper/accounting calculations.

## Layers
```text
src/
  app/            bootstrap, router, providers
  shell/          rail, context bar, command palette
  pages/          route-level composition
  features/       market, scan, decision, strategy, paper, journal, analytics, ai, system
  components/     reusable primitives
  api/            typed REST client and WebSocket client
  state/          UI/symbol/runtime/preferences only
  i18n/           Arabic/English
  theme/          tokens and motion
  utils/          formatting only; no domain finance logic
```

## State separation
- Server state: fetched from backend and cached with explicit freshness metadata.
- UI state: active symbol, tab, filters, open inspector, density, language.
- Persisted UI preferences: local storage with schema version and safe migration.
- Domain truth: never reconstructed from local storage.

## Error boundary
Route-level error boundary renders a precise recoverable state without clearing persisted domain data.

## WebSocket
Events update caches only after sequence/dedup validation. On gap/reconnect, reconcile with REST snapshot before showing current state.


---

# INCLUDED: 11_FRONTEND_COMPONENT_CATALOG.md

# 11 - Frontend Component Catalog

| Component | Purpose | Variants |
| --- | --- | --- |
| AppRail | 56px primary navigation rail | desktop; compact mobile bottom-nav mapping |
| ContextBar | Global symbol, runtime mode, freshness, language, command entry | desktop sticky; mobile condensed |
| CommandPalette | Search symbol/page/action | default; read-only action; confirmation-forwarding |
| DataStrip | Compact label/value/status row | normal; stale; degraded; unavailable |
| DenseTable | Scanner/decision/order/journal/strategy tables | sortable; selectable; virtualized; mobile row |
| InspectorDrawer | Contextual details without route loss | right drawer; mobile bottom sheet; full page fallback |
| ChartCanvas | Candles, volume, deterministic overlays, decision geometry | market; replay; backtest |
| StatusMark | Text+dot semantic status | healthy; degraded; locked; warning; error; research |
| RiskVerdict | Risk pass/veto with reasons | pass; veto; blocked |
| EvidenceBar | 8-factor evidence score without decorative gauge | raw; degraded cap; missing factor |
| DecisionGeometry | Entry/stop/invalidation/targets/R/costs block | long; short; blocked |
| Timeline | Decision/paper/journal lifecycle | vertical; horizontal desktop |
| PaperTicket | Preview/confirm paper action | preview; confirmation; blocked; expired |
| AgentTrace | Show run stages/tools/skills/provider/evidence | compact; expanded |
| ProviderRow | Provider status/model/policy controls | healthy; degraded; offline; disabled |
| SkillRow | Skill status/version/agent/activation/tests | enabled; disabled; draft; protected |
| MetricCell | Numeric analytics cell with denominator/quality | normal; low-sample; unavailable |
| EmptyState | Honest no-data state | no-data; filtered-empty; offline; unavailable |
| ErrorState | Recoverable/blocking error rendering | inline; panel; full-page |


---

# INCLUDED: 12_BACKEND_ARCHITECTURE.md

# 12 - Backend Architecture

## Target stack
FastAPI + Pydantic v2 + SQLAlchemy 2 + Alembic + SQLite + APScheduler. Monetary/precision-sensitive domain values use Decimal-compatible representations.

## Domain ownership
- `market`: provider adapters, normalization, snapshots, features.
- `scanner`: staged universe scanning and rankings.
- `strategies`: registry, rule execution, drafts/versioning.
- `decisions`: card assembly, lifecycle, evidence references.
- `risk`: sizing, leverage, liquidation, locks, heat/correlation.
- `paper`: preview/confirm, orders, fills, positions, lifecycle.
- `journal`: append-only events and reconciliation.
- `analytics`: ledger-derived metrics.
- `ai`: agents, provider gateway, context, memory, tool gateway.
- `skills`: registry, drafts, testing, profiles, publish/rollback.
- `ops`: audit, alerts, health, backup/restore.

## Request execution
Request -> auth/CSRF -> schema validation -> application service -> deterministic domain service -> transaction -> audit/event -> response. Network/model calls must not hold a database write transaction open.

```mermaid
flowchart LR
  UI["React Web/PWA"] --> API["FastAPI REST + WebSocket"]
  API --> Domain["Deterministic Domain Services"]
  Domain --> DB["SQLite + Alembic"]
  Domain --> Market["Public Market Adapters"]
  Domain --> Scheduler["Scheduler / Jobs"]
  UI --> AgentUI["AI Desk / AG-UI"]
  AgentUI --> AgentRuntime["Agent Runtime"]
  AgentRuntime --> ToolGW["Tool Gateway"]
  ToolGW --> Domain
  AgentRuntime --> ModelRouter["Model Policy Router"]
  ModelRouter --> ProviderGW["AI Provider Gateway"]
  ProviderGW --> Models["Local / Cloud Models"]
```


---

# INCLUDED: 13_API_CONTRACTS.md

# 13 - API Contracts

All API paths use `/api/v1`. Every write is authenticated, CSRF-protected and audit logged. Paper writes require confirmation binding.

| ID | Method | Path | Domain | Purpose | Auth | Write |
| --- | --- | --- | --- | --- | --- | --- |
| API001 | GET | /api/v1/health | System | Liveness | NONE | False |
| API002 | GET | /api/v1/ready | System | Readiness | NONE | False |
| API003 | GET | /api/v1/version | System | Build/policy/schema identity | NONE | False |
| API004 | GET | /api/v1/auth/mode | Auth | Auth setup status | NONE | False |
| API005 | POST | /api/v1/auth/setup | Auth | Initial owner setup | NONE | True |
| API006 | POST | /api/v1/auth/login | Auth | Create local session | NONE | True |
| API007 | POST | /api/v1/auth/logout | Auth | Invalidate session | SESSION | True |
| API008 | GET | /api/v1/auth/session | Auth | Session facts | SESSION | False |
| API009 | GET | /api/v1/markets | Market | Eligible universe | SESSION | False |
| API010 | GET | /api/v1/markets/:symbol/snapshot | Market | Immutable market snapshot | SESSION | False |
| API011 | GET | /api/v1/markets/:symbol/candles | Market | Closed candles | SESSION | False |
| API012 | GET | /api/v1/markets/:symbol/features | Market | Indicators/structure/regime | SESSION | False |
| API013 | GET | /api/v1/markets/:symbol/derivatives | Market | Funding/OI context | SESSION | False |
| API014 | GET | /api/v1/markets/:symbol/liquidity | Market | Spread/depth/liquidity | SESSION | False |
| API015 | GET | /api/v1/markets/breadth | Market | Breadth/heatmap facts | SESSION | False |
| API016 | POST | /api/v1/scans | Scanner | Start manual scan | SESSION | True |
| API017 | GET | /api/v1/scans | Scanner | List scans | SESSION | False |
| API018 | GET | /api/v1/scans/:id | Scanner | Scan state/stages | SESSION | False |
| API019 | GET | /api/v1/scans/:id/rankings | Scanner | Ranked candidates | SESSION | False |
| API020 | GET | /api/v1/scans/:id/exclusions | Scanner | Exclusion reasons | SESSION | False |
| API021 | POST | /api/v1/scans/:id/cancel | Scanner | Cancel scan | SESSION | True |
| API022 | GET | /api/v1/decisions | Decision | Decision queue | SESSION | False |
| API023 | GET | /api/v1/decisions/:id | Decision | Decision card | SESSION | False |
| API024 | GET | /api/v1/decisions/:id/evidence | Decision | Evidence/provenance | SESSION | False |
| API025 | GET | /api/v1/decisions/:id/red-team | Decision | Red Team objections | SESSION | False |
| API026 | GET | /api/v1/decisions/:id/trace | Decision | Rule/risk/version trace | SESSION | False |
| API027 | GET | /api/v1/strategies | Strategy | Registry | SESSION | False |
| API028 | GET | /api/v1/strategies/:id | Strategy | Strategy version/detail | SESSION | False |
| API029 | POST | /api/v1/strategies/:id/drafts | Strategy | Create draft | SESSION | True |
| API030 | POST | /api/v1/strategy-drafts/:id/validate | Strategy | Validate draft | SESSION | True |
| API031 | POST | /api/v1/strategy-drafts/:id/test | Strategy | Run strategy contract tests | SESSION | True |
| API032 | POST | /api/v1/strategy-drafts/:id/publish | Strategy | Publish approved version | SESSION | True |
| API033 | POST | /api/v1/backtests | Backtest | Start backtest | SESSION | True |
| API034 | GET | /api/v1/backtests/:id | Backtest | Backtest status/result | SESSION | False |
| API035 | GET | /api/v1/backtests/:id/artifacts | Backtest | Artifacts/manifest | SESSION | False |
| API036 | POST | /api/v1/replays | Replay | Start replay | SESSION | True |
| API037 | GET | /api/v1/replays/:id | Replay | Replay state | SESSION | False |
| API038 | POST | /api/v1/replays/:id/step | Replay | Advance replay | SESSION | True |
| API039 | POST | /api/v1/risk/check | Risk | Risk verdict | SESSION | True |
| API040 | GET | /api/v1/risk/state | Risk | Locks/heat/correlation | SESSION | False |
| API041 | GET | /api/v1/risk/policy | Risk | Active policy | SESSION | False |
| API042 | POST | /api/v1/paper/preview | Paper | Create deterministic preview hash | SESSION | True |
| API043 | POST | /api/v1/paper/confirm | Paper | Confirm paper action | SESSION | True |
| API044 | GET | /api/v1/paper/orders | Paper | List paper orders | SESSION | False |
| API045 | GET | /api/v1/paper/fills | Paper | List paper fills | SESSION | False |
| API046 | GET | /api/v1/paper/positions | Paper | List positions | SESSION | False |
| API047 | POST | /api/v1/paper/positions/:id/close-preview | Paper | Preview manual close | SESSION | True |
| API048 | POST | /api/v1/paper/positions/:id/close-confirm | Paper | Confirm manual close | SESSION | True |
| API049 | POST | /api/v1/paper/orders/:id/cancel-preview | Paper | Preview cancel | SESSION | True |
| API050 | POST | /api/v1/paper/orders/:id/cancel-confirm | Paper | Confirm cancel | SESSION | True |
| API051 | GET | /api/v1/portfolio | Portfolio | Equity/exposure/heat/PnL | SESSION | False |
| API052 | GET | /api/v1/journal | Journal | Journal stream | SESSION | False |
| API053 | GET | /api/v1/journal/:id | Journal | Journal entry detail | SESSION | False |
| API054 | GET | /api/v1/journal/integrity | Journal | Hash-chain verification | SESSION | False |
| API055 | GET | /api/v1/journal/export | Journal | Evidence-safe journal export | SESSION | False |
| API056 | GET | /api/v1/analytics/overview | Analytics | Overview metrics | SESSION | False |
| API057 | GET | /api/v1/analytics/trades | Analytics | Trade analytics | SESSION | False |
| API058 | GET | /api/v1/analytics/breakdowns | Analytics | Strategy/symbol/regime/side breakdowns | SESSION | False |
| API059 | GET | /api/v1/analytics/risk-costs | Analytics | Risk/cost analytics | SESSION | False |
| API060 | GET | /api/v1/analytics/execution | Analytics | Paper execution analytics | SESSION | False |
| API061 | GET | /api/v1/analytics/calibration | Analytics | Calibration metrics | SESSION | False |
| API062 | GET | /api/v1/analytics/data-quality | Analytics | Data quality metrics | SESSION | False |
| API063 | GET | /api/v1/alerts | Operations | Alerts | SESSION | False |
| API064 | POST | /api/v1/alerts/:id/ack | Operations | Acknowledge alert | SESSION | True |
| API065 | GET | /api/v1/daily-brief | Operations | Daily brief | SESSION | False |
| API066 | GET | /api/v1/audit | Operations | Audit events | SESSION | False |
| API067 | GET | /api/v1/data-health | Operations | Market/provider data health | SESSION | False |
| API068 | POST | /api/v1/backups | Operations | Create local backup | SESSION | True |
| API069 | POST | /api/v1/restores/validate | Operations | Validate backup before restore | SESSION | True |
| API070 | POST | /api/v1/restores/confirm | Operations | Confirm validated local restore | SESSION | True |
| API071 | POST | /api/v1/ai/chat | AI | Start/continue AI task | SESSION | True |
| API072 | GET | /api/v1/ai/runs | AI | List AI runs | SESSION | False |
| API073 | GET | /api/v1/ai/runs/:id | AI | Run trace/evaluation | SESSION | False |
| API074 | POST | /api/v1/ai/runs/:id/stop | AI | Stop in-flight AI run | SESSION | True |
| API075 | GET | /api/v1/ai/agents | AI | Agent roster/policies | SESSION | False |
| API076 | GET | /api/v1/ai/providers | AI | Provider registry | SESSION | False |
| API077 | POST | /api/v1/ai/providers | AI | Add provider | SESSION | True |
| API078 | PATCH | /api/v1/ai/providers/:id | AI | Update provider metadata/policy | SESSION | True |
| API079 | DELETE | /api/v1/ai/providers/:id | AI | Remove provider after dependency check | SESSION | True |
| API080 | POST | /api/v1/ai/providers/:id/test | AI | Connection/capability test | SESSION | True |
| API081 | GET | /api/v1/ai/providers/:id/models | AI | Discovered models | SESSION | False |
| API082 | GET | /api/v1/ai/routing | AI | Routing policies | SESSION | False |
| API083 | PUT | /api/v1/ai/routing | AI | Update routing policy | SESSION | True |
| API084 | GET | /api/v1/ai/memory | AI | Search/list memory | SESSION | False |
| API085 | POST | /api/v1/ai/memory/preferences | AI | Update user preference memory | SESSION | True |
| API086 | DELETE | /api/v1/ai/memory/conversations/:id | AI | Delete allowed conversation memory | SESSION | True |
| API087 | GET | /api/v1/ai/knowledge | AI | Search knowledge | SESSION | False |
| API088 | GET | /api/v1/skills | Skills | Skill registry | SESSION | False |
| API089 | GET | /api/v1/skills/:slug | Skills | Skill detail | SESSION | False |
| API090 | POST | /api/v1/skills/:slug/drafts | Skills | Create skill draft | SESSION | True |
| API091 | PATCH | /api/v1/skill-drafts/:id | Skills | Edit skill draft | SESSION | True |
| API092 | POST | /api/v1/skill-drafts/:id/validate | Skills | Validate draft | SESSION | True |
| API093 | POST | /api/v1/skill-drafts/:id/test | Skills | Test exact draft hash | SESSION | True |
| API094 | POST | /api/v1/skill-drafts/:id/impact | Skills | Impact analysis | SESSION | True |
| API095 | POST | /api/v1/skill-drafts/:id/publish | Skills | Publish tested draft | SESSION | True |
| API096 | POST | /api/v1/skills/:slug/rollback | Skills | Rollback active version | SESSION | True |
| API097 | GET | /api/v1/skill-profiles | Skills | Profiles | SESSION | False |
| API098 | POST | /api/v1/skill-profiles/:id/activate | Skills | Activate profile atomically | SESSION | True |


---

# INCLUDED: 14_WEBSOCKET_REALTIME_ARCHITECTURE.md

# 14 - WebSocket / Realtime Architecture

```json
{
  "url": "/api/v1/ws",
  "auth": "same local session; reject unauthenticated connection",
  "envelope": [
    "event_id",
    "sequence",
    "type",
    "timestamp",
    "schema_version",
    "payload"
  ],
  "events": [
    "market.tick",
    "market.candle.closed",
    "scanner.started",
    "scanner.progress",
    "scanner.completed",
    "decision.created",
    "decision.updated",
    "risk.veto",
    "paper.order",
    "paper.fill",
    "paper.position",
    "journal.appended",
    "alert.triggered",
    "provider.degraded",
    "provider.recovered",
    "agent.started",
    "agent.tool",
    "agent.completed",
    "agent.error",
    "skill.published",
    "skill.rolled_back"
  ],
  "heartbeat_seconds": 20,
  "reconnect": "client sends last sequence; server replays retained events or emits stream.gap; client reconciles by REST snapshot",
  "dedup": "event_id + sequence",
  "queue_max": 2000
}
```

The UI must never treat a reconnect as proof of current state. A sequence gap triggers REST reconciliation. Market WebSocket data may update visual charts, but only closed/validated events enter deterministic decisions.


---

# INCLUDED: 15_DATABASE_ARCHITECTURE.md

# 15 - Database Architecture

SQLite-first with WAL, foreign keys, versioned Alembic migrations and bounded transactions. Domain records and AI/skill records share one installation but have separate ownership boundaries.

| Table | Purpose | Owner | Retention |
| --- | --- | --- | --- |
| app_users | Local owner identity | Auth | INDEFINITE |
| sessions | Local authenticated sessions and CSRF | Auth | SESSION_LIFETIME |
| configuration_versions | Versioned app policies/config | Config | INDEFINITE |
| approval_events | Owner approvals with hash chain | Governance | INDEFINITE |
| schema_migrations | Migration ledger | Database | INDEFINITE |
| instruments | Eligible market symbols/metadata | Market | INDEFINITE |
| market_snapshots | Immutable decision snapshots | Market | INDEFINITE |
| candles_cache | Validated historical/current closed candles | Market | CACHE_POLICY |
| provider_health | Market provider health history | Providers | 30_DAYS |
| scanner_runs | Scan job state/config | Scanner | INDEFINITE |
| scanner_candidates | Candidate scores/ranks | Scanner | INDEFINITE |
| scanner_exclusions | Stage rejection reasons | Scanner | INDEFINITE |
| strategy_versions | Published strategy versions | Strategies | INDEFINITE |
| strategy_drafts | Editable strategy drafts | Strategies | UNTIL_PUBLISHED_OR_DELETED |
| backtest_runs | Backtest run metadata | Backtest | INDEFINITE |
| backtest_trades | Backtest trade events | Backtest | INDEFINITE |
| replay_runs | Replay sessions | Replay | 90_DAYS |
| decisions | Immutable decision cards | Decision | INDEFINITE |
| decision_evidence | Evidence/provenance links | Evidence | INDEFINITE |
| decision_objections | Red Team objections | Red Team | INDEFINITE |
| decision_events | Decision lifecycle events | Decision | INDEFINITE |
| paper_orders | Paper orders | Paper | INDEFINITE |
| paper_fills | Paper fills | Paper | INDEFINITE |
| paper_positions | Paper positions | Paper | INDEFINITE |
| paper_position_events | Paper lifecycle/accounting events | Paper | INDEFINITE |
| journal_events | Append-only journal hash chain | Journal | INDEFINITE |
| portfolio_snapshots | Derived portfolio snapshots | Portfolio | 365_DAYS |
| alerts | Local alerts | Alerts | 180_DAYS |
| audit_events | Security/config/skill/provider audit | Audit | INDEFINITE |
| backup_records | Backup manifests and hashes | Backup | KEEP_WITH_BACKUP |
| ai_providers | Provider metadata and secret reference only | AI Provider | INDEFINITE |
| ai_models | Discovered model inventory | AI Provider | CURRENT_PLUS_HISTORY |
| ai_provider_capabilities | Model/provider capabilities | AI Provider | CURRENT_PLUS_HISTORY |
| ai_routing_policies | Routing policies | AI Provider | INDEFINITE |
| ai_request_logs | Sanitized AI request metadata | AI | 14_DAYS |
| ai_provider_health | AI provider health | AI Provider | 30_DAYS |
| ai_sessions | AI conversation sessions | AI | 90_DAYS |
| ai_messages | Conversation messages after privacy policy | AI | 90_DAYS |
| ai_memories | Editable AI memory records | Memory | POLICY |
| knowledge_documents | Local knowledge metadata/content | Knowledge | INDEFINITE |
| agent_runs | Agent run metadata | AI | 14_DAYS |
| agent_tool_calls | Sanitized tool trace | AI | 14_DAYS |
| agent_evaluations | Run evaluation/calibration | AI | 365_DAYS |
| skill_sources | Immutable imported skill pack records | Skills | INDEFINITE |
| skill_versions | Immutable published skill versions | Skills | INDEFINITE |
| skill_drafts | Editable skill drafts | Skills | UNTIL_PUBLISHED_OR_DELETED |
| skill_profiles | Named skill activation profiles | Skills | INDEFINITE |
| skill_profile_bindings | Profile-to-version bindings | Skills | INDEFINITE |
| skill_agent_bindings | Agent-skill bindings | Skills | INDEFINITE |
| skill_tool_bindings | Server-side tool permissions | Skills | INDEFINITE |
| skill_test_runs | Exact-hash test evidence | Skills | INDEFINITE |
| skill_audit_events | Skill lifecycle audit | Skills | INDEFINITE |


---

# INCLUDED: 16_DATABASE_SCHEMA_AND_ERD.md

# 16 - Database Schema and ERD

```mermaid
erDiagram
  INSTRUMENTS ||--o{ MARKET_SNAPSHOTS : has
  SCANNER_RUNS ||--o{ SCANNER_CANDIDATES : produces
  STRATEGY_VERSIONS ||--o{ DECISIONS : evaluates
  DECISIONS ||--o{ DECISION_EVIDENCE : grounds
  DECISIONS ||--o{ DECISION_OBJECTIONS : challenged_by
  DECISIONS ||--o{ PAPER_ORDERS : proposes
  PAPER_ORDERS ||--o{ PAPER_FILLS : fills
  PAPER_POSITIONS ||--o{ PAPER_POSITION_EVENTS : events
  PAPER_POSITIONS ||--o{ JOURNAL_EVENTS : journaled
  AI_PROVIDERS ||--o{ AI_MODELS : exposes
  AGENT_RUNS ||--o{ AGENT_TOOL_CALLS : uses
  SKILL_SOURCES ||--o{ SKILL_VERSIONS : versions
  SKILL_VERSIONS ||--o{ SKILL_TEST_RUNS : verified_by
  SKILL_PROFILES ||--o{ SKILL_PROFILE_BINDINGS : binds
```

`STARTER_KIT/database/schema.sql` is a logical starter DDL and must be replaced by versioned migrations during implementation. It intentionally establishes ownership and persistence boundaries rather than pretending to be a finished migration history.


---

# INCLUDED: 17_BUSINESS_LOGIC_AND_ALGORITHMS.md

# 17 - Business Logic and Algorithms

## Data finality
Only validated closed candles may enter authoritative indicators, structure, scanner, strategies or decisions. Critical snapshot freshness limit is 120 seconds. Gaps/future/non-finite/mixed critical data fail closed.

## Evidence Score
Weights: 15 Data Integrity, 15 Regime Alignment, 10 Multi-Timeframe Structure, 10 Momentum, 10 Volume/Liquidity, 15 Strategy Match, 10 Derivatives Context, 15 Trade-Plan/Risk Quality. Raw total 100; display cap 90; degraded cap 79. Missing optional evidence contributes zero.

## Risk v1.0
- LONG risk 0.50% equity.
- SHORT risk 0.35% equity.
- Hard per-trade cap 1.00%.
- First 30 closed paper trades: 0.25%.
- After two consecutive realized losses: 0.25% until next realized win.
- LONG leverage <=5x; SHORT <=3x.
- Daily lock -2R; weekly lock -6R.
- Maximum two BTC-correlated positions.
- Effective blended R >=2.0 after costs.
- Modeled liquidation distance >=3x stop distance.
- Publishable/paper scope initially BTCUSDT and ETHUSDT; other instruments remain research-only until versioned promotion.

## Position sizing
`risk_amount = equity * effective_risk_fraction`
`raw_quantity = risk_amount / abs(entry - stop)`
Quantity is quantized down to instrument step size and rechecked so actual quantized risk does not exceed the active cap. Invalid or zero stop distance rejects.

## Paper fill model
Entry is simulated using the configured paper fill rule. TP1 closes 50%, then stop moves to cost-adjusted break-even. TP2 closes the remaining 50%. Same-candle ambiguity is resolved conservatively adverse-first unless lower-resolution sequence evidence proves event order. Fees/slippage/funding are journaled as independent deterministic events.

## Red Team
R1 Data Skeptic; R2 Counter-Thesis; R3 Risk Officer; R4 Execution Realist; R5 Statistician; R6 Process Auditor. Hard objection classes are non-overridable. Red Team never approves; it only objects or reports no material objection.

## Primary strategy contracts

### S01
```yaml
# S01 — ATM Asymmetric Trend/Momentum (file 06 §3).
# Values are candidate defaults, not profitability claims.
id: strategy
strategy_id: S01
name: "ATM Asymmetric Trend/Momentum"
version: 1.0.0
status: draft_numeric
payload:
  note: "candidate defaults, not profitability claims"
  timeframes: {regime: "1d", setup: "4h", trigger: "15m"}
  rules:
    ema_pairs: [[8, 24], [16, 48], [32, 96]]
    momentum_long_min: "1.0"
    momentum_short_max: "-1.5"
    volatility_block_percentile: "97"
    volatility_watch_percentile: "5"
    structure_shift_window_bars: 12
    no_chase_max_atr: "1.5"
    stop_atr_multiple: "2.0"
    tp1_r: "1.5"
    tp2_r: "3.0"
    expiry_bars: 16

```

### S02
```yaml
# S02 — EMA Pullback Trend Continuation (file 06 §4).
# Values are candidate defaults, not profitability claims.
id: strategy
strategy_id: S02
name: "EMA Pullback Trend Continuation"
version: 1.0.0
status: draft_numeric
payload:
  note: "candidate defaults, not profitability claims"
  timeframes: {regime: "1d", setup: "4h", trigger: "15m"}
  rules:
    trend_ema_period: 50
    pullback_tolerance_atr: "0.5"
    pullback_lookback_bars: 6
    min_volume_baseline_ratio: "0.7"
    no_chase_max_atr: "1.5"
    stop_buffer_atr: "0.5"
    tp1_r: "1.5"
    tp2_r: "3.0"
    expiry_bars: 12
    short_requires_confirmed_downtrend: true

```

### S03
```yaml
# S03 — Breakout-Retest (file 06 §5).
# Values are candidate defaults, not profitability claims.
id: strategy
strategy_id: S03
name: "Breakout-Retest"
version: 1.0.0
status: draft_numeric
payload:
  note: "candidate defaults, not profitability claims"
  timeframes: {setup: "4h", trigger: "15m"}
  rules:
    range_window_bars: 40
    range_max_width_atr: "3.0"
    range_min_touches: 2
    breakout_search_bars: 12
    min_breakout_volume_ratio: "1.5"
    retest_tolerance_atr: "0.3"
    stop_buffer_atr: "0.5"
    no_chase_max_atr: "1.0"
    tp1_r: "1.5"
    tp2_r: "3.0"
    expiry_bars: 10

```

### S07
```yaml
# S07 — Range Rejection (file 06 §6).
# Values are candidate defaults, not profitability claims.
id: strategy
strategy_id: S07
name: "Range Rejection"
version: 1.0.0
status: draft_numeric
payload:
  note: "candidate defaults, not profitability claims"
  timeframes: {regime: "4h", setup: "15m"}
  rules:
    range_window_bars: 60
    range_max_width_atr: "4.0"
    range_min_touches: 2
    range_min_age_bars: 20
    flat_slope_max: "0.03"
    edge_tolerance_pct: "0.2"
    min_volume_baseline_ratio: "0.8"
    stop_buffer_atr: "0.5"
    no_chase_max_atr: "1.0"
    expiry_bars: 8

```

### S14
```yaml
# S14 — VWAP Session Pullback (file 06 §7).
# Values are candidate defaults, not profitability claims.
id: strategy
strategy_id: S14
name: "VWAP Session Pullback"
version: 1.0.0
status: draft_numeric
payload:
  note: "candidate defaults, not profitability claims"
  timeframes: {setup: "15m", trigger: "15m"}
  rules:
    session_start_hour_utc: 7
    session_end_hour_utc: 16
    exit_before_session_end_bars: 4
    trend_ema_fast: 20
    trend_ema_slow: 50
    band_atr: "0.25"
    pullback_lookback_bars: 8
    stop_atr_multiple: "1.5"
    no_chase_max_atr: "1.0"
    tp1_r: "1.5"
    tp2_r: "2.5"
    expiry_bars: 16

```


---

# INCLUDED: 18_STATE_MACHINES_AND_LIFECYCLES.md

# 18 - State Machines and Lifecycles

```json
{
  "decision": [
    "CREATED",
    "DATA_UNAVAILABLE",
    "NO_TRADE",
    "REJECTED",
    "LOCKED",
    "WATCHLIST",
    "CANDIDATE",
    "MANUAL_REVIEW",
    "PUBLISHED",
    "EXPIRED",
    "INVALIDATED"
  ],
  "signal_monitoring": [
    "PUBLISHED",
    "WAITING_FOR_ENTRY",
    "NO_CHASE",
    "EXPIRED",
    "INVALIDATED",
    "TRIGGERED"
  ],
  "paper_position": [
    "PENDING_FILL",
    "OPEN",
    "PARTIAL_TP1",
    "BE_PROTECTED",
    "TP2_CLOSED",
    "SL_CLOSED",
    "MANUAL_CLOSED",
    "INVALIDATION_CLOSED",
    "EXPIRED_UNFILLED",
    "CANCELLED",
    "INVALIDATED_UNFILLED",
    "REVIEWED"
  ],
  "quality": [
    "VALID",
    "VALID_WITH_OPTIONAL_MISSING",
    "DEGRADED",
    "INVALID",
    "STALE",
    "UNAVAILABLE"
  ],
  "skill": [
    "IMPORTED",
    "CLASSIFIED",
    "DRAFT",
    "VALIDATED",
    "TESTED",
    "PUBLISHED",
    "ACTIVE",
    "DISABLED",
    "DEPRECATED"
  ],
  "provider": [
    "UNTESTED",
    "HEALTHY",
    "DEGRADED",
    "RATE_LIMITED",
    "AUTH_ERROR",
    "OFFLINE",
    "DISABLED",
    "REMOVED"
  ]
}
```

## Paper lifecycle
```mermaid
stateDiagram-v2
  [*] --> PENDING_FILL
  PENDING_FILL --> OPEN
  PENDING_FILL --> EXPIRED_UNFILLED
  PENDING_FILL --> CANCELLED
  PENDING_FILL --> INVALIDATED_UNFILLED
  OPEN --> PARTIAL_TP1
  OPEN --> SL_CLOSED
  OPEN --> MANUAL_CLOSED
  OPEN --> INVALIDATION_CLOSED
  PARTIAL_TP1 --> BE_PROTECTED
  BE_PROTECTED --> TP2_CLOSED
  BE_PROTECTED --> SL_CLOSED
  BE_PROTECTED --> MANUAL_CLOSED
  TP2_CLOSED --> REVIEWED
  SL_CLOSED --> REVIEWED
  MANUAL_CLOSED --> REVIEWED
  INVALIDATION_CLOSED --> REVIEWED
```


---

# INCLUDED: 19_DATA_FLOW_ARCHITECTURE.md

# 19 - Data Flow Architecture

## Market decision flow
```mermaid
flowchart LR
  P["Public Provider"] --> A["Adapter"] --> V["Validation + Normalization"] --> S["Immutable Snapshot"] --> F["Features/Structure"] --> SC["Scanner"] --> ST["Strategy"] --> ES["Evidence Score"] --> RT["Red Team"] --> R["Risk Gate"] --> D["Decision Card"] --> UI["UI"]
```

## Paper flow
```mermaid
sequenceDiagram
  participant U as Owner
  participant UI as UI
  participant API as Backend
  participant R as Risk
  participant P as Paper Engine
  participant J as Journal
  U->>UI: Confirm paper preview
  UI->>API: confirmation + preview hash
  API->>R: revalidate current risk
  R-->>API: PASS or VETO
  API->>P: create paper event only on PASS
  P->>J: append order/fill/position events
  J-->>API: reconciled account state
  API-->>UI: updated paper state
```

## AI flow
```mermaid
flowchart LR
  U["User Task"] --> C["Context Engine"] --> S["Supervisor"]
  S --> TG["Tool Gateway"] --> D["Deterministic Services"]
  S --> MR["Model Router"] --> PG["Provider Gateway"]
  D --> E["Evidence"]
  PG --> E
  E --> RT["Red Team when decision-related"] --> A["Answer + Trace"]
```


---

# INCLUDED: 20_PROVIDERS_AND_INTEGRATIONS.md

# 20 - Providers and Integrations

## Market providers
Primary market facts come from public read-only futures data adapters. Secondary metadata providers may enrich display metadata but never replace futures decision fields. Provider calls are timeout-bounded, rate-limit aware and fail closed.

## AI providers
The AI Provider Gateway supports local, cloud and custom compatible providers. The application owns agents, prompts, tools, memory, context, policies, risk and deterministic calculations. Providers own model inference only.

## Separation rule
Tool Gateway and Provider Gateway are independent trust boundaries. An LLM may request a tool; the application validates and executes it. A provider cannot directly call domain internals or gain new permissions from prompt text.


---

# INCLUDED: 21_LIVE_DEMO_MOCK_REPLAY_DATA.md

# 21 - LIVE / DEMO / MOCK / REPLAY Data

- `LIVE_PUBLIC`: public read-only market data. No private keys.
- `DEMO`: deterministic local fixtures, fully offline.
- `REPLAY`: historical deterministic clock.
- `TEST`: isolated test database and fixtures.
- `SOAK`: long-running reliability profile with no external writes.

The active profile is visible globally. DEMO/REPLAY data is never labeled LIVE. Cached stale data may remain visible for inspection but cannot create a fresh publishable decision.


---

# INCLUDED: 22_CONFIGURATION_AND_ENVIRONMENT.md

# 22 - Configuration and Environment

Configuration is versioned and separated into domain policy, runtime settings, provider metadata and owner UI preferences.

## Non-secret runtime values
- API bind: `127.0.0.1:8000`
- Agent runtime bind: `127.0.0.1:7777`
- Database mode: SQLite WAL
- Default profile: DEMO on first safe launch
- Default language: owner-selectable Arabic/English
- Network exposure: loopback only

## Secrets
Provider credentials are stored backend-side only using a secret reference. They never appear in frontend configuration, source control, logs, memory, journal, screenshots or exported evidence. The package contains no secret values.


---

# INCLUDED: 23_SECURITY_ARCHITECTURE.md

# 23 - Security Architecture

## Hard prohibitions
- No live order route or signed exchange client.
- No withdrawal/transfer capability.
- No private exchange credentials.
- No prompt-based permission elevation.
- No raw secrets returned to frontend.

## Controls
Local owner authentication, HttpOnly session, CSRF on writes, loopback-only binding, input schema validation, ORM/parameterized DB access, output escaping, security headers, provider URL validation, secret redaction, audit events, append-only journal integrity, backup verification, dependency/secret/forbidden-surface scans.

## Custom provider SSRF control
Validate protocol, DNS resolution, resolved IP, redirects, TLS, port and response size. Explicit loopback is allowed for local AI. Cloud metadata/link-local/private LAN targets are rejected unless a future owner policy explicitly authorizes a narrow endpoint class.

## AI prompt injection
External research text is data only. It cannot alter system instructions, grant tools, modify risk or change skill permissions. Model output is schema/evidence validated before paper confirmation can be offered.


---

# INCLUDED: 24_ERROR_HANDLING_AND_EDGE_CASES.md

# 24 - Error Handling and Edge Cases

| ID | Code | Trigger | HTTP | User behavior |
| --- | --- | --- | --- | --- |
| ERR001 | AUTH_REQUIRED | No valid local session | 401 | Show login; preserve requested route |
| ERR002 | CSRF_REQUIRED | Write request lacks valid CSRF | 403 | Show safe retry message |
| ERR003 | DATA_STALE | Critical snapshot older than policy | 409 | Block publish/paper; show stale banner |
| ERR004 | DATA_MIXED | Critical fields not coherent in time | 409 | Block decision; show mixed-data detail |
| ERR005 | DATA_UNAVAILABLE | Required market data missing | 503 | Abstain; no candidate |
| ERR006 | PROVIDER_RATE_LIMITED | Provider returned rate limit | 503 | Backoff/circuit state; visible degraded status |
| ERR007 | STRATEGY_INELIGIBLE | Strategy disabled/research-only | 409 | No publish/paper |
| ERR008 | RISK_VETO | Hard risk gate failed | 409 | Display veto reason; no override |
| ERR009 | INVALID_GEOMETRY | Entry/stop/targets invalid | 422 | Reject plan |
| ERR010 | LOW_EFFECTIVE_R | Effective blended R below 2.0 | 409 | Reject plan |
| ERR011 | LIQUIDATION_UNSAFE | Modeled liquidation safety below policy | 409 | Reject plan |
| ERR012 | DAILY_LOCK | Daily realized loss lock active | 409 | Block new paper approval |
| ERR013 | WEEKLY_LOCK | Weekly realized loss lock active | 409 | Block new paper approval |
| ERR014 | CONFIRMATION_REQUIRED | Paper write lacks owner confirmation | 428 | Open confirmation UI |
| ERR015 | HASH_MISMATCH | Decision/config/skill integrity mismatch | 409 | Block use and raise audit event |
| ERR016 | JOURNAL_INTEGRITY_FAILURE | Hash chain fails verification | 500 | Switch to read-only safety mode |
| ERR017 | MODEL_UNAVAILABLE | No compatible healthy model | 503 | AI unavailable only; deterministic app continues |
| ERR018 | LOCAL_PROVIDER_UNAVAILABLE | LOCAL_ONLY task has no local model | 503 | Do not cloud-fallback |
| ERR019 | SKILL_POLICY_CONFLICT | Skill draft requests forbidden permission/policy | 409 | Block publish |
| ERR020 | BACKUP_INTEGRITY_FAILURE | Backup hash/schema invalid | 422 | Abort restore before switching data |

## Required edge cases
Null/non-finite values; missing candles; future bars; stale/mixed timestamps; 429/timeout/provider outage; invalid symbol; delisting; duplicate scan; duplicate paper confirmation; same-candle TP/SL; restart between fill and journal; locked DB; corrupt UI preferences; corrupt backup; AI provider removal while referenced; skill publish conflict; WebSocket gap; offline restart; low disk; thermal/battery heavy-job pause.


---

# INCLUDED: 25_RUNTIME_ARCHITECTURE.md

# 25 - Runtime Architecture

## Services
- Primary FastAPI application: `127.0.0.1:8000`.
- Agent runtime/AG-UI sidecar: `127.0.0.1:7777`.
- SQLite data files in app-private storage.
- React production assets served by the primary backend.
- Scheduler owned by one process/lock.

## Isolation
If AI or every model provider fails, Market, Scanner, Strategies, Risk, Paper, Journal, Backtest and Analytics continue. AI surfaces show unavailable state only.

## Boot
Config -> DB migration/integrity -> domain registries -> provider health -> scheduler lock -> API/WS -> static frontend -> ready.

## Shutdown
Stop new jobs -> persist job state -> close WebSockets -> flush audit/logs -> close DB -> exit.


---

# INCLUDED: 26_INSTALLATION_BUILD_AND_OPERATION.md

# 26 - Installation, Build and Operation

## Developer workstation
Target repository contains Python backend and React frontend with pinned lockfiles. Installation commands are intentionally supplied as starter scripts rather than external documentation.

## Android/Termux target
Use Termux host plus Ubuntu/PRoot compatibility profile. Python 3.12 is the release target for the backend/AI environment. Node is required only for frontend build/development; production serves static assets. Docker is not required on phone.

## Operational scripts
`STARTER_KIT/scripts/termux_install.sh`
`STARTER_KIT/scripts/run_local.sh`
`STARTER_KIT/scripts/stop_local.sh`
`STARTER_KIT/scripts/doctor.sh`

The scripts are build-time controllers. The final implementation must pin exact package versions before release and rerun clean-install acceptance on the target phone profile.


---

# INCLUDED: 27_TESTING_AND_QA_BLUEPRINT.md

# 27 - Testing and QA Blueprint

| ID | Category | Priority | Test | Expected |
| --- | --- | --- | --- | --- |
| TC-SEC-001 | Security | P0 | Search final tree for live-order/signed/private-key/withdrawal surfaces | Zero forbidden surface |
| TC-DATA-001 | Data | P0 | Closed-candle enforcement | Forming/future candle rejected from decision path |
| TC-DATA-002 | Data | P0 | Freshness boundary 119.999/120/120.001s | Policy boundary exact |
| TC-RISK-001 | Risk | P0 | Effective R boundary 1.99/2.00/2.01 | Only >=2.00 can pass this gate |
| TC-RISK-002 | Risk | P0 | Liquidation ratio 2.999/3.000/3.001 | Only >=3.000 passes |
| TC-RISK-003 | Risk | P0 | Calibration count 29/30/31 | Risk reduction applied through policy boundary |
| TC-RISK-004 | Risk | P0 | Newest two losses activate reducer | Reducer active; older losses do not falsely trigger |
| TC-PAPER-001 | Paper | P0 | TP1 -> BE -> TP2 50/50 accounting | Ledger and analytics reconcile |
| TC-PAPER-002 | Paper | P0 | TP1 -> BE -> SL accounting | Ledger and analytics reconcile |
| TC-PAPER-003 | Paper | P0 | Duplicate confirmation | Idempotent; no duplicate order/event |
| TC-JRN-001 | Journal | P0 | Tamper event payload | Hash-chain verifier finds first mismatch |
| TC-STRAT-001 | Strategy | P0 | Each S01/S02/S03/S07/S14 gate fail/pass fixtures | Deterministic exact rule behavior |
| TC-BT-001 | Backtest | P0 | Lookahead probe | Future data cannot influence signal |
| TC-BT-002 | Backtest | P1 | OOS/walk-forward/cost stress | Results labeled with sample/assumptions |
| TC-AI-001 | AI | P0 | Unsupported numeric claim | Evidence validator rejects or abstains |
| TC-AI-002 | AI | P0 | Prompt injection from research source | Instructions ignored; data treated untrusted |
| TC-AI-003 | AI | P0 | LOCAL_ONLY local model offline | No cloud fallback |
| TC-SKILL-001 | Skills | P0 | Protected skill disable | Rejected |
| TC-SKILL-002 | Skills | P1 | Draft tested hash differs before publish | Publish rejected |
| TC-PROV-001 | Provider | P1 | Delete optional provider | Agents/tools/memory unaffected; bindings validated |
| TC-WS-001 | Realtime | P1 | Disconnect + sequence gap | REST reconciliation before current state |
| TC-RTL-001 | UI | P1 | Arabic 320px and 200% zoom | No clipped primary content; finance numerics LTR |
| TC-A11Y-001 | UI | P1 | Keyboard/focus/reduced motion | All core flows accessible |
| TC-OFF-001 | Offline | P0 | Network disabled DEMO launch | Full deterministic demo without fake LIVE |
| TC-BKP-001 | Backup | P1 | Corrupt backup | Restore aborts before current data switch |
| TC-SOAK-001 | Reliability | P1 | 24-hour soak on release candidate | No duplicate scheduler, unbounded growth, stale-to-signal, integrity failure |

## Layers
L0 static/schema/import/build/security scans; L1 unit; L2 property/golden/mutation for critical domain modules; L3 integration API/DB/provider/jobs/backup; L4 browser/E2E/accessibility; L5 performance/chaos; L6 clean install/package/soak. A mandatory test that is skipped, blocked or failed prevents release PASS.


---

# INCLUDED: 28_REPOSITORY_AND_MODULE_MAP.md

# 28 - Repository and Module Map

```text
signal-desk/
  apps/
    web/
      src/app/
      src/shell/
      src/pages/
      src/features/
      src/components/
      src/api/
      src/state/
      src/i18n/
      src/theme/
    api/
      app/main.py
      app/api/
      app/domain/market/
      app/domain/scanner/
      app/domain/strategies/
      app/domain/decisions/
      app/domain/risk/
      app/domain/paper/
      app/domain/journal/
      app/domain/analytics/
      app/ai/
      app/skills/
      app/ops/
      app/storage/
      migrations/
  packages/
    contracts/
    schemas/
    design-tokens/
    strategy-definitions/
    skill-contracts/
  config/
    policies/
    strategies/
    runtime/
  tests/
    unit/
    property/
    integration/
    e2e/
    security/
    phone/
  scripts/
  docs/
  evidence/
```

Ownership is domain-first. Frontend utilities must not duplicate backend financial/domain calculations.


---

# INCLUDED: 29_DEPENDENCY_MAP.md

# 29 - Dependency Map

```mermaid
flowchart LR
  UI["React Web/PWA"] --> API["FastAPI REST + WebSocket"]
  API --> Domain["Deterministic Domain Services"]
  Domain --> DB["SQLite + Alembic"]
  Domain --> Market["Public Market Adapters"]
  Domain --> Scheduler["Scheduler / Jobs"]
  UI --> AgentUI["AI Desk / AG-UI"]
  AgentUI --> AgentRuntime["Agent Runtime"]
  AgentRuntime --> ToolGW["Tool Gateway"]
  ToolGW --> Domain
  AgentRuntime --> ModelRouter["Model Policy Router"]
  ModelRouter --> ProviderGW["AI Provider Gateway"]
  ProviderGW --> Models["Local / Cloud Models"]
```

## Mandatory dependency direction
UI -> API client -> backend application service -> deterministic domain -> repository/provider.
AI Agent -> Tool Gateway -> deterministic domain.
AI Agent -> Model Router -> Provider Gateway -> model.
Provider Gateway must never become a shortcut into domain state.
Skills may guide agents but cannot expand Tool Gateway permissions.


---

# INCLUDED: 30_TARGET_PRODUCT_CONTRACT.md

# 30 - Target Product Contract

This file intentionally contains no current-project status narrative. The target is one coherent Signal Desk application with the capabilities defined in this package, the Quiet Grid Terminal design system, the simplified nine-item primary navigation, deterministic financial authority, paper-only execution and an optional provider-independent AI Desk.

The developer must not preserve an old layout merely because a donor implementation used it. They must preserve the functional and safety contracts while building the target UI, routes, motion and module ownership specified here.


---

# INCLUDED: 31_FIGMA_HANDOFF.md

# 31 - Figma Handoff

## Figma pages
01 Foundations
02 Components
03 Desktop Screens
04 Tablet Screens
05 Mobile Screens
06 Data States
07 Dialogs & Drawers
08 Motion Storyboards
09 Prototypes

## Frame sizes
Desktop Wide 1600x1000
Desktop Core 1440x960
Tablet 834x1112
Mobile 390x844
Small Mobile 360x800

## Required desktop frames
Home, Market Workspace, Scanner, Decisions, Decision Detail, Strategy Lab, Backtest, Replay, Paper Desk, Journal, Analytics, AI Desk, AI Skills, AI Providers, AI Memory, AI Traces, System.

## Auto-layout
Use 4/8/12/16/24/32 spacing tokens. Rail fixed, context bar fixed, content fill, inspector fixed width 336 when open.

## Components
Build the components in `MATRICES/COMPONENT_CATALOG.csv` as variants before screen composition.

## Prototype motion
Use `CONTRACTS/motion_tokens.json`. No Smart Animate that introduces movement not defined in the motion contract.

## Visual source
`VISUALS/` contains developer-facing wireframe/mockup images for the new target direction.


---

# INCLUDED: 32_CONTRADICTIONS_AND_DESIGN_RESOLUTIONS.md

# 32 - Design Resolutions

## Resolution 1 - functional scope vs visual redesign
Functional/safety contracts are preserved. Historical/current visual layout is not authoritative because the owner explicitly requested a new simpler shape and motion system.

## Resolution 2 - AI vs deterministic authority
AI explains, researches, compares, critiques and orchestrates. Deterministic services own all decision-critical numbers and gates.

## Resolution 3 - many pages vs simple navigation
All capabilities remain, but the top-level navigation is reduced to Home, Market, Scan, Decisions, Strategies, Paper, Journal, AI and System. Secondary functionality becomes tabs/subroutes/inspectors.

## Resolution 4 - many market skills vs context size
Import the skill library but route only the smallest sufficient set. Source packs remain immutable.

## Resolution 5 - provider flexibility vs privacy
Providers are replaceable, but routing is constrained by privacy/capabilities/health. LOCAL_ONLY cannot cloud-fallback.


---

# INCLUDED: 33_REQUIREMENTS_TRACEABILITY_MATRIX.md

# 33 - Requirements Traceability Matrix

| Requirement | Feature | UI | Module | API | Data | Tests |
| --- | --- | --- | --- | --- | --- | --- |
| REQ-001 | F001 | System | Auth/API/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-002 | F002 | Global | Runtime/Config | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-003 | F003 | Global | Frontend/i18n | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-004 | F004 | Global | Frontend | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-005 | F005 | Market | Frontend/Storage | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-006 | F006 | Market/Scan | Market Data | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-007 | F007 | Market | Market Data/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-008 | F008 | Market/Scan | Market Data | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-009 | F009 | Market | Frontend/Chart | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-010 | F010 | Market | Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-011 | F011 | Market | Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-012 | F012 | Market/Scan | Market Data/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-013 | F013 | Market/Scan | Market Data/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-014 | F014 | Market/Paper | Market Data/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-015 | F015 | Home/Market | Domain/Frontend | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-016 | F016 | Scan | Scanner/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-017 | F017 | Scan | Scanner/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-018 | F018 | Scan | Scheduler/Scanner | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-019 | F019 | Scan/Decisions | Evidence Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-020 | F020 | Decisions | Decision Engine/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-021 | F021 | Decisions | Decision Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-022 | F022 | Decisions | Red Team | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-023 | F023 | AI/Decisions | AI Runtime | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-024 | F024 | Strategies | Strategy Engine/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-025 | F025 | Strategies | Strategy Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-026 | F026 | Strategies | Strategy Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-027 | F027 | Strategies | Strategy Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-028 | F028 | Backtest | Backtest Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-029 | F029 | Replay | Replay Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-030 | F030 | Analytics/Strategies | Analytics | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-031 | F031 | Paper/Decisions | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-032 | F032 | Paper/Decisions | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-033 | F033 | Paper/Decisions | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-034 | F034 | Paper/Decisions | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-035 | F035 | Home/Paper | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-036 | F036 | Paper | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-037 | F037 | Paper | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-038 | F038 | Paper/Risk | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-039 | F039 | Paper | Paper Engine/API | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-040 | F040 | Paper | Paper Engine/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-041 | F041 | Paper | Paper Engine/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-042 | F042 | Paper | Paper Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-043 | F043 | Journal/Audit | Journal/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-044 | F044 | Paper | Portfolio/Risk | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-045 | F045 | Analytics | Analytics | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-046 | F046 | Analytics | Analytics | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-047 | F047 | Analytics | Analytics | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-048 | F048 | System | Alerts/Scheduler | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-049 | F049 | Home/System | Brief/AI | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-050 | F050 | Home/System/AI | Providers | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-051 | F051 | System | Audit/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-052 | F052 | System | Backup/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-053 | F053 | System | Docs/UI | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-054 | F054 | AI | AI Runtime | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-055 | F055 | AI | Tool Gateway | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-056 | F056 | AI Providers | Provider Gateway | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-057 | F057 | AI Providers | Provider Gateway | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-058 | F058 | AI Providers | Provider Gateway/Security | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-059 | F059 | AI Memory | Memory | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-060 | F060 | AI Memory | Knowledge | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-061 | F061 | AI Skills | Skill Control | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-062 | F062 | AI Skills | Skill Control | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-063 | F063 | AI Traces | Skill Control/Audit | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-064 | F064 | AI Traces | AI Runtime/Audit | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-065 | F065 | AI Traces | Evaluation | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-066 | F066 | AI | Research Adapter | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-067 | F067 | Global | Runtime/Fixtures | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-068 | F068 | System | Runtime/Scripts | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-069 | F069 | System | Runtime/Ops | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-070 | F070 | Audit/System | Export | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-001 | F019 | Scan/Decisions | Evidence Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-002 | F007 | Market | Market Data/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-003 | F068 | System | Runtime/Scripts | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-004 | F003 | Global | Frontend/i18n | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-005 | F056 | AI Providers | Provider Gateway | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-006 | F051 | System | Audit/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |


---

# INCLUDED: 34_RECONSTRUCTION_MASTER_PLAN.md

# 34 - Reconstruction Master Plan

| Milestone | Name | Objective |
| --- | --- | --- |
| M0 | Blueprint Lock | Freeze contracts, source packs, security laws, design tokens and traceability. |
| M1 | Foundation | Monorepo, auth, DB, config, logging, local runtime, React shell. |
| M2 | Market Truth | Public provider adapters, universe, candles, snapshots, freshness, indicators, structure. |
| M3 | Scanner + Strategies | Scanner stages, ranking, Evidence Score, S01/S02/S03/S07/S14, decision cards. |
| M4 | Risk + Red Team | Risk v1.0, sizing, leverage, liquidation, locks, correlation, Red Team. |
| M5 | Paper + Journal | Preview/confirm, orders/fills/positions, 50/50 lifecycle, journal chain, portfolio. |
| M6 | Backtest + Replay + Analytics | Backtest, replay, OOS/walk-forward, Analytics V2, calibration. |
| M7 | Skill Control Plane | 166-skill import, registry, drafts, tests, impact, publish/rollback, profiles. |
| M8 | AI Desk | Tool Gateway, Provider Gateway, six agents, context, memory, knowledge, traces. |
| M9 | Target UI | Quiet Grid Terminal screens, responsive/RTL/accessibility/motion. |
| M10 | Operations | Alerts, data/provider health, audit, backup/restore, methodology/limitations. |
| M11 | Integrated QA | Security, anti-hallucination, E2E, accessibility, performance, chaos. |
| M12 | Phone Release | Termux clean install, package validation, 24h soak, final handoff. |

Each milestone is gated. A later milestone cannot hide an earlier P0/P1 blocker. The developer must record exact build/source identity and executed tests for every gate.


---

# INCLUDED: 35_ANTI_HALLUCINATION_VERIFICATION.md

# 35 - Anti-Hallucination Verification

Before claiming a module complete, verify: file exists, route exists, schema exists, formula matches locked policy, test actually executed, provider/model actually connected, data actually fresh, skill version actually active, and package hash actually computed.

Required truth labels in build/review reports: `CONFIRMED`, `INFERENCE`, `ASSUMPTION`, `UNKNOWN`, `BLOCKED`.

Forbidden claims without evidence: connected provider, current market data, successful tool call, passing test, full release, production-ready, complete security, successful fallback, valid backup/restore.

The final release evidence must come from the exact packaged tree, not historical logs from another source hash.


---

# INCLUDED: 37_AI_TRADING_DESK.md

# 37 - AI Trading Desk

## Six agents only
Supervisor, Research, Market Analyst, Strategy Analyst, Evidence, Red Team. Specialist market concepts are skills/tools, not additional top-level agents.

## Agent loop
Observe context -> understand intent -> plan -> select smallest skill/tool set -> use deterministic tools -> optional model reasoning -> verify -> evidence review -> Red Team where decision-related -> answer -> save permitted memory/evaluation.

## Run inspector
Every response can expose: run ID, agents, skill versions, provider/model, tool calls, evidence IDs, privacy class, risk state, Red Team result and evaluation. Hidden chain-of-thought is not displayed.

## Failure isolation
AI down = AI pages degraded. Deterministic trading workstation remains usable.


---

# INCLUDED: 38_AI_PROVIDER_GATEWAY.md

# 38 - AI Provider Gateway

```json
{
  "provider_independence": true,
  "providers": [
    "OLLAMA_LOCAL",
    "KIMI",
    "OLLAMA_CLOUD",
    "OPENAI_OPTIONAL",
    "CUSTOM_COMPATIBLE"
  ],
  "routing_modes": [
    "AUTO",
    "LOCAL_ONLY",
    "CLOUD_ONLY",
    "PRIVACY_FIRST",
    "QUALITY_FIRST",
    "COST_FIRST",
    "SPEED_FIRST",
    "MANUAL",
    "STRICT_STRUCTURED"
  ],
  "privacy_classes": [
    "PUBLIC",
    "INTERNAL",
    "PRIVATE_LOCAL_ONLY",
    "SECRET_NEVER_SEND_TO_MODEL"
  ],
  "capabilities": [
    "TEXT",
    "VISION",
    "TOOLS",
    "STREAMING",
    "STRUCTURED_OUTPUT",
    "REASONING",
    "FILES",
    "EMBEDDINGS_OPTIONAL"
  ],
  "rules": [
    "Agents never call a provider adapter directly.",
    "Tool Gateway is separate from Provider Gateway.",
    "LOCAL_ONLY never falls back to cloud.",
    "Model IDs are discovered/tested, not embedded in business logic.",
    "Provider removal cannot delete agent prompts, memory, tools, journal, risk, or decision history.",
    "Raw provider payloads are not persisted by default."
  ],
  "custom_provider_security": [
    "allow only approved protocol families",
    "validate scheme/host/IP/DNS/redirect/TLS/port",
    "allow explicit loopback for local AI",
    "block cloud metadata and arbitrary LAN scanning",
    "response-size and timeout bounds",
    "redact secrets and sensitive prompts"
  ]
}
```

## Provider lifecycle
ADDED -> UNTESTED -> HEALTHY/DEGRADED -> DISABLED -> REMOVED. Remove shows dependency report and requires replacement selection if the provider is referenced by an active routing policy.

## Audit fields
request_id, agent_id, provider_id, model_id, routing_policy, task_type, privacy_class, start/end, latency, success/failure, fallback_used, tool call identifiers, token counts when available, error category. Raw secrets are never logged.


---

# INCLUDED: 39_SKILL_CONTROL_PLANE.md

# 39 - Skill Control Plane

Source library size: 166 market skills. Source pack is immutable.

## Skill classes
SYSTEM, ENGINE_BACKED, ENGINE_BACKED_ANALYSIS, DETERMINISTIC_ENGINE, AI_REASONING, HYBRID_RESEARCH, QA_GUARD, ADMIN_AI.

## Lifecycle
Imported -> Classified -> Draft -> Validated -> Tested -> Published -> Active/Disabled -> Deprecated. Published versions are immutable. Edit clones to a draft.

## Publish gate
Schema + policy + contract + exact-hash tests + adversarial tests when AI + routing/dependency checks + impact analysis + owner publish.

## Protected boundaries
Skill editor cannot enable live trading, change root Tool Gateway permissions, bypass Risk, expose secrets, rewrite journal history or change market-data authority.

## Trace
Every AI run records exact skill slug/version/hash.


---

# INCLUDED: 40_CONTEXT_MEMORY_KNOWLEDGE.md

# 40 - Context, Memory and Knowledge

## Context bundle
Current owner request, page, symbol/timeframe, runtime profile, fresh market snapshot, active strategies, recent decisions, paper portfolio/risk locks, relevant journal references, relevant memory, available tools, provider policy.

Precedence: explicit current instruction > current UI selection > session > preferences > historical memory. Historical memory never overrides fresh market facts.

## Memory classes
1 Session conversation
2 User preferences
3 Decision references
4 Research memory with freshness/expiry
5 Strategy observations/calibration
6 Knowledge documents

Journal/decision truth is not stored as editable AI memory. V1 retrieval can use local SQLite FTS/BM25; embeddings are optional and must be versioned if added.


---

# INCLUDED: 41_MOTION_AND_INTERACTION_SYSTEM.md

# 41 - Motion and Interaction System

```json
{
  "principle": "Motion confirms hierarchy and state. No bouncing, decorative parallax, or attention-seeking loops.",
  "durations_ms": {
    "instant": 70,
    "fast": 110,
    "standard": 160,
    "drawer": 220,
    "modal": 180,
    "page": 180,
    "price_flash": 520
  },
  "easing": {
    "standard": "cubic-bezier(0.2,0,0,1)",
    "exit": "cubic-bezier(0.4,0,1,1)"
  },
  "patterns": {
    "page_change": "opacity 0->1 and translateY 4px->0",
    "drawer": "translateX 16px->0 and opacity 0->1",
    "dialog": "scale .985->1 and opacity 0->1",
    "row_selection": "background interpolation only",
    "price_tick": "single semantic background flash; no number bounce",
    "risk_veto": "one border-color transition; no repeated pulse",
    "chart_loading": "static skeleton bands with low-opacity pulse",
    "command_palette": "fade + 6px vertical settle"
  },
  "reduced_motion": "Disable transforms and animated scrolling; retain immediate state color changes only."
}
```

## Interaction rules
- Click a table row: select row and open inspector without page jump.
- Double activation is never required; mobile uses single tap.
- Escape closes overlay/drawer, never discards a committed change.
- Destructive or paper-write actions use explicit confirmation.
- Long asynchronous jobs show stage, elapsed time, cancel action and last verified output.
- Price changes use semantic flash only; do not animate digit position.
- Risk veto appears immediately and stays static until input changes.


---

# INCLUDED: 42_TERMUX_PHONE_RUNTIME.md

# 42 - Termux / Android Runtime

Target release profile: Termux host + Ubuntu/PRoot compatibility environment + Python 3.12 backend/AI runtime. React is built to static files. Services bind only to loopback. No Docker required.

## Resource policy
Scanner REST concurrency 6; symbol analysis concurrency 4; AI agent concurrency 2; backtest concurrency 1; memory retrieval top-K 8; bounded logs 25MB x5/process; WebSocket queue 2000; minimum free disk 2GB. Heavy bulk/backtest work pauses under severe thermal or very low battery conditions when detectable.

## Scripts
The starter kit includes installation, start, stop and doctor controllers. Final release must pin dependency versions and prove clean install on the target phone.


---

# INCLUDED: 43_DEVELOPER_STARTER_KIT_GUIDE.md

# 43 - Developer Starter Kit Guide

The starter kit is an interface-first scaffold, not the finished application. It contains design tokens, motion tokens, routes, type contracts, backend Protocols, database logical schema, policy files and local runtime scripts.

The developer should copy contracts into the real repository, implement domain modules behind them, then replace the logical SQL with Alembic migrations and replace sample run scripts with release-tested versions.

No starter file is allowed to weaken safety rules because it is convenient to implement.


---

# INCLUDED: 44_BUILD_EXECUTION_CONTROLLER.md

# 44 - Build Execution Controller

```text
PROJECT=SIGNAL_DESK
MODE=BUILD_FROM_TARGET_BLUEPRINT
SOURCE_OF_TRUTH=THIS_PACKAGE
VISUAL_SYSTEM=QUIET_GRID_TERMINAL
LIVE_TRADING=FORBIDDEN
PRIVATE_EXCHANGE_KEYS=FORBIDDEN
SIGNED_EXCHANGE_REQUESTS=FORBIDDEN
PAPER_TRADING=ENABLED
DETERMINISTIC_NUMERIC_AUTHORITY=REQUIRED
AI_READ_ONLY_ADVISORY=REQUIRED
SKILL_CONTROL_PLANE=REQUIRED
AI_PROVIDER_GATEWAY=REQUIRED
ANDROID_TERMUX_TARGET=REQUIRED
NO_PARALLEL_REPLACEMENT_APP=TRUE
NO_UNDOCUMENTED_FEATURE_REMOVAL=TRUE

Execute M0 through M12 in order.
For every milestone: implement actual source, run required tests, preserve commands/exit codes/evidence, fix failures, rerun, update traceability.
Do not claim PASS from this Blueprint.
Do not change locked risk/data/safety rules without a new versioned owner decision.
Do not recreate the old visual layout; implement Quiet Grid Terminal from Design/Figma/Motion contracts.
Final delivery requires clean install, full mandatory QA, package verification and target-phone soak.
```


---

# INCLUDED: 45_RELEASE_ACCEPTANCE_GATES.md

# 45 - Release Acceptance Gates

G1 Source/requirements traceability complete.
G2 Zero live-trading/private-key/signed-order surface.
G3 Deterministic market/strategy/evidence/risk/paper/accounting tests pass.
G4 Strategy and Risk policy versions exact.
G5 Paper lifecycle and journal reconcile.
G6 Backtest no-lookahead/cost/OOS gates pass.
G7 AI cannot create unsupported numbers or bypass tools/risk/privacy.
G8 Skill publish/rollback/protected permissions pass.
G9 Quiet Grid Terminal desktop/tablet/mobile/RTL/accessibility approved.
G10 Backup/restore and restart recovery pass.
G11 Clean Termux target install and local run pass.
G12 24-hour soak completed on exact release candidate.
G13 Final ZIP re-extracted, checksum-verified, no secrets/caches/dependency directories.

Any unresolved P0/P1 or mandatory skipped test prevents VERIFIED RELEASE.
