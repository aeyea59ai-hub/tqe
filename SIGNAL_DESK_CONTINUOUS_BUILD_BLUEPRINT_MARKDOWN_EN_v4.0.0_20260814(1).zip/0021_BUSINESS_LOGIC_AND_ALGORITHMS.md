# 17 - Business Logic and Algorithms

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/17_BUSINESS_LOGIC_AND_ALGORITHMS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Data finality
Only validated closed candles may enter authoritative indicators, structure, scanner, strategies or decisions. Critical snapshot freshness limit is 120 seconds. Gaps/future/non-finite/mixed critical data fail closed.

## Evidence Score
Weights: 15 Data Integrity, 15 Regime Alignment, 10 Multi-Timeframe Structure, 10 Momentum, 10 Volume/Liquidity, 15 Strategy Match, 10 Derivatives Context, 15 Trade-Plan/Risk Quality. Raw total 100; display cap 90; degraded cap 79. Missing optional evidence contributes zero.

## Risk v1.0
- LONG risk 0.50% equity.
- SHORT risk 0.35% equity.
- Hard per-trade cap 1.00%.
- First 30 closed paper trades: 0.25%.
- After two consecutive realized losses: 0.25% until next realized win.
- LONG leverage <=5x; SHORT <=3x.
- Daily lock -2R; weekly lock -6R.
- Maximum two BTC-correlated positions.
- Effective blended R >=2.0 after costs.
- Modeled liquidation distance >=3x stop distance.
- Publishable/paper scope initially BTCUSDT and ETHUSDT; other instruments remain research-only until versioned promotion.

## Position sizing
`risk_amount = equity * effective_risk_fraction`
`raw_quantity = risk_amount / abs(entry - stop)`
Quantity is quantized down to instrument step size and rechecked so actual quantized risk does not exceed the active cap. Invalid or zero stop distance rejects.

## Paper fill model
Entry is simulated using the configured paper fill rule. TP1 closes 50%, then stop moves to cost-adjusted break-even. TP2 closes the remaining 50%. Same-candle ambiguity is resolved conservatively adverse-first unless lower-resolution sequence evidence proves event order. Fees/slippage/funding are journaled as independent deterministic events.

## Red Team
R1 Data Skeptic; R2 Counter-Thesis; R3 Risk Officer; R4 Execution Realist; R5 Statistician; R6 Process Auditor. Hard objection classes are non-overridable. Red Team never approves; it only objects or reports no material objection.

## Primary strategy contracts

### S01
```yaml
# S01 — ATM Asymmetric Trend/Momentum (file 06 §3).
# Values are candidate defaults, not profitability claims.
id: strategy
strategy_id: S01
name: "ATM Asymmetric Trend/Momentum"
version: 1.0.0
status: draft_numeric
payload:
  note: "candidate defaults, not profitability claims"
  timeframes: {regime: "1d", setup: "4h", trigger: "15m"}
  rules:
    ema_pairs: [[8, 24], [16, 48], [32, 96]]
    momentum_long_min: "1.0"
    momentum_short_max: "-1.5"
    volatility_block_percentile: "97"
    volatility_watch_percentile: "5"
    structure_shift_window_bars: 12
    no_chase_max_atr: "1.5"
    stop_atr_multiple: "2.0"
    tp1_r: "1.5"
    tp2_r: "3.0"
    expiry_bars: 16

```

### S02
```yaml
# S02 — EMA Pullback Trend Continuation (file 06 §4).
# Values are candidate defaults, not profitability claims.
id: strategy
strategy_id: S02
name: "EMA Pullback Trend Continuation"
version: 1.0.0
status: draft_numeric
payload:
  note: "candidate defaults, not profitability claims"
  timeframes: {regime: "1d", setup: "4h", trigger: "15m"}
  rules:
    trend_ema_period: 50
    pullback_tolerance_atr: "0.5"
    pullback_lookback_bars: 6
    min_volume_baseline_ratio: "0.7"
    no_chase_max_atr: "1.5"
    stop_buffer_atr: "0.5"
    tp1_r: "1.5"
    tp2_r: "3.0"
    expiry_bars: 12
    short_requires_confirmed_downtrend: true

```

### S03
```yaml
# S03 — Breakout-Retest (file 06 §5).
# Values are candidate defaults, not profitability claims.
id: strategy
strategy_id: S03
name: "Breakout-Retest"
version: 1.0.0
status: draft_numeric
payload:
  note: "candidate defaults, not profitability claims"
  timeframes: {setup: "4h", trigger: "15m"}
  rules:
    range_window_bars: 40
    range_max_width_atr: "3.0"
    range_min_touches: 2
    breakout_search_bars: 12
    min_breakout_volume_ratio: "1.5"
    retest_tolerance_atr: "0.3"
    stop_buffer_atr: "0.5"
    no_chase_max_atr: "1.0"
    tp1_r: "1.5"
    tp2_r: "3.0"
    expiry_bars: 10

```

### S07
```yaml
# S07 — Range Rejection (file 06 §6).
# Values are candidate defaults, not profitability claims.
id: strategy
strategy_id: S07
name: "Range Rejection"
version: 1.0.0
status: draft_numeric
payload:
  note: "candidate defaults, not profitability claims"
  timeframes: {regime: "4h", setup: "15m"}
  rules:
    range_window_bars: 60
    range_max_width_atr: "4.0"
    range_min_touches: 2
    range_min_age_bars: 20
    flat_slope_max: "0.03"
    edge_tolerance_pct: "0.2"
    min_volume_baseline_ratio: "0.8"
    stop_buffer_atr: "0.5"
    no_chase_max_atr: "1.0"
    expiry_bars: 8

```

### S14
```yaml
# S14 — VWAP Session Pullback (file 06 §7).
# Values are candidate defaults, not profitability claims.
id: strategy
strategy_id: S14
name: "VWAP Session Pullback"
version: 1.0.0
status: draft_numeric
payload:
  note: "candidate defaults, not profitability claims"
  timeframes: {setup: "15m", trigger: "15m"}
  rules:
    session_start_hour_utc: 7
    session_end_hour_utc: 16
    exit_before_session_end_bars: 4
    trend_ema_fast: 20
    trend_ema_slow: 50
    band_atr: "0.25"
    pullback_lookback_bars: 8
    stop_atr_multiple: "1.5"
    no_chase_max_atr: "1.0"
    tp1_r: "1.5"
    tp2_r: "2.5"
    expiry_bars: 16

```
