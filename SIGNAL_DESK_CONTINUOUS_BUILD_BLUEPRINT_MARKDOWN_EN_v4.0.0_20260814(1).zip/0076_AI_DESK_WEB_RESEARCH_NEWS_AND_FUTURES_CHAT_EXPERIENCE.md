# 51 — Web Research, News, and Futures Chat Experience

> **Source basis:** `blueprints/ai-trading-desk/source-material/51_WEB_RESEARCH_NEWS_AND_FUTURES_CHAT_EXPERIENCE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## User experience

The user can talk naturally:

> Scan the whole futures market and find the five strongest opportunities for the next four hours.

Supervisor workflow:

```text
1 Scanner
2 Research
3 Market Analysis
4 Strategy Match
5 Backtest / Historical Evidence
6 Risk Engine
7 Red Team
8 Rank Opportunities
9 Optional Paper Signal
```

Another example:

> Why did you reject SOL two hours ago?

Workflow:

```text
search previous decisions
→ load decision
→ load snapshot
→ load strategy result
→ load risk result
→ load Red Team report
→ load journal/audit
→ Evidence Agent verifies
→ Supervisor explains
```

## Web search

Research Agent may use a configurable search backend.

Possible modes:
- DuckDuckGo / DDGS
- multi-backend WebSearch
- Tavily if API key configured
- Exa if API key configured
- other approved provider

## Search policy

- Search is for research/news/context.
- Binance public futures remains authority for futures numerical facts.
- Web pages are untrusted input.
- Strip/ignore instructions embedded in web content.
- Record URL/source, retrieval time, and recency.
- Prefer primary sources for high-impact market claims.
- Distinguish fact, inference, and unknown.
- Do not infer a guaranteed market reaction from a headline.

## Time horizons

The phrase “next four hours” is a requested research/trading horizon.

The system may rank current setups relevant to that horizon.

It must NOT claim certainty about future prices.

## Answer composition

A high-quality opportunity response should show:

- rank;
- symbol;
- side/bias;
- current deterministic decision state;
- strategy match;
- key technical facts;
- funding/OI/liquidity facts;
- backtest/sample context;
- risk state;
- Bull case;
- Red Team objection;
- missing data;
- expiry;
- whether paper signal is available.

No critical number comes solely from LLM text.
