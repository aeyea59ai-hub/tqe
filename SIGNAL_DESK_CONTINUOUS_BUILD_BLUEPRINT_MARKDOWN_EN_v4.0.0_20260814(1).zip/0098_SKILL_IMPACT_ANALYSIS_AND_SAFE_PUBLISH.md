# Impact analysis before skill publish

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/05_SKILL_IMPACT_ANALYSIS_AND_SAFE_PUBLISH.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

Every draft publish must generate an impact report.

## Report

- current version → proposed version;
- content diff;
- changed routing tags;
- changed agent bindings;
- changed provider policy;
- changed context requirements;
- changed tool bindings requested;
- dependent skills;
- affected routes/workflows;
- affected tests;
- security/risk classification;
- migration needed? yes/no;
- rollback target;
- expected behavior change.

## Hard blocks

Publishing is blocked if:
- requested tool permission exceeds allowed class;
- draft conflicts with a locked system policy;
- mandatory tests are missing/failing;
- content hash differs from tested hash;
- dependency cycle is introduced;
- schema becomes incompatible without migration;
- risk/security review is required but absent.

## Canary option

For non-system AI skills:

`Publish to TEST profile → compare → optionally promote to DEFAULT`.

Do not canary deterministic risk logic through LLM configuration.
