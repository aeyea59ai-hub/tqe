# Open Risks and Owner Decisions

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/22_OPEN_RISKS_AND_OWNER_DECISIONS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. No owner decision blocks implementation start

Every required technical ambiguity is either closed or disabled. The following future decisions do not block Phases 0-8:

| ID | Future decision | Current default |
|---|---|---|
| OD-001 | Purchase a historical derivatives dataset | No; Price Core plus prospective collection |
| OD-002 | Use a read-only API key for top-trader ratios | No; feature OFF |
| OD-003 | Enable a 40% partial exit at 2R | No; separately versioned later |
| OD-004 | Enable a macro-blackout provider | No; OFF |
| OD-005 | Make ATM paper-actionable | Only after promotion gates |

## 2. Residual risks

| Risk | Probability/Impact | Mitigation |
|---|---|---|
| ATM has no edge after costs | High/High | Accept a negative result as valid research |
| SHORT tail risk | High/High | Stricter conditions, smaller size, separate reporting |
| Historical derivatives coverage is incomplete | Confirmed/High | Variants and prospective collection |
| Trailing-only does not fit the current card | Confirmed/Medium | Research schema; promotion blocker |
| Full-universe load | Medium/Medium | Bounded batches plus truthful coverage |
| API documentation changes | Medium/Medium | Endpoint snapshot and version review |
| Overfitting | High/High | Parameter cap, OOS, walk-forward, DSR |

## 3. Owner authority

Any change to the defaults above requires an explicit owner decision, a new Strategy Version, and traceability/test updates.
