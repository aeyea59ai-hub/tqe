# Continuous Build Mode

## Working method

Implementation proceeds in small vertical slices that connect domain behavior, storage, API, UI and tests where applicable. Each meaningful change is followed immediately by the most relevant syntax, type, contract, unit or integration checks. A failing check is corrected at its root, a regression test is added when useful, and the affected checks are rerun.

## Automatic continuation

When the current slice passes its relevant checks, work continues automatically to the next slice. Routine owner confirmation is unnecessary. When a particular external tool, browser, network endpoint or runtime is unavailable, that individual verification is recorded as `NOT_RUN_ENVIRONMENT`, while every independent implementation and verification task continues.

## Evidence

For each completed slice, preserve the changed files, requirement IDs, commands, environment versions, timestamps, exit codes, outputs, source-tree identity and resulting artifacts. Historical results provide context only; fresh execution establishes the current result.

## Delivery posture

The build remains active until the functional scope is implemented, the available verification matrix is executed, release artifacts are generated, and remaining environment-dependent checks are precisely identified.
