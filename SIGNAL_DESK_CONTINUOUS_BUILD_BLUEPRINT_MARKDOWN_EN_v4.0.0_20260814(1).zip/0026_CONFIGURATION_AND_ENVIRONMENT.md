# 22 - Configuration and Environment

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/22_CONFIGURATION_AND_ENVIRONMENT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

Configuration is versioned and separated into domain policy, runtime settings, provider metadata and owner UI preferences.

## Non-secret runtime values
- API bind: `127.0.0.1:8000`
- Agent runtime bind: `127.0.0.1:7777`
- Database mode: SQLite WAL
- Default profile: DEMO on first safe launch
- Default language: owner-selectable Arabic/English
- Network exposure: loopback only

## Secrets
Provider credentials are stored backend-side only using a secret reference. They never appear in frontend configuration, source control, logs, memory, journal, screenshots or exported evidence. The package contains no secret values.
