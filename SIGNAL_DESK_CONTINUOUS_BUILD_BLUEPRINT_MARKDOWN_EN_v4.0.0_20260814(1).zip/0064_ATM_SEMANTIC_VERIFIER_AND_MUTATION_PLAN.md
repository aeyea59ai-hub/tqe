# Semantic Verifier and Mutation Plan

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/18_SEMANTIC_VERIFIER_AND_MUTATION_PLAN.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Objective

The Semantic Verifier must not stop at file presence, JSON syntax, or SHA matching. It must understand governing invariants and prove that a prohibited semantic change produces FAIL.

## 2. Inputs

- source Git tree hash.
- strategy/risk/data contracts.
- schemas and cross-field validators.
- tests and evidence index.
- DB migration graph.
- API route inventory.
- feature flag definitions.
- release manifest.

## 3. Check layers

1. **Identity:** source/config/dataset/evidence hashes.
2. **Contract:** required fields/enums/versions.
3. **Cross-field:** VAL-001…VAL-025.
4. **Surface:** API/DB/UI/egress/secret forbidden surfaces.
5. **Evidence:** every claim references same-tree rerunnable evidence.
6. **Mutation:** injected defects must be killed.

## 4. Mutation catalog

| ID | mutation | severity | required detector |
|---|---|---|---|
| MUT-001 | empty permissive schema | P0 | schema semantic baseline |
| MUT-002 | DATA_UNAVAILABLE allowed as setup | P0 | VAL-001 |
| MUT-003 | Risk VETO ignored | P0 | VAL-002 |
| MUT-004 | ATM Research creates Paper Order | P0 | VAL-004/API scan |
| MUT-005 | observed_at added to content hash | P0 | hash determinism |
| MUT-006 | risk cap changed silently | P0 | policy hash/contract |
| MUT-007 | ATM actionability default true | P0 | feature flag guard |
| MUT-008 | new Binance order endpoint | P0 | forbidden route scan |
| MUT-009 | private API secret field | P0 | secret/schema scan |
| MUT-010 | stale snapshot marked VALID | P0 | cross-field validator |
| MUT-011 | fixed TP fabricated for trailing-only ATM | P1 | exit-model contract |
| MUT-012 | OI forward-filled through gaps | P1 | dataset gap test |
| MUT-013 | recent 30d data labeled multi-year | P0 | coverage verifier |
| MUT-014 | old S01 version payload edited | P0 | immutable version hash |
| MUT-015 | test oracle changed to fabricate price | P0 | oracle allowlist/semantic check |
| MUT-016 | release says COMPLETE with tests absent | P0 | claim verifier |
| MUT-017 | evidence from different commit | P0 | same-tree check |
| MUT-018 | object key order changes hash | P1 | canonicalization test |
| MUT-019 | quantity rounded upward beyond risk | P0 | risk property |
| MUT-020 | UI hides Research Only badge | P1 | UI contract test |

## 5. Required thresholds

- P0 mutations killed: 100%.
- Overall mutation kill: ≥90%.
- Any surviving P0 mutation = Semantic Verification FAIL.
- The mutation runner requires self-tests and tamper evidence.

## 6. Proof procedure

1. Run clean baseline → PASS.
2. Apply one mutation at a time to disposable tree.
3. Run verifier.
4. Require non-zero exit + exact finding ID.
5. Restore clean tree by checkout, not manual repair.
6. Save mutation diff/hash/output.
7. Re-run clean tree → PASS.

## 7. Status in this package

`PLANNED` - implementation progresses to executable mutation evidence and recorded kill results.
