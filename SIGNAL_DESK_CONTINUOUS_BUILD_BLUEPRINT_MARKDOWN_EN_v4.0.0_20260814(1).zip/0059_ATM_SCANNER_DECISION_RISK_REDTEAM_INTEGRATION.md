# Scanner, Decision, Risk, and Red Team Integration

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/13_SCANNER_DECISION_RISK_REDTEAM_INTEGRATION.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Universe

- Every eligible USDT-M perpetual appears in Market Universe.
- ATM has no hard-coded symbol list.
- Schedule deep evaluation in bounded batches, but do not display 100% coverage unless every eligible instrument was evaluated in the scan cycle.

## 2. Scanner lane

### Shared path remains unchanged

Integrity -> History/Liquidity -> Cheap ranking -> MTF -> Derivatives -> Strategy -> Risk/Red Team -> Decision.

### ATM research lane

- Runs in parallel only after snapshot qualification.
- Results do not enter actionable rankings.
- May expose a separate research rank without mixing it with the official Strategy Score.
- Every exclusion has a reason code.

## 3. Risk observation

Risk Engine uses the same governing policy, but labels its verdict `OBSERVATION_ONLY`.

Hard failures include:

- stale or invalid snapshot;
- invalid geometry;
- risk-fraction or cap breach;
- minimum exchange filters;
- leverage cap;
- missing or invalid MMR when a liquidation claim is requested;
- portfolio lock or correlation breach.

A risk pass does not make ATM actionable.

## 4. Red Team

Evaluate:

- data integrity;
- counter-trend conflict;
- crowding and funding tail risk;
- short-squeeze risk;
- stop noise and geometry;
- dataset mismatch;
- backtest leakage;
- unsupported actionability.

The owner or AI cannot override a hard veto inside the same evaluation. An override requires a new Strategy Version or Policy change, not a manual response.

## 5. Decision precedence

1. Data unavailable or stale.
2. Strategy disabled or Research Only guard.
3. Portfolio lock or Risk veto.
4. Red Team hard veto.
5. Strategy rules.
6. Evidence Score.
7. AI explanation.

AI always runs last and cannot affect any preceding state.
