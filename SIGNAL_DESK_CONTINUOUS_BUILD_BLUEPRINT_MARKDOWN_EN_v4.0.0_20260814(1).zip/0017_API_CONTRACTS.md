# 13 - API Contracts

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/13_API_CONTRACTS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

All API paths use `/api/v1`. Every write is authenticated, CSRF-protected and audit logged. Paper writes require confirmation binding.

| ID | Method | Path | Domain | Purpose | Auth | Write |
| --- | --- | --- | --- | --- | --- | --- |
| API001 | GET | /api/v1/health | System | Liveness | NONE | False |
| API002 | GET | /api/v1/ready | System | Readiness | NONE | False |
| API003 | GET | /api/v1/version | System | Build/policy/schema identity | NONE | False |
| API004 | GET | /api/v1/auth/mode | Auth | Auth setup status | NONE | False |
| API005 | POST | /api/v1/auth/setup | Auth | Initial owner setup | NONE | True |
| API006 | POST | /api/v1/auth/login | Auth | Create local session | NONE | True |
| API007 | POST | /api/v1/auth/logout | Auth | Invalidate session | SESSION | True |
| API008 | GET | /api/v1/auth/session | Auth | Session facts | SESSION | False |
| API009 | GET | /api/v1/markets | Market | Eligible universe | SESSION | False |
| API010 | GET | /api/v1/markets/:symbol/snapshot | Market | Immutable market snapshot | SESSION | False |
| API011 | GET | /api/v1/markets/:symbol/candles | Market | Closed candles | SESSION | False |
| API012 | GET | /api/v1/markets/:symbol/features | Market | Indicators/structure/regime | SESSION | False |
| API013 | GET | /api/v1/markets/:symbol/derivatives | Market | Funding/OI context | SESSION | False |
| API014 | GET | /api/v1/markets/:symbol/liquidity | Market | Spread/depth/liquidity | SESSION | False |
| API015 | GET | /api/v1/markets/breadth | Market | Breadth/heatmap facts | SESSION | False |
| API016 | POST | /api/v1/scans | Scanner | Start manual scan | SESSION | True |
| API017 | GET | /api/v1/scans | Scanner | List scans | SESSION | False |
| API018 | GET | /api/v1/scans/:id | Scanner | Scan state/stages | SESSION | False |
| API019 | GET | /api/v1/scans/:id/rankings | Scanner | Ranked candidates | SESSION | False |
| API020 | GET | /api/v1/scans/:id/exclusions | Scanner | Exclusion reasons | SESSION | False |
| API021 | POST | /api/v1/scans/:id/cancel | Scanner | Cancel scan | SESSION | True |
| API022 | GET | /api/v1/decisions | Decision | Decision queue | SESSION | False |
| API023 | GET | /api/v1/decisions/:id | Decision | Decision card | SESSION | False |
| API024 | GET | /api/v1/decisions/:id/evidence | Decision | Evidence/provenance | SESSION | False |
| API025 | GET | /api/v1/decisions/:id/red-team | Decision | Red Team objections | SESSION | False |
| API026 | GET | /api/v1/decisions/:id/trace | Decision | Rule/risk/version trace | SESSION | False |
| API027 | GET | /api/v1/strategies | Strategy | Registry | SESSION | False |
| API028 | GET | /api/v1/strategies/:id | Strategy | Strategy version/detail | SESSION | False |
| API029 | POST | /api/v1/strategies/:id/drafts | Strategy | Create draft | SESSION | True |
| API030 | POST | /api/v1/strategy-drafts/:id/validate | Strategy | Validate draft | SESSION | True |
| API031 | POST | /api/v1/strategy-drafts/:id/test | Strategy | Run strategy contract tests | SESSION | True |
| API032 | POST | /api/v1/strategy-drafts/:id/publish | Strategy | Publish approved version | SESSION | True |
| API033 | POST | /api/v1/backtests | Backtest | Start backtest | SESSION | True |
| API034 | GET | /api/v1/backtests/:id | Backtest | Backtest status/result | SESSION | False |
| API035 | GET | /api/v1/backtests/:id/artifacts | Backtest | Artifacts/manifest | SESSION | False |
| API036 | POST | /api/v1/replays | Replay | Start replay | SESSION | True |
| API037 | GET | /api/v1/replays/:id | Replay | Replay state | SESSION | False |
| API038 | POST | /api/v1/replays/:id/step | Replay | Advance replay | SESSION | True |
| API039 | POST | /api/v1/risk/check | Risk | Risk verdict | SESSION | True |
| API040 | GET | /api/v1/risk/state | Risk | Locks/heat/correlation | SESSION | False |
| API041 | GET | /api/v1/risk/policy | Risk | Active policy | SESSION | False |
| API042 | POST | /api/v1/paper/preview | Paper | Create deterministic preview hash | SESSION | True |
| API043 | POST | /api/v1/paper/confirm | Paper | Confirm paper action | SESSION | True |
| API044 | GET | /api/v1/paper/orders | Paper | List paper orders | SESSION | False |
| API045 | GET | /api/v1/paper/fills | Paper | List paper fills | SESSION | False |
| API046 | GET | /api/v1/paper/positions | Paper | List positions | SESSION | False |
| API047 | POST | /api/v1/paper/positions/:id/close-preview | Paper | Preview manual close | SESSION | True |
| API048 | POST | /api/v1/paper/positions/:id/close-confirm | Paper | Confirm manual close | SESSION | True |
| API049 | POST | /api/v1/paper/orders/:id/cancel-preview | Paper | Preview cancel | SESSION | True |
| API050 | POST | /api/v1/paper/orders/:id/cancel-confirm | Paper | Confirm cancel | SESSION | True |
| API051 | GET | /api/v1/portfolio | Portfolio | Equity/exposure/heat/PnL | SESSION | False |
| API052 | GET | /api/v1/journal | Journal | Journal stream | SESSION | False |
| API053 | GET | /api/v1/journal/:id | Journal | Journal entry detail | SESSION | False |
| API054 | GET | /api/v1/journal/integrity | Journal | Hash-chain verification | SESSION | False |
| API055 | GET | /api/v1/journal/export | Journal | Evidence-safe journal export | SESSION | False |
| API056 | GET | /api/v1/analytics/overview | Analytics | Overview metrics | SESSION | False |
| API057 | GET | /api/v1/analytics/trades | Analytics | Trade analytics | SESSION | False |
| API058 | GET | /api/v1/analytics/breakdowns | Analytics | Strategy/symbol/regime/side breakdowns | SESSION | False |
| API059 | GET | /api/v1/analytics/risk-costs | Analytics | Risk/cost analytics | SESSION | False |
| API060 | GET | /api/v1/analytics/execution | Analytics | Paper execution analytics | SESSION | False |
| API061 | GET | /api/v1/analytics/calibration | Analytics | Calibration metrics | SESSION | False |
| API062 | GET | /api/v1/analytics/data-quality | Analytics | Data quality metrics | SESSION | False |
| API063 | GET | /api/v1/alerts | Operations | Alerts | SESSION | False |
| API064 | POST | /api/v1/alerts/:id/ack | Operations | Acknowledge alert | SESSION | True |
| API065 | GET | /api/v1/daily-brief | Operations | Daily brief | SESSION | False |
| API066 | GET | /api/v1/audit | Operations | Audit events | SESSION | False |
| API067 | GET | /api/v1/data-health | Operations | Market/provider data health | SESSION | False |
| API068 | POST | /api/v1/backups | Operations | Create local backup | SESSION | True |
| API069 | POST | /api/v1/restores/validate | Operations | Validate backup before restore | SESSION | True |
| API070 | POST | /api/v1/restores/confirm | Operations | Confirm validated local restore | SESSION | True |
| API071 | POST | /api/v1/ai/chat | AI | Start/continue AI task | SESSION | True |
| API072 | GET | /api/v1/ai/runs | AI | List AI runs | SESSION | False |
| API073 | GET | /api/v1/ai/runs/:id | AI | Run trace/evaluation | SESSION | False |
| API074 | POST | /api/v1/ai/runs/:id/stop | AI | Stop in-flight AI run | SESSION | True |
| API075 | GET | /api/v1/ai/agents | AI | Agent roster/policies | SESSION | False |
| API076 | GET | /api/v1/ai/providers | AI | Provider registry | SESSION | False |
| API077 | POST | /api/v1/ai/providers | AI | Add provider | SESSION | True |
| API078 | PATCH | /api/v1/ai/providers/:id | AI | Update provider metadata/policy | SESSION | True |
| API079 | DELETE | /api/v1/ai/providers/:id | AI | Remove provider after dependency check | SESSION | True |
| API080 | POST | /api/v1/ai/providers/:id/test | AI | Connection/capability test | SESSION | True |
| API081 | GET | /api/v1/ai/providers/:id/models | AI | Discovered models | SESSION | False |
| API082 | GET | /api/v1/ai/routing | AI | Routing policies | SESSION | False |
| API083 | PUT | /api/v1/ai/routing | AI | Update routing policy | SESSION | True |
| API084 | GET | /api/v1/ai/memory | AI | Search/list memory | SESSION | False |
| API085 | POST | /api/v1/ai/memory/preferences | AI | Update user preference memory | SESSION | True |
| API086 | DELETE | /api/v1/ai/memory/conversations/:id | AI | Delete allowed conversation memory | SESSION | True |
| API087 | GET | /api/v1/ai/knowledge | AI | Search knowledge | SESSION | False |
| API088 | GET | /api/v1/skills | Skills | Skill registry | SESSION | False |
| API089 | GET | /api/v1/skills/:slug | Skills | Skill detail | SESSION | False |
| API090 | POST | /api/v1/skills/:slug/drafts | Skills | Create skill draft | SESSION | True |
| API091 | PATCH | /api/v1/skill-drafts/:id | Skills | Edit skill draft | SESSION | True |
| API092 | POST | /api/v1/skill-drafts/:id/validate | Skills | Validate draft | SESSION | True |
| API093 | POST | /api/v1/skill-drafts/:id/test | Skills | Test exact draft hash | SESSION | True |
| API094 | POST | /api/v1/skill-drafts/:id/impact | Skills | Impact analysis | SESSION | True |
| API095 | POST | /api/v1/skill-drafts/:id/publish | Skills | Publish tested draft | SESSION | True |
| API096 | POST | /api/v1/skills/:slug/rollback | Skills | Rollback active version | SESSION | True |
| API097 | GET | /api/v1/skill-profiles | Skills | Profiles | SESSION | False |
| API098 | POST | /api/v1/skill-profiles/:id/activate | Skills | Activate profile atomically | SESSION | True |
