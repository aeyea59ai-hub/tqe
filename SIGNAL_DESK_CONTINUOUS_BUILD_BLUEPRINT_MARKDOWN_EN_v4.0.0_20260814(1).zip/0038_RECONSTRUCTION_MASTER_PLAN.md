# 34 - Reconstruction Master Plan

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/34_RECONSTRUCTION_MASTER_PLAN.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

| Milestone | Name | Objective |
| --- | --- | --- |
| M0 | Blueprint Lock | Freeze contracts, source packs, security laws, design tokens and traceability. |
| M1 | Foundation | Monorepo, auth, DB, config, logging, local runtime, React shell. |
| M2 | Market Truth | Public provider adapters, universe, candles, snapshots, freshness, indicators, structure. |
| M3 | Scanner + Strategies | Scanner stages, ranking, Evidence Score, S01/S02/S03/S07/S14, decision cards. |
| M4 | Risk + Red Team | Risk v1.0, sizing, leverage, liquidation, locks, correlation, Red Team. |
| M5 | Paper + Journal | Preview/confirm, orders/fills/positions, 50/50 lifecycle, journal chain, portfolio. |
| M6 | Backtest + Replay + Analytics | Backtest, replay, OOS/walk-forward, Analytics V2, calibration. |
| M7 | Skill Control Plane | 166-skill import, registry, drafts, tests, impact, publish/rollback, profiles. |
| M8 | AI Desk | Tool Gateway, Provider Gateway, six agents, context, memory, knowledge, traces. |
| M9 | Target UI | Quiet Grid Terminal screens, responsive/RTL/accessibility/motion. |
| M10 | Operations | Alerts, data/provider health, audit, backup/restore, methodology/limitations. |
| M11 | Integrated QA | Security, anti-hallucination, E2E, accessibility, performance, chaos. |
| M12 | Phone Release | Termux clean install, package validation, 24h soak, final handoff. |

Each milestone is gated. A later milestone cannot hide an earlier P0/P1 blocker. The developer must record exact build/source identity and executed tests for every gate.
