# 49 — AI Provider Registry and Model Routing

> **Source basis:** `blueprints/ai-trading-desk/source-material/49_AI_PROVIDER_REGISTRY_AND_ANY_MODEL_ROUTING.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Owner requirement

The AI Trading Desk must not be locked to one model vendor.

The user can select a provider/model from Settings without changing agent code.

## Supported provider classes

Use provider adapters.

Examples to support when installed/configured:
- OpenAI
- Anthropic
- Google Gemini
- xAI
- Groq
- DeepSeek
- Mistral
- Together
- Fireworks
- Cerebras
- Azure OpenAI / Azure AI Foundry
- AWS Bedrock
- Vertex AI
- NVIDIA
- IBM watsonx
- OpenRouter
- LiteLLM
- Ollama
- LM Studio
- vLLM
- llama.cpp
- generic OpenAI-compatible / Open Responses endpoint when compatibility tests pass

Do not claim literally “any AI in existence.”

The precise contract is:

> Any provider supported by the installed Agno model adapter or by a verified compatible configurable API adapter can be selected without changing trading-domain code.

## ProviderConfig

```text
provider_id
display_name
adapter_type
base_url
model_id
api_key_ref
enabled
supports_tools
supports_structured_output
supports_streaming
supports_reasoning
supports_files
context_window
timeout_seconds
max_output_tokens
temperature
cost_policy
health_state
last_tested_at
```

## Model routing

Each agent can inherit the default provider or use a role-specific override.

Example:

```text
Supervisor      -> best reasoning/tool model
Research        -> search-capable/cost-efficient model
Market Analyst  -> strong structured reasoning model
Strategy        -> strong structured reasoning model
Evidence        -> strict low-temperature validator model
Red Team        -> independent provider/model where desired
```

## User controls

Settings > AI Providers:

- Add provider.
- Enter base URL when relevant.
- Enter model ID.
- Enter API secret.
- Test connection.
- View capabilities.
- Set default model.
- Override per agent.
- Disable provider.
- Choose LOCAL ONLY mode.
- Choose CLOUD ALLOWED mode.
- View last error/latency.
- Never show the raw saved key after submission.

## Failover

Optional failover:

```text
PRIMARY -> FALLBACK_1 -> FALLBACK_2 -> LOCAL
```

Failover must never change trading facts.

Model failure returns:
`MODEL_UNAVAILABLE`

It must not block deterministic Scanner/Risk/Paper functions.

## V3 precedence note

Files 62–69 supersede any wording here that could imply direct vendor binding.

The authoritative design is:

`Agent -> Model Policy Router -> AI Provider Gateway -> Provider Adapter`

and independently:

`Agent -> Tool Gateway -> Deterministic SIGNAL DESK Engines`.
