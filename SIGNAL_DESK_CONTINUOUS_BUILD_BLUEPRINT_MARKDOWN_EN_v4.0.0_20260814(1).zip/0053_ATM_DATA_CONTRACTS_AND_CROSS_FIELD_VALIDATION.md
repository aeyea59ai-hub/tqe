# Strict Data Contracts and Cross-Field Validation Blueprint

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/07_DATA_CONTRACTS_AND_CROSS_FIELD_VALIDATION.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Contract principle

Schema syntax alone is insufficient. Every entity requires:

- field validation;
- enum validation;
- cross-field invariants;
- provenance validation;
- hash validation;
- lifecycle and actionability validation.

## 2. UniverseSnapshot

### Required fields

| Field | Logical type | Rule |
|---|---|---|
| snapshot_instance_id | immutable identifier | unique |
| content_hash | SHA-256 | excludes retrieval time |
| observed_at_utc | UTC timestamp | excluded from content hash |
| provider | enum | public provider only |
| policy_id/version/hash | identifiers | match current policy |
| eligible_symbol_count | integer | equals number of symbols |
| symbols | ordered records | sorted by symbol |
| status | CURRENT/STALE/INVALID | derived, not manually supplied |

### Invariants

- `eligible_symbol_count == len(symbols)`.
- Every symbol is unique.
- Every active symbol has quote=`USDT`, contract=`PERPETUAL`, status=`TRADING`.
- A missing or extra symbol relative to eligible `exchangeInfo` is P0.
- `content_hash` is stable for identical semantic content regardless of `observed_at_utc`.

## 3. MarketSnapshot

### Core fields

- snapshot ID, content hash, and observed time;
- symbol and UniverseSnapshot reference;
- component boundaries for every timeframe;
- closed candle series only;
- mark, funding, and OI metadata with source times;
- quality state and reason codes;
- provider-response hashes;
- freshness result for each data class.

### Invariants

- no future candles;
- no unauthorized duplicates or gaps;
- all timeframe series end on coherent boundaries;
- quality=`VALID` cannot coexist with a stale mandatory component;
- endpoint provenance cannot include TRADE, USER_DATA, or private-account paths;
- NaN and infinity are forbidden.

## 4. StrategyVersion

- strategy_id=`S01`;
- first target version=`2.0.0-experimental`;
- immutable payload hash;
- actionability=`RESEARCH_ONLY`;
- FeatureFlagSet reference;
- source-authority references;
- lifecycle event chain.

Invariant: after the first evaluation, the payload is immutable. Any behavior change requires a new version.

## 5. ATMResearchEvaluation

### Fields

- evaluation_id;
- run_id;
- strategy/version/config hash;
- symbol, snapshot, and content hashes;
- dataset mode;
- side: LONG/SHORT/NONE;
- individual rule results;
- pullback-zone and trigger status;
- hypothetical research geometry;
- risk observation verdict;
- Red Team verdict and objections;
- final research state;
- fixed actionability `RESEARCH_ONLY`;
- timestamps derived from snapshot or replay clock.

### Final states

`DATA_UNAVAILABLE`, `INSUFFICIENT_HISTORY`, `NO_SETUP`, `WAIT_EXPANSION`, `RESEARCH_SETUP`, `RESEARCH_REJECTED`, `EXPIRED`.

### Cross-field invariants

- Invalid or stale data cannot produce `RESEARCH_SETUP`.
- Side NONE requires null geometry.
- LONG requires entry > stop; SHORT requires entry < stop.
- A hard risk veto forces `RESEARCH_REJECTED`.
- Actionability is always `RESEARCH_ONLY`.
- `paper_order_id` must be null.
- AI output cannot change final state.

## 6. DecisionCard compatibility

Do not use the current actionable DecisionCard for ATM v2 until the trailing-only lifecycle is supported. If ATM appears in Decision UI, use a separate Research Card or view model with an explicit badge.

Invariant: `strategy=S01 v2` plus `actionability=RESEARCH_ONLY` forbids `CANDIDATE`, `PUBLISHED`, `WATCHLIST_ACTIONABLE`, and any Paper Order creation.

## 7. DatasetManifest

| Field | Purpose |
|---|---|
| dataset_id/version | immutable identity |
| provider/license | origin and right to use |
| endpoint/product | data type |
| symbols/timeframes | scope |
| start/end | coverage |
| expected/actual rows | completeness |
| gaps/duplicates | quality |
| time semantics | event/open/close timestamps |
| transform spec version | normalization |
| partition hashes/root hash | integrity |
| acquisition time | audit only |
| promotion_eligible | derived from rules |

## 8. BacktestArtifact

- source commit, config, and dataset hashes;
- exact variant;
- sample splits;
- cost and fill models;
- results, trades, and equity;
- warnings and invalidation conditions;
- artifact hash excludes run ID and wall-clock time.

Invariant: every used feature must have dataset coverage for the complete required period.

## 9. Cross-field Validator catalog

| ID | Invariant |
|---|---|
| VAL-001 | stale/invalid data cannot become setup or candidate |
| VAL-002 | Risk VETO forces rejection |
| VAL-003 | Red Team hard veto forces rejection |
| VAL-004 | Research Only cannot create Paper Order |
| VAL-005 | side NONE requires null geometry |
| VAL-006 | LONG/SHORT geometry is directionally valid |
| VAL-007 | stop distance is within ATM bounds |
| VAL-008 | quantized quantity never exceeds risk-safe quantity |
| VAL-009 | below minimum notional rejects instead of resizing upward |
| VAL-010 | strategy/config/dataset hashes match referenced payloads |
| VAL-011 | content hash excludes observation metadata |
| VAL-012 | instance ID includes observation identity |
| VAL-013 | eligible count equals symbol array length |
| VAL-014 | all symbols are unique and policy-eligible |
| VAL-015 | timeframe boundaries are coherent |
| VAL-016 | no future or open candle is used |
| VAL-017 | dataset mode matches enabled features |
| VAL-018 | incomplete derivatives coverage blocks promotion artifact |
| VAL-019 | unknown or missing feature flags fail validation |
| VAL-020 | legacy strategy version remains immutable |
| VAL-021 | owner approval is required for promotion |
| VAL-022 | AI evidence IDs exist in the Fact Bundle |
| VAL-023 | AI numeric claims exist in frozen evidence |
| VAL-024 | no forbidden endpoint provenance |
| VAL-025 | `COMPLETE` claim requires same-tree runtime evidence |
