# 20 - Providers and Integrations

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/20_PROVIDERS_AND_INTEGRATIONS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Market providers
Primary market facts come from public read-only futures data adapters. Secondary metadata providers may enrich display metadata but never replace futures decision fields. Provider calls are timeout-bounded, rate-limit aware and fail closed.

## AI providers
The AI Provider Gateway supports local, cloud and custom compatible providers. The application owns agents, prompts, tools, memory, context, policies, risk and deterministic calculations. Providers own model inference only.

## Separation rule
Tool Gateway and Provider Gateway are independent trust boundaries. An LLM may request a tool; the application validates and executes it. A provider cannot directly call domain internals or gain new permissions from prompt text.
