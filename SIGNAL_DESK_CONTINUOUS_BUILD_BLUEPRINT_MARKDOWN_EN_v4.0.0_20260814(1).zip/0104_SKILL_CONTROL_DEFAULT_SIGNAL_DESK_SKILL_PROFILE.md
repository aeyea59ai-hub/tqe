# Skill Control Default Signal Desk Skill Profile

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/DEFAULT_SIGNAL_DESK_SKILL_PROFILE.json`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

```json
```json
{
  "profile_id": "signal-desk-market-v4",
  "description": "Safe default skill profile for crypto futures intelligence and paper trading.",
  "system_policies": "LOCKED_ALWAYS_ON",
  "core_required": [
    "market-data-provider-adapter",
    "symbol-contract-metadata",
    "ohlcv-normalization",
    "closed-candle-enforcement",
    "market-snapshot-builder",
    "data-freshness-coherence",
    "provider-health-observability",
    "data-lineage-provenance",
    "multi-timeframe-analysis",
    "trend-regime-analysis",
    "ema-analysis",
    "vwap-analysis",
    "rsi-analysis",
    "macd-analysis",
    "atr-volatility-analysis",
    "support-resistance-zones",
    "market-structure-bos-choch",
    "volume-analysis",
    "scanner-ranking-pipeline",
    "crypto-perpetual-futures",
    "funding-rate-analysis",
    "open-interest-analysis",
    "derivatives-crowding-composite",
    "exchange-liquidity-risk",
    "deterministic-feature-engine",
    "deterministic-signal-engine",
    "strategy-validation",
    "backtesting-engine",
    "transaction-cost-modeling",
    "position-sizing",
    "leverage-liquidation-risk",
    "risk-engine",
    "decision-card-integrity",
    "paper-trading-engine"
  ],
  "ai_agents": [
    "Supervisor",
    "Research",
    "Market Analyst",
    "Strategy Analyst",
    "Evidence",
    "Red Team"
  ],
  "ai_skill_policy": "select smallest sufficient set; do not load all skills",
  "general_150_skill_library_policy": "installed_optional_not_auto_routable_to_trading",
  "stocks_fundamentals_options": "disabled_by_default",
  "qa_skills": "background_or_admin_only",
  "paper_write": "human_confirmation_required",
  "live_trading": "forbidden"
}
```

```
