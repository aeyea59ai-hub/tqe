# 60 — Context Engine, Agent Loop, Self-Check, and Task Planning

> **Source basis:** `blueprints/ai-trading-desk/source-material/60_CONTEXT_ENGINE_AGENT_LOOP_SELF_CHECK_AND_TASK_PLANNING.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Goal

The AI Trading Desk must behave like an intelligent operator, not a one-shot chatbot.

The intelligence architecture is:

```text
OBSERVE
  ↓
BUILD CONTEXT
  ↓
UNDERSTAND INTENT
  ↓
PLAN
  ↓
SELECT TOOLS
  ↓
RUN TOOLS
  ↓
VERIFY RESULTS
  ↓
SPECIALIST ANALYSIS
  ↓
EVIDENCE CHECK
  ↓
RED TEAM
  ↓
DETERMINISTIC RISK GATE
  ↓
ANSWER / PAPER PROPOSAL
  ↓
SAVE MEMORY
  ↓
EVALUATE / CALIBRATE
```

## Context Engine

Before each task, construct a bounded task-specific context bundle.

### Required context fields

```text
USER PROFILE
USER PREFERENCES
CURRENT PAGE
SELECTED SYMBOL
SELECTED TIMEFRAME
CURRENT MARKET SNAPSHOT
CURRENT DATA MODE
ACTIVE STRATEGIES
RECENT DECISIONS
OPEN PAPER POSITIONS
PORTFOLIO RISK
RISK LOCKS
RELEVANT JOURNAL HISTORY
RELEVANT LONG-TERM MEMORY
RELEVANT RESEARCH MEMORY
AVAILABLE TOOLS
ACTIVE AI PROVIDER POLICY
CURRENT TASK
```

## Context inference from UI

Example:

If the user is on:

`/workspace/BTCUSDT`

and asks:

> Analyze it.

The Context Engine resolves `it` to `BTCUSDT` from the current page state.

The system should not ask redundant questions when the current application context already resolves the reference safely.

## Context precedence

1. Explicit current user instruction.
2. Current UI selection.
3. Current session state.
4. Relevant long-term preference memory.
5. Historical trading/research memory.

Historical memory must never override fresh market facts.

## Context size control

Do not send the entire user/project history to the model.

Retrieve only:
- relevant memories;
- relevant decisions;
- relevant strategy/risk documentation;
- relevant market snapshot;
- required tool schemas.

Use token and result budgets.

## Planner

The Supervisor creates a structured execution plan before expensive tool/agent calls.

Plan schema:

```text
task_id
intent
resolved_entities
required_facts
required_tools
required_agents
parallelizable_steps
critical_dependencies
stop_conditions
expected_output
paper_action_possible
```

## Self-check gate

Before final response, run:

```text
CHECK_DATA_FRESHNESS
CHECK_MISSING_FIELDS
CHECK_NUMERIC_PROVENANCE
CHECK_STRATEGY_MATCH
CHECK_RISK
CHECK_CONTRADICTIONS
CHECK_AGENT_DISAGREEMENT
CHECK_UNSUPPORTED_CLAIMS
CHECK_DEMO_LIVE_LABEL
CHECK_TOOL_ERRORS
CHECK_SOURCE_RECENCY
```

Possible results:

```text
PASS
MANUAL_REVIEW
ANSWER_BLOCKED
INSUFFICIENT_EVIDENCE
```

## Rule

The Supervisor must not hide failed self-checks.

If a critical check fails, the answer must clearly state the limitation and must not create a paper signal.
