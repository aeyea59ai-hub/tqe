# ATM Change Impact Map

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/26_CHANGE_IMPACT_MAP.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

| current area | expected implementation change | regression scope |
|---|---|---|
| strategy registry | register S01 v2 + research actionability | all strategy list/lifecycle tests |
| S01 evaluator/config | new immutable version with canonical rules | S01 v1 reproduction + S02/S03/S07/S14 |
| feature engine | confirm EMA/ATR/swing definitions | all strategy golden tests |
| snapshot identity | content/instance split | replay, decisions, caching, audit |
| storage models/migrations | research/dataset/verifier records | clean/existing DB upgrade |
| strategy API | experimental status/research endpoints | auth/CSRF/pagination/contracts |
| scanner | shadow lane and coverage | existing rankings unchanged |
| decision service | research card separation | current actionable cards unchanged |
| risk/red team | observation verdict references | policy invariants unchanged |
| backtest/paper lifecycle | trailing-only research model | existing TP1/BE/TP2 unchanged |
| frontend strategies/backtest/data health | ATM research views | navigation/RTL/a11y/regressions |
| verifier/CI | semantic/mutation gates | existing verifier hardening |
| docs/evidence | traceability/status/source register | claim ledger consistency |

## Change rule

Any modification not listed in this map requires a documented Change Request before implementation, especially when it affects live/public providers or Paper Order paths.
