# Skill Manager API contract

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/07_SKILL_MANAGER_API_CONTRACT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

Conceptual endpoints:

```text
GET  /api/skills
GET  /api/skills/{slug}
GET  /api/skills/{slug}/versions
GET  /api/skills/{slug}/impact

POST /api/skills/{slug}/draft
PATCH /api/skill-drafts/{draft_id}
DELETE /api/skill-drafts/{draft_id}

POST /api/skill-drafts/{draft_id}/validate
POST /api/skill-drafts/{draft_id}/test
POST /api/skill-drafts/{draft_id}/impact
POST /api/skill-drafts/{draft_id}/publish

POST /api/skills/{slug}/enable
POST /api/skills/{slug}/disable
POST /api/skills/{slug}/rollback

GET  /api/skill-profiles
POST /api/skill-profiles
POST /api/skill-profiles/{id}/activate

GET  /api/system-policies
```

System-policy mutation uses a separate owner-only API with explicit confirmation and full release gates.

## Optimistic concurrency

Draft/publish requests include:
- base version;
- expected active version;
- content hash.

Reject stale edits with `SKILL_VERSION_CONFLICT`.
