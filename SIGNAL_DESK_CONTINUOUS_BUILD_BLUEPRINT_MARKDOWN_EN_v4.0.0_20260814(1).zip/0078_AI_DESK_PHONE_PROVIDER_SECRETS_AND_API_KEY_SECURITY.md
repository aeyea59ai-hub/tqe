# 53 — Phone Provider Secrets and API-Key Security

> **Source basis:** `blueprints/ai-trading-desk/source-material/53_PHONE_PROVIDER_SECRETS_AND_API_KEY_SECURITY.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Requirement

The user must be able to connect AI providers without editing source code.

## Secret boundary

API keys belong to the backend only.

Never store provider keys in:
- React source;
- browser localStorage;
- sessionStorage;
- IndexedDB;
- chat history;
- journal;
- logs;
- screenshots;
- git;
- release ZIP.

## Provider setup flow

UI:
Settings → AI Providers → Add Provider

User enters:
- provider;
- base URL if relevant;
- model;
- API key;
- optional limits.

Frontend sends the secret once over loopback HTTPS/HTTP local channel to the backend.

Backend:
- validates provider format;
- tests credential with a minimal request when owner requests test;
- stores secret reference;
- returns only a masked identifier.

## Phone storage

Minimum safe local profile:

```text
~/.signaldesk/secrets/providers.env
chmod 600
```

The release must also support:
- environment-variable-only mode;
- session-only provider key mode with no persistence.

If an Android/Termux secure-keystore adapter is implemented and verified later, it may replace file persistence.

Do not falsely claim Android Keystore protection unless actually implemented.

## Secret redaction

All logs/errors/traces use centralized redaction for:
- API keys;
- bearer tokens;
- cookies;
- authorization headers;
- provider request headers;
- query parameters containing secrets.

## Agent restriction

Agents cannot call:
- list_raw_secrets
- get_provider_key
- change_provider_key

Only Settings/Admin control plane can manage them.

## Backup

Secrets excluded from normal backup/export by default.

Restoring a backup requires the user to re-enter provider secrets.

## V3 custom-provider security

Custom Base URL support must include SSRF controls, scheme/host/redirect validation, and explicit loopback exceptions for local AI.

Raw provider secrets never enter:
- Context Engine;
- long-term memory;
- agent tools;
- calibration records;
- model prompts.
