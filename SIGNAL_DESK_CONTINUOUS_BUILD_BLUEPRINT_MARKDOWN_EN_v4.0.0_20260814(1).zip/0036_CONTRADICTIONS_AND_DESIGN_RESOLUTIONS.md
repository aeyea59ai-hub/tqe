# 32 - Design Resolutions

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/32_CONTRADICTIONS_AND_DESIGN_RESOLUTIONS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Resolution 1 - functional scope vs visual redesign
Functional/safety contracts are preserved. Historical/current visual layout is not authoritative because the owner explicitly requested a new simpler shape and motion system.

## Resolution 2 - AI vs deterministic authority
AI explains, researches, compares, critiques and orchestrates. Deterministic services own all decision-critical numbers and gates.

## Resolution 3 - many pages vs simple navigation
All capabilities remain, but the top-level navigation is reduced to Home, Market, Scan, Decisions, Strategies, Paper, Journal, AI and System. Secondary functionality becomes tabs/subroutes/inspectors.

## Resolution 4 - many market skills vs context size
Import the skill library but route only the smallest sufficient set. Source packs remain immutable.

## Resolution 5 - provider flexibility vs privacy
Providers are replaceable, but routing is constrained by privacy/capabilities/health. LOCAL_ONLY cannot cloud-fallback.
