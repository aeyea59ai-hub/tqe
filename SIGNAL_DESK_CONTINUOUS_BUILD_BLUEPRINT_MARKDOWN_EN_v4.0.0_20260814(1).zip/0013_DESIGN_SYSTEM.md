# 09 - Design System

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/09_DESIGN_SYSTEM.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Tokens
```json
{
  "design_name": "Quiet Grid Terminal",
  "principles": [
    "open layouts",
    "few containers",
    "hairline separators",
    "dense where useful",
    "quiet motion",
    "clear data hierarchy",
    "no ornamental card grid"
  ],
  "colors": {
    "canvas": "#090D10",
    "surface": "#0D1418",
    "surfaceRaised": "#121C21",
    "surfaceHover": "#162229",
    "border": "#223038",
    "text": "#E8F0F2",
    "textMuted": "#8A9A9F",
    "textDim": "#5F7076",
    "accent": "#7DE2C4",
    "focus": "#8AB4F8",
    "long": "#2ED09A",
    "short": "#FF6B73",
    "warning": "#F7C967",
    "danger": "#FF5A67",
    "info": "#78A9FF",
    "locked": "#B29BFF",
    "overlay": "rgba(3,7,9,0.78)"
  },
  "typography": {
    "ui": "Inter, system-ui, sans-serif",
    "numeric": "IBM Plex Mono, ui-monospace, monospace",
    "sizes_px": {
      "xs": 11,
      "sm": 12,
      "md": 13,
      "body": 14,
      "lg": 16,
      "xl": 20,
      "xxl": 28,
      "hero": 36
    },
    "weights": {
      "regular": 400,
      "medium": 500,
      "semibold": 600,
      "bold": 700
    },
    "line_heights": {
      "tight": 1.15,
      "normal": 1.4,
      "relaxed": 1.6
    }
  },
  "spacing_px": [
    4,
    8,
    12,
    16,
    20,
    24,
    32,
    40,
    48,
    64
  ],
  "radii_px": {
    "control": 4,
    "panel": 6,
    "dialog": 8,
    "pill": 999
  },
  "borders": {
    "default": "1px solid #223038",
    "strong": "1px solid #33464F"
  },
  "elevation": {
    "none": "none",
    "float": "0 12px 40px rgba(0,0,0,.28)"
  },
  "layout": {
    "rail_width": 56,
    "context_bar_height": 48,
    "inspector_width": 336,
    "content_max_width": 1920,
    "grid_gap": 12
  },
  "breakpoints_px": {
    "mobile": 0,
    "tablet": 768,
    "desktop": 1180,
    "wide": 1600
  }
}
```

## Component philosophy
Use open bands, rows, tables, canvases and one inspector. Cards are reserved for confirmations or compact summaries that cannot be expressed as rows.

## Semantic states
LONG=#2ED09A, SHORT=#FF6B73, warning=#F7C967, info=#78A9FF, locked=#B29BFF. Every status includes text.

## Focus
All interactive elements receive a 2px focus ring using #8AB4F8 with 2px offset.

## Numeric typography
Prices, quantities, percentages, R values and timestamps use the numeric font with tabular figures.
