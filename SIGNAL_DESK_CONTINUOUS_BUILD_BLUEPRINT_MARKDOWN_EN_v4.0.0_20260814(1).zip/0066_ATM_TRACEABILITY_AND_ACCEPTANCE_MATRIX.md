# Traceability and Acceptance Matrix

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/20_TRACEABILITY_AND_ACCEPTANCE_MATRIX.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

| Req ID | requirement | design source | test IDs | release gate |
|---|---|---|---|---|
| REQ-001 | ATM is inside Signal Desk, not a replacement | 01,04 | T-FLG-003,T-UI-001 | G1/G4 |
| REQ-002 | S01 version immutable | 03,06,11 | T-DB-003,T-FLG-004 | G2/G3 |
| REQ-003 | Research Only default | 06,12 | T-FLG-001..006 | G2/G3 |
| REQ-004 | exact ATM rules | 05 | T-ATM-001..020 | G2 |
| REQ-005 | strict cross-field validators | 07 | T-SCH-001..010 | G2/G3 |
| REQ-006 | deterministic content hash | 08 | T-HASH-001..008 | G2/G5 |
| REQ-007 | honest derivatives coverage | 09 | T-DAT-001..008 | G2/G5 |
| REQ-008 | no ATM paper order | 10,13 | T-API-004,T-FLG-003 | G3/G6 |
| REQ-009 | DB append-only history | 11 | T-DB-004,T-DB-005 | G3 |
| REQ-010 | state transitions guarded | 12 | state transition tests | G2/G3 |
| REQ-011 | risk/red-team authoritative | 13 | T-SCH-003 + risk tests | G2/G3 |
| REQ-012 | causal backtest/replay | 14 | T-EXE-005..012 | G5 |
| REQ-013 | UI experimental labeling | 15 | T-UI-001..006 | G4 |
| REQ-014 | no private/live surface | 16 | T-SEC-001..007 | G6 |
| REQ-015 | executable tests eventually | 17 | all T-* | G2–G9 |
| REQ-016 | semantic mutations | 18 | MUT-001..020 | G7 |
| REQ-017 | same-tree release evidence | 19 | T-REL-002 | G0/G10 |
| REQ-018 | no false COMPLETE | 19,23 | T-REL-001..005 | G10 |

## Acceptance rule

Every requirement must have:

- implementation evidence.
- at least one positive test.
- at least one negative or boundary test where applicable.
- source/config/dataset identity.
- owner-visible status.
