# 38 - AI Provider Gateway

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/38_AI_PROVIDER_GATEWAY.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

```json
{
  "provider_independence": true,
  "providers": [
    "OLLAMA_LOCAL",
    "KIMI",
    "OLLAMA_CLOUD",
    "OPENAI_OPTIONAL",
    "CUSTOM_COMPATIBLE"
  ],
  "routing_modes": [
    "AUTO",
    "LOCAL_ONLY",
    "CLOUD_ONLY",
    "PRIVACY_FIRST",
    "QUALITY_FIRST",
    "COST_FIRST",
    "SPEED_FIRST",
    "MANUAL",
    "STRICT_STRUCTURED"
  ],
  "privacy_classes": [
    "PUBLIC",
    "INTERNAL",
    "PRIVATE_LOCAL_ONLY",
    "SECRET_NEVER_SEND_TO_MODEL"
  ],
  "capabilities": [
    "TEXT",
    "VISION",
    "TOOLS",
    "STREAMING",
    "STRUCTURED_OUTPUT",
    "REASONING",
    "FILES",
    "EMBEDDINGS_OPTIONAL"
  ],
  "rules": [
    "Agents never call a provider adapter directly.",
    "Tool Gateway is separate from Provider Gateway.",
    "LOCAL_ONLY never falls back to cloud.",
    "Model IDs are discovered/tested, not embedded in business logic.",
    "Provider removal cannot delete agent prompts, memory, tools, journal, risk, or decision history.",
    "Raw provider payloads are not persisted by default."
  ],
  "custom_provider_security": [
    "allow only approved protocol families",
    "validate scheme/host/IP/DNS/redirect/TLS/port",
    "allow explicit loopback for local AI",
    "block cloud metadata and arbitrary LAN scanning",
    "response-size and timeout bounds",
    "redact secrets and sensitive prompts"
  ]
}
```

## Provider lifecycle
ADDED -> UNTESTED -> HEALTHY/DEGRADED -> DISABLED -> REMOVED. Remove shows dependency report and requires replacement selection if the provider is referenced by an active routing policy.

## Audit fields
request_id, agent_id, provider_id, model_id, routing_policy, task_type, privacy_class, start/end, latency, success/failure, fallback_used, tool call identifiers, token counts when available, error category. Raw secrets are never logged.
