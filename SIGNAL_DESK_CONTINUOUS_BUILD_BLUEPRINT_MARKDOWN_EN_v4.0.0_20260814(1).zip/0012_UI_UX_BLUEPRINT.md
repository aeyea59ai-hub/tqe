# 08 - UI/UX Blueprint

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/08_UI_UX_BLUEPRINT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

The target visual system is intentionally different from the earlier dense panel/card approach. The new direction, **Quiet Grid Terminal**, uses an open dark canvas, one thin navigation rail, one context bar, table-first information, a single contextual inspector and restrained semantic color. Major pages avoid nested cards. Detail appears in drawers/sheets instead of permanent columns. Motion is short and functional: 110-220 ms, no bounce, no glow loops, no decorative parallax. The primary interaction is symbol/context continuity plus a command palette.

## Shell
- 56px left rail on desktop.
- 48px context bar across the top.
- Main workspace is an open canvas; panels appear only where information needs framing.
- One 336px inspector drawer is reused across scanner rows, decisions, strategies, providers and skills.
- Command palette is the fastest way to switch symbol, page or read-only command.
- Mobile replaces the rail with five-item bottom navigation and uses bottom sheets for inspectors.

## Density
Tables, market facts and logs are compact. Forms, confirmations and explanatory text use wider spacing. No bento layout. No nested card stacks.

## Information hierarchy
1. Context and safety state.
2. Primary task or data.
3. Decision/risk state.
4. Supporting evidence.
5. Deep diagnostics in inspector/drawer.

## Status display
Status uses a small dot + precise text, never color alone. LONG and SHORT colors are reserved for directional information; warnings and locks use separate semantics.

## Responsive rules
- >=1180px: rail + canvas + optional inspector.
- 768-1179px: rail collapses to icons; inspector overlays.
- <768px: bottom nav; context bar condensed; tables become row lists; chart remains full-width.
