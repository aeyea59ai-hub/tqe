# Owner controls without accidental breakage

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/10_OWNER_SAFE_CONTROL_RULES.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Owner can

- enable/disable normal skills;
- assign skills to agents;
- choose AUTO/CONDITIONAL/MANUAL;
- create drafts;
- edit instructions;
- choose model policy;
- adjust routing tags;
- test;
- publish;
- rollback;
- duplicate/fork;
- export/import;
- activate profiles.

## Normal editor cannot

- edit an active published version in place;
- disable protected core policy;
- grant a forbidden Tool Gateway permission;
- enable live trading;
- expose secret APIs to agents;
- rewrite historical skill versions.

## Advanced policy changes

For locked system policies:
1. owner enters Advanced System Policy area;
2. creates policy draft;
3. system warns about affected invariants;
4. full project QA is mandatory;
5. explicit owner publish;
6. previous policy stays rollback-capable.

This gives the owner control while making accidental damage difficult.
