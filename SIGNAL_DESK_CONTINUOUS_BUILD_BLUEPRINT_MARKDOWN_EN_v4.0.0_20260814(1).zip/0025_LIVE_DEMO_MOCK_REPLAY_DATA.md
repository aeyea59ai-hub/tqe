# 21 - LIVE / DEMO / MOCK / REPLAY Data

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/21_LIVE_DEMO_MOCK_REPLAY_DATA.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

- `LIVE_PUBLIC`: public read-only market data. No private keys.
- `DEMO`: deterministic local fixtures, fully offline.
- `REPLAY`: historical deterministic clock.
- `TEST`: isolated test database and fixtures.
- `SOAK`: long-running reliability profile with no external writes.

The active profile is visible globally. DEMO/REPLAY data is never labeled LIVE. Cached stale data may remain visible for inspection but cannot create a fresh publishable decision.
