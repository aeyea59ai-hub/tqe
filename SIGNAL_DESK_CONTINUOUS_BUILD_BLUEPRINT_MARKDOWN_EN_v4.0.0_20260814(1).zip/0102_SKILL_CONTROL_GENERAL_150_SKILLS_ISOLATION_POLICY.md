# General 150-Skill Library isolation

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/09_GENERAL_150_SKILLS_ISOLATION_POLICY.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

The general-purpose skills library remains useful, but it is not automatically routable into trading workflows.

## Default

`INSTALLED_OPTIONAL / DISABLED_FOR_MARKET_AUTO_ROUTING`

Examples:
- coding;
- documents;
- marketing;
- ecommerce;
- personal productivity;
- legal;
- device/media.

## Developer/Admin profile

Coding/security/QA skills may be enabled in a separate Developer profile.

They must not enter market-decision context unless explicitly requested and relevant.

## Reason

This prevents:
- context bloat;
- instruction conflicts;
- accidental prompt chaining;
- trading analysis contaminated by unrelated roles.
