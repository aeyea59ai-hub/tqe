# Historical Derivatives Data Plan

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/09_HISTORICAL_DERIVATIVES_DATA_PLAN.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Problem

A multi-year ATM backtest cannot assume complete historical coverage for every derivatives feature from Binance public APIs. The current source study identified the following limitations that must be reverified against official documentation during implementation:

- Open Interest Statistics have a limited recent-history window.
- Taker Buy/Sell Volume and Top Trader ratios have limited recent-history windows.
- Some Top Trader Account/Position Ratio access may require an API-key header.
- Funding Info exposes `fundingIntervalHours`; historical changes must be versioned rather than applying the current value to the past.

Do not combine multi-year price history with recent derivatives data and label the result a Full ATM Backtest.

## 2. Backtest variants

### A. ATM_PRICE_CORE

- Data: closed klines, instrument filters, and funding history when historically available.
- OI, taker, and top-trader gates: OFF.
- Valid for Trend, Momentum, Volatility, Entry, and Exit core testing.
- Does not prove the derivatives layer.

### B. ATM_DERIVATIVES_RECENT

- Uses only the genuine overlap window available for every enabled feature.
- Automatically trims the period to the coverage intersection.
- Label: `RECENT_WINDOW_ONLY`.
- Cannot independently justify long-term promotion.

### C. ATM_DERIVATIVES_LICENSED

- Requires a Dataset Manifest from a licensed or paid provider.
- Must prove provenance, license, completeness, and transforms.
- Disabled until an owner decision approves it.

### D. ATM_PROSPECTIVE_COLLECTION

- Collector begins at a documented future activation date.
- Stores periodic OI, taker, ratio, and funding-interval snapshots.
- Uses immutable partitions and daily root hashes.
- Never fabricates historical data.

## 3. Promotion data gate

Derivatives features become promotion-eligible only when either:

1. a licensed historical dataset continuously covers train, OOS, and walk-forward periods; or
2. a prospective dataset covers at least 12 months with >=95% completeness for every mandatory feature.

Until then:

- OI and ratios are evidence-only;
- no hard derivatives gate in ATM v2;
- every report displays the dataset mode explicitly.

## 4. Funding interval ledger

For every symbol store:

- effective_from and effective_to;
- funding interval hours;
- source-response hash;
- observed_at;
- conflict-resolution record.

Backtest uses the interval effective at the historical timestamp. If it cannot be proven, mark funding cost `INTERVAL_UNVERIFIED` and make the artifact promotion-ineligible.

## 5. Dataset quality rules

- No silent forward-fill of OI or ratios.
- Gaps remain gaps.
- Every resampling operation declares its aggregation semantics.
- All timestamps use UTC.
- Revised data creates a new dataset version.
- Preserve symbol rename and delisting lifecycle.
- Historical universe snapshots are required to avoid survivorship bias; otherwise the report must declare the limitation.

## 6. Default owner decision

Do not request a private API key in the first version. Keep top-trader features OFF. The safe default is Price Core plus a prospective collector, followed by a later decision on purchasing a licensed dataset.
