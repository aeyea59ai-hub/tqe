# 46 — AI Trading Desk: Agno AgentOS + AG-UI Architecture

> **Source basis:** `blueprints/ai-trading-desk/source-material/46_AI_TRADING_DESK_AGNO_AGENTOS_AGUI_ARCHITECTURE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Owner requirement

AI Trading Desk is **not a second trading platform** and is not a replacement for SIGNAL DESK.

It is a new first-class workspace inside the same product:

```text
SIGNAL DESK
├── Dashboard
├── Scanner
├── Charts
├── Strategies
├── Backtesting
├── Risk
├── Paper Trading
├── Journal
└── AI TRADING DESK
    ├── Chat
    ├── Agent Team
    ├── Research
    ├── Memory
    ├── Tools
    ├── Providers
    ├── Traces
    └── Settings
```

## Architecture

```text
React SIGNAL DESK UI
        │
        ├── Existing pages and engines
        │
        └── /ai-desk
              │
            AG-UI
              │
        AgentOS Runtime
              │
    ┌─────────┴─────────┐
    │                   │
Supervisor          Research
    │                   │
    ├── Market Analyst
    ├── Strategy Analyst
    ├── Evidence Agent
    └── Red-Team Agent
              │
              ▼
      TOOL PERMISSION GATE
              │
              ▼
      EXISTING DETERMINISTIC ENGINES
```

## Critical separation

The AI layer may:
- reason;
- search;
- compare;
- summarize;
- orchestrate;
- call approved tools;
- inspect previous evidence;
- request backtests;
- prepare a paper-trade proposal.

The AI layer must NOT independently own:
- market prices;
- candles;
- funding;
- open interest;
- indicators;
- strategy math;
- backtest accounting;
- risk math;
- position sizing;
- liquidation math;
- fees;
- funding costs;
- slippage;
- portfolio limits;
- paper fills;
- journal accounting.

Those remain deterministic application services.

## AgentOS integration

AgentOS should be treated as an agent runtime/control layer, not the trading backend.

Preferred integration:

```text
Existing FastAPI Application
├── /api/...              existing deterministic APIs
├── /ws/...               existing realtime APIs
└── /agent/...            AgentOS / AG-UI mounted or locally proxied
```

Implementation options, in order:

1. Mount AgentOS as a local ASGI sub-application/router when verified compatible with the existing FastAPI lifecycle.
2. Otherwise run AgentOS as a local-only sidecar on `127.0.0.1:7777` and proxy `/agent/*` through the primary FastAPI application.
3. Never expose AgentOS directly to a public interface by default.

## AG-UI responsibilities

AG-UI is used for:
- streaming chat;
- tool-call progress;
- agent status;
- structured events;
- state synchronization;
- evidence cards;
- human-in-the-loop confirmation.

The React application remains the visual owner. Do not replace the full app with an AgentOS control-plane UI.

## Network binding

Phone/local defaults:

- SIGNAL DESK UI/API: `127.0.0.1`
- AgentOS: `127.0.0.1`
- no `0.0.0.0` unless explicitly enabled by the owner;
- no public tunnel by default.

## External AI

Cloud model calls are optional outbound requests from the local backend.

No provider is mandatory.

## V3 intelligence stack

The AI Trading Desk now explicitly includes:

```text
AgentOS / AG-UI
├── Supervisor
├── Context Engine
├── Agent Loop / Planner
├── Memory Engine
├── Knowledge / RAG
├── Tool Gateway
├── Model Policy Router
├── AI Provider Gateway
├── Self-Check
├── Evaluation
├── Calibration
└── Feedback
```

Tool Gateway and AI Provider Gateway are separate trust boundaries.
