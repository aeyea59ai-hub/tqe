# 25 - Runtime Architecture

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/25_RUNTIME_ARCHITECTURE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Services
- Primary FastAPI application: `127.0.0.1:8000`.
- Agent runtime/AG-UI sidecar: `127.0.0.1:7777`.
- SQLite data files in app-private storage.
- React production assets served by the primary backend.
- Scheduler owned by one process/lock.

## Isolation
If AI or every model provider fails, Market, Scanner, Strategies, Risk, Paper, Journal, Backtest and Analytics continue. AI surfaces show unavailable state only.

## Boot
Config -> DB migration/integrity -> domain registries -> provider health -> scheduler lock -> API/WS -> static frontend -> ready.

## Shutdown
Stop new jobs -> persist job state -> close WebSockets -> flush audit/logs -> close DB -> exit.
