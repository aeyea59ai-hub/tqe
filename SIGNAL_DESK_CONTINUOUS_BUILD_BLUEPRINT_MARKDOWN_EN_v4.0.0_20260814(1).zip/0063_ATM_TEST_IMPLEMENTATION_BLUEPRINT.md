# Executable Test Implementation Blueprint

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/17_TEST_IMPLEMENTATION_BLUEPRINT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Truthful status

The table below is the executable-test implementation catalog. Convert every row into the appropriate pytest, Vitest, Playwright, property, contract, security, performance, or integration test; run the resulting suite and preserve fresh evidence.

## 2. Framework mapping

| Type | Future implementation |
|---|---|
| Pure domain/rules/hash | pytest + property-based tests |
| Schema/cross-field | Pydantic/JSON Schema tests + negative fixtures |
| API/DB/migrations | FastAPI TestClient + temporary DB + Alembic roundtrip |
| Frontend/UI | Vitest + Testing Library |
| Browser/accessibility | Playwright + axe |
| Security | static scan + negative integration |
| Backtest/replay | deterministic golden fixtures/metamorphic tests |
| Release | clean extract + same-tree verifier |

## 3. Test specification catalog

| ID | category | fixture/action | required oracle | evidence |
|---|---|---|---|---|
| T-SCH-001 | SCHEMA | MarketSnapshot stale + VALID | reject through cross-field validation | automated executable test + saved evidence |
| T-SCH-002 | SCHEMA | DATA_UNAVAILABLE + RESEARCH_SETUP | reject | automated executable test + saved evidence |
| T-SCH-003 | SCHEMA | Risk VETO + setup | RESEARCH_REJECTED | automated executable test + saved evidence |
| T-SCH-004 | SCHEMA | Research Only + paper_order_id | reject | automated executable test + saved evidence |
| T-SCH-005 | SCHEMA | LONG entry <= stop | reject | automated executable test + saved evidence |
| T-SCH-006 | SCHEMA | SHORT entry >= stop | reject | automated executable test + saved evidence |
| T-SCH-007 | SCHEMA | eligible_count mismatch | reject | automated executable test + saved evidence |
| T-SCH-008 | SCHEMA | duplicate symbols | reject | automated executable test + saved evidence |
| T-SCH-009 | SCHEMA | unknown feature flag | reject | automated executable test + saved evidence |
| T-SCH-010 | SCHEMA | missing canonicalization version | reject | automated executable test + saved evidence |
| T-HASH-001 | HASH | same content/different observed_at | same content hash | automated executable test + saved evidence |
| T-HASH-002 | HASH | same content/different key order | same hash | automated executable test + saved evidence |
| T-HASH-003 | HASH | symbol set reordered | same normalized hash | automated executable test + saved evidence |
| T-HASH-004 | HASH | candle order changed | fail/different hash | automated executable test + saved evidence |
| T-HASH-005 | HASH | price changed by one tick | different hash | automated executable test + saved evidence |
| T-HASH-006 | HASH | decimal 1.0 vs 1.000 | same normalized hash | automated executable test + saved evidence |
| T-HASH-007 | HASH | instance time changed | different instance ID | automated executable test + saved evidence |
| T-HASH-008 | HASH | hash reference mismatch | hard fail | automated executable test + saved evidence |
| T-ATM-001 | RULE | momentum +0.9999 | no long | automated executable test + saved evidence |
| T-ATM-002 | RULE | momentum +1.0 | long threshold pass | automated executable test + saved evidence |
| T-ATM-003 | RULE | momentum -1.4999 | no short | automated executable test + saved evidence |
| T-ATM-004 | RULE | momentum -1.5 | short threshold pass | automated executable test + saved evidence |
| T-ATM-005 | RULE | daily close == EMA200 | regime fail | automated executable test + saved evidence |
| T-ATM-006 | RULE | long slope == 0 | long fail | automated executable test + saved evidence |
| T-ATM-007 | RULE | short EMA200 slope == 0 | short slope pass | automated executable test + saved evidence |
| T-ATM-008 | RULE | CHoCH wick only | short fail | automated executable test + saved evidence |
| T-ATM-009 | RULE | CHoCH close break after confirmation | pass | automated executable test + saved evidence |
| T-ATM-010 | RULE | ATR percentile 14.999 | WAIT_EXPANSION | automated executable test + saved evidence |
| T-ATM-011 | RULE | ATR percentile 15 | pass | automated executable test + saved evidence |
| T-ATM-012 | RULE | ATR percentile 89.999 | pass | automated executable test + saved evidence |
| T-ATM-013 | RULE | ATR percentile 90 | reject | automated executable test + saved evidence |
| T-ATM-014 | RULE | no-chase 2.0 ATR | pass | automated executable test + saved evidence |
| T-ATM-015 | RULE | no-chase >2.0 ATR | fail | automated executable test + saved evidence |
| T-ATM-016 | RULE | stop 1.199 ATR | widen to 1.2 | automated executable test + saved evidence |
| T-ATM-017 | RULE | stop 3.5 ATR | pass boundary | automated executable test + saved evidence |
| T-ATM-018 | RULE | stop >3.5 ATR | reject | automated executable test + saved evidence |
| T-ATM-019 | RULE | setup expiry at 12 bars | expire exactly | automated executable test + saved evidence |
| T-ATM-020 | RULE | insufficient 1D history | INSUFFICIENT_HISTORY | automated executable test + saved evidence |
| T-FND-001 | FUNDING | funding coverage <75% | unavailable | automated executable test + saved evidence |
| T-FND-002 | FUNDING | funding std 0 | unavailable | automated executable test + saved evidence |
| T-FND-003 | FUNDING | long z=2.0 | no scale | automated executable test + saved evidence |
| T-FND-004 | FUNDING | long z>2 and <=3 | 0.5 research scale | automated executable test + saved evidence |
| T-FND-005 | FUNDING | long z>3 | reject | automated executable test + saved evidence |
| T-FND-006 | FUNDING | short z<-1.5 | reject | automated executable test + saved evidence |
| T-FND-007 | FUNDING | cost exactly 0.25R | pass; reject applies only when cost >0.25R | automated executable test + saved evidence |
| T-FND-008 | FUNDING | cost >0.25R | reject | automated executable test + saved evidence |
| T-FND-009 | FUNDING | historical interval missing | promotion ineligible | automated executable test + saved evidence |
| T-EXE-001 | ENTRYEXIT | no complete impulse | NO_CONFIRMED_IMPULSE | automated executable test + saved evidence |
| T-EXE-002 | ENTRYEXIT | EMA20 outside fib zone | no setup | automated executable test + saved evidence |
| T-EXE-003 | ENTRYEXIT | 15m wick break only | no trigger | automated executable test + saved evidence |
| T-EXE-004 | ENTRYEXIT | 15m close directional break | trigger | automated executable test + saved evidence |
| T-EXE-005 | ENTRYEXIT | fill before trigger known | forbidden/lookahead fail | automated executable test + saved evidence |
| T-EXE-006 | ENTRYEXIT | fill next 15m open | expected | automated executable test + saved evidence |
| T-EXE-007 | ENTRYEXIT | same bar stop and favorable exit | stop first | automated executable test + saved evidence |
| T-EXE-008 | ENTRYEXIT | Chandelier attempts to loosen | retain prior stop | automated executable test + saved evidence |
| T-EXE-009 | ENTRYEXIT | long 168h no 1R | time exit | automated executable test + saved evidence |
| T-EXE-010 | ENTRYEXIT | short 72h no 1R | time exit | automated executable test + saved evidence |
| T-EXE-011 | ENTRYEXIT | funding paid >0.3R | next-open exit | automated executable test + saved evidence |
| T-EXE-012 | ENTRYEXIT | partial flag off | no partial fill | automated executable test + saved evidence |
| T-FLG-001 | FLAGS | ATM evaluation disabled | typed ATM_DISABLED | automated executable test + saved evidence |
| T-FLG-002 | FLAGS | shadow on/actionable off | research records only | automated executable test + saved evidence |
| T-FLG-003 | FLAGS | paper order from ATM research | blocked | automated executable test + saved evidence |
| T-FLG-004 | FLAGS | flag mutation during active run | blocked/new version | automated executable test + saved evidence |
| T-FLG-005 | FLAGS | missing flag | fail closed | automated executable test + saved evidence |
| T-FLG-006 | FLAGS | owner approval absent | no promotion | automated executable test + saved evidence |
| T-DAT-001 | DATASET | price-core with OI gate requested | reject mode mismatch | automated executable test + saved evidence |
| T-DAT-002 | DATASET | derivatives gap hidden by fill | detect/fail | automated executable test + saved evidence |
| T-DAT-003 | DATASET | 30-day recent dataset claimed multi-year | reject claim | automated executable test + saved evidence |
| T-DAT-004 | DATASET | partition hash mismatch | dataset invalid | automated executable test + saved evidence |
| T-DAT-005 | DATASET | coverage <95% for promotion | ineligible | automated executable test + saved evidence |
| T-DAT-006 | DATASET | provider license missing | ineligible | automated executable test + saved evidence |
| T-DAT-007 | DATASET | universe survivorship warning absent | artifact invalid | automated executable test + saved evidence |
| T-DAT-008 | DATASET | funding interval current applied historically | detect | automated executable test + saved evidence |
| T-API-001 | API | research endpoint unauthenticated | 401/blocked | automated executable test + saved evidence |
| T-API-002 | API | research write without CSRF | blocked | automated executable test + saved evidence |
| T-API-003 | API | unknown fields | 422 | automated executable test + saved evidence |
| T-API-004 | API | ATM paper endpoint attempt | 404/409 typed | automated executable test + saved evidence |
| T-API-005 | API | version mutation after use | 409 immutable | automated executable test + saved evidence |
| T-API-006 | API | content hash mismatch | 409/422 hard fail | automated executable test + saved evidence |
| T-API-007 | API | pagination overflow | bounded reject | automated executable test + saved evidence |
| T-API-008 | API | stack trace in response | forbidden | automated executable test + saved evidence |
| T-DB-001 | DB | clean upgrade through new revision | pass | automated executable test + saved evidence |
| T-DB-002 | DB | upgrade existing 0003 DB | pass | automated executable test + saved evidence |
| T-DB-003 | DB | duplicate strategy version | constraint fail | automated executable test + saved evidence |
| T-DB-004 | DB | delete audit/evaluation | blocked | automated executable test + saved evidence |
| T-DB-005 | DB | orphan evaluation | FK fail | automated executable test + saved evidence |
| T-DB-006 | DB | migration imports current ORM metadata | static fail | automated executable test + saved evidence |
| T-UI-001 | UI | ATM row | Experimental + Research Only visible | automated executable test + saved evidence |
| T-UI-002 | UI | ATM detail | no Paper/Publish button | automated executable test + saved evidence |
| T-UI-003 | UI | NOT_RUN state | not rendered as PASS | automated executable test + saved evidence |
| T-UI-004 | UI | RTL numbers/symbols | LTR isolates correct | automated executable test + saved evidence |
| T-UI-005 | UI | keyboard dialog | focus trap/Escape/restore | automated executable test + saved evidence |
| T-UI-006 | UI | data coverage below 100% | degraded warning | automated executable test + saved evidence |
| T-SEC-001 | SECURITY | add /order route | forbidden scan fails | automated executable test + saved evidence |
| T-SEC-002 | SECURITY | add API secret field | secret/schema scan fails | automated executable test + saved evidence |
| T-SEC-003 | SECURITY | signed request helper | forbidden scan fails | automated executable test + saved evidence |
| T-SEC-004 | SECURITY | client supplies mark price | validation rejects | automated executable test + saved evidence |
| T-SEC-005 | SECURITY | AI unsupported number | validator rejects | automated executable test + saved evidence |
| T-SEC-006 | SECURITY | archive traversal | package reject | automated executable test + saved evidence |
| T-SEC-007 | SECURITY | SSRF provider URL | allowlist reject | automated executable test + saved evidence |
| T-REL-001 | RELEASE | ZIP valid but app absent | cannot claim complete | automated executable test + saved evidence |
| T-REL-002 | RELEASE | tests from different commit | gate fail | automated executable test + saved evidence |
| T-REL-003 | RELEASE | P0 mutation survives | semantic fail | automated executable test + saved evidence |
| T-REL-004 | RELEASE | 24h soak not run | release limitation/block per policy | automated executable test + saved evidence |
| T-REL-005 | RELEASE | owner approval absent | not release | automated executable test + saved evidence |
| T-REL-006 | RELEASE | re-extracted package differs | fail | automated executable test + saved evidence |

## 4. Evidence contract

For every test:

- test ID.
- source commit.
- config/dataset hashes.
- command and exit code.
- stdout/stderr artifact.
- start/end UTC.
- tool/runtime versions.
- result PASS/FAIL/SKIP/BLOCKED.
- SKIP/BLOCKED reason.

## 5. No relabeling

- Catalogued ≠ implemented.
- Implemented ≠ run.
- Run ≠ pass.
- Pass on another tree ≠ pass on release tree.
