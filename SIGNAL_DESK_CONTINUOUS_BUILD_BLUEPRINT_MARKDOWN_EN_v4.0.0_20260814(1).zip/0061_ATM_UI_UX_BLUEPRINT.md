# UI/UX Blueprint

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/15_UI_UX_BLUEPRINT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Strategy Registry

The S01 row displays:

- `ATM - Experimental`;
- current version and previous versions;
- separate lifecycle and actionability badges;
- enabled or disabled state;
- config/content hash;
- dataset mode;
- blocker count;
- latest Semantic Verification result.

Never communicate status by color alone; icon and text are mandatory.

## 2. Strategy Detail - ATM tabs

1. Overview.
2. Canonical Rules.
3. Feature Flags.
4. Current versus Target Diff.
5. Data Coverage.
6. Shadow Evaluations.
7. Backtest Variants.
8. Risk and Red Team.
9. Promotion Gates.
10. Evidence and Hashes.

## 3. Research Evaluations

Every card has an explicit banner:

`EXPERIMENTAL · RESEARCH ONLY · NOT A PAPER SIGNAL`

Display:

- symbol, side, and research state;
- rule matrix;
- snapshot time and hash;
- dataset mode and coverage;
- hypothetical entry, stop, and exit model;
- risk observation;
- objections;
- disabled features.

No Paper Ticket or Publish button.

## 4. Data Health

Add matrices for:

- price coverage;
- funding coverage and interval verification;
- OI, taker, and ratio coverage;
- gaps by symbol and date;
- dataset promotion eligibility.

## 5. Backtest UI

The user selects an explicit variant. Do not provide an ambiguous `ATM Full` option.

- PRICE_CORE.
- DERIVATIVES_RECENT.
- DERIVATIVES_LICENSED when available.

Every result displays a limitation banner.

## 6. Verification UI

Display:

- contract checks;
- cross-field checks;
- mutation kill matrix;
- source tree hash;
- evidence timestamps.

`NOT_RUN` must be visually and textually distinct from PASS.

## 7. RTL and financial conventions

- Product UI supports Arabic RTL, while symbols, numbers, and timestamps use LTR isolation.
- Never reverse the chart time axis.
- Use tabular numerals.
- Use consistent per-symbol precision.
- Translate raw enums in localized UI while keeping the code in a tooltip or detail view.
- Dialogs require focus trap, Escape close, and focus restoration.
- Support keyboard navigation and accessible labels.
