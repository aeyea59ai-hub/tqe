# 31 - Figma Handoff

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/31_FIGMA_HANDOFF.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Figma pages
01 Foundations
02 Components
03 Desktop Screens
04 Tablet Screens
05 Mobile Screens
06 Data States
07 Dialogs & Drawers
08 Motion Storyboards
09 Prototypes

## Frame sizes
Desktop Wide 1600x1000
Desktop Core 1440x960
Tablet 834x1112
Mobile 390x844
Small Mobile 360x800

## Required desktop frames
Home, Market Workspace, Scanner, Decisions, Decision Detail, Strategy Lab, Backtest, Replay, Paper Desk, Journal, Analytics, AI Desk, AI Skills, AI Providers, AI Memory, AI Traces, System.

## Auto-layout
Use 4/8/12/16/24/32 spacing tokens. Rail fixed, context bar fixed, content fill, inspector fixed width 336 when open.

## Components
Build the components in `MATRICES/COMPONENT_CATALOG.csv` as variants before screen composition.

## Prototype motion
Use `CONTRACTS/motion_tokens.json`. No Smart Animate that introduces movement not defined in the motion contract.

## Visual source
`VISUALS/` contains developer-facing wireframe/mockup images for the new target direction.
