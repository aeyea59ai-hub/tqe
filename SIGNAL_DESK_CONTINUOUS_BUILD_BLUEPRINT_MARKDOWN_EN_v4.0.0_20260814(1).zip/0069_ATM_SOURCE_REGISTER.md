# Source Register

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/24_SOURCE_REGISTER.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Internal sources

| ID | source | identity |
|---|---|---|
| SRC-001 | Signal Desk canonical source tree | Git `e23d2d4add989ffabb5dab93a98388523254a762` |
| SRC-002 | Full application/reverse-engineered package | SHA-256 `7d783d9629c6faf2fd59e92a07dfd04bc3cd2e40485d64dea5d4f21d3c37a07f` |
| SRC-003 | Signal Desk v1.1 source package | SHA-256 `381959e841f95a1978fd22317f66e40cb7288aab72e30405f7d64dd672b9e02f` |
| SRC-004 | ATM 44-school handover v1.1 | SHA-256 `23e32c5548e58e3c13c0aab51a30dbad5ee5e3be561e6108d8be88503154350e` |
| SRC-005 | Original ATM/44-school study | preserved in prior handover source |

## Official external references — accessed 2026-08-13

| ID | official source | fact used |
|---|---|---|
| EXT-001 | Binance USDⓈ-M Market Data — Exchange Information | universe/filter/status definitions |
| EXT-002 | Binance USDⓈ-M — Open Interest Statistics | latest one-month availability |
| EXT-003 | Binance USDⓈ-M — Taker Buy/Sell Volume | latest 30-day availability |
| EXT-004 | Binance USDⓈ-M — Top Trader Long/Short Ratios | API key requirement and 30-day range |
| EXT-005 | Binance USDⓈ-M — Get Funding Rate Info | fundingIntervalHours field |

Current documentation location:

- `https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data`

## Source policy

- external API behavior rechecked before implementation/release.
- documentation snapshot date recorded.
- undocumented behavior not relied upon.
- conflicting source produces a decision record, not silent selection.
