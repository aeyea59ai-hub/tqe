# 42 - Termux / Android Runtime

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/42_TERMUX_PHONE_RUNTIME.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

Target release profile: Termux host + Ubuntu/PRoot compatibility environment + Python 3.12 backend/AI runtime. React is built to static files. Services bind only to loopback. No Docker required.

## Resource policy
Scanner REST concurrency 6; symbol analysis concurrency 4; AI agent concurrency 2; backtest concurrency 1; memory retrieval top-K 8; bounded logs 25MB x5/process; WebSocket queue 2000; minimum free disk 2GB. Heavy bulk/backtest work pauses under severe thermal or very low battery conditions when detectable.

## Scripts
The starter kit includes installation, start, stop and doctor controllers. Final release must pin dependency versions and prove clean install on the target phone.
