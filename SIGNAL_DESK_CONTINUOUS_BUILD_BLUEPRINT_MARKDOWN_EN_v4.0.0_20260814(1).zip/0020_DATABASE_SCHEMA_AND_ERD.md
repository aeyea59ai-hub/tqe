# 16 - Database Schema and ERD

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/16_DATABASE_SCHEMA_AND_ERD.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

```mermaid
erDiagram
  INSTRUMENTS ||--o{ MARKET_SNAPSHOTS : has
  SCANNER_RUNS ||--o{ SCANNER_CANDIDATES : produces
  STRATEGY_VERSIONS ||--o{ DECISIONS : evaluates
  DECISIONS ||--o{ DECISION_EVIDENCE : grounds
  DECISIONS ||--o{ DECISION_OBJECTIONS : challenged_by
  DECISIONS ||--o{ PAPER_ORDERS : proposes
  PAPER_ORDERS ||--o{ PAPER_FILLS : fills
  PAPER_POSITIONS ||--o{ PAPER_POSITION_EVENTS : events
  PAPER_POSITIONS ||--o{ JOURNAL_EVENTS : journaled
  AI_PROVIDERS ||--o{ AI_MODELS : exposes
  AGENT_RUNS ||--o{ AGENT_TOOL_CALLS : uses
  SKILL_SOURCES ||--o{ SKILL_VERSIONS : versions
  SKILL_VERSIONS ||--o{ SKILL_TEST_RUNS : verified_by
  SKILL_PROFILES ||--o{ SKILL_PROFILE_BINDINGS : binds
```

`STARTER_KIT/database/schema.sql` is a logical starter DDL and must be replaced by versioned migrations during implementation. It intentionally establishes ownership and persistence boundaries rather than pretending to be a finished migration history.
