# 14 - WebSocket / Realtime Architecture

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/14_WEBSOCKET_REALTIME_ARCHITECTURE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

```json
{
  "url": "/api/v1/ws",
  "auth": "same local session; reject unauthenticated connection",
  "envelope": [
    "event_id",
    "sequence",
    "type",
    "timestamp",
    "schema_version",
    "payload"
  ],
  "events": [
    "market.tick",
    "market.candle.closed",
    "scanner.started",
    "scanner.progress",
    "scanner.completed",
    "decision.created",
    "decision.updated",
    "risk.veto",
    "paper.order",
    "paper.fill",
    "paper.position",
    "journal.appended",
    "alert.triggered",
    "provider.degraded",
    "provider.recovered",
    "agent.started",
    "agent.tool",
    "agent.completed",
    "agent.error",
    "skill.published",
    "skill.rolled_back"
  ],
  "heartbeat_seconds": 20,
  "reconnect": "client sends last sequence; server replays retained events or emits stream.gap; client reconciles by REST snapshot",
  "dedup": "event_id + sequence",
  "queue_max": 2000
}
```

The UI must never treat a reconnect as proof of current state. A sequence gap triggers REST reconciliation. Market WebSocket data may update visual charts, but only closed/validated events enter deterministic decisions.
