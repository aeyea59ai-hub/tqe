# 37 - AI Trading Desk

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/37_AI_TRADING_DESK.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Six agents only
Supervisor, Research, Market Analyst, Strategy Analyst, Evidence, Red Team. Specialist market concepts are skills/tools, not additional top-level agents.

## Agent loop
Observe context -> understand intent -> plan -> select smallest skill/tool set -> use deterministic tools -> optional model reasoning -> verify -> evidence review -> Red Team where decision-related -> answer -> save permitted memory/evaluation.

## Run inspector
Every response can expose: run ID, agents, skill versions, provider/model, tool calls, evidence IDs, privacy class, risk state, Red Team result and evaluation. Hidden chain-of-thought is not displayed.

## Failure isolation
AI down = AI pages degraded. Deterministic trading workstation remains usable.
