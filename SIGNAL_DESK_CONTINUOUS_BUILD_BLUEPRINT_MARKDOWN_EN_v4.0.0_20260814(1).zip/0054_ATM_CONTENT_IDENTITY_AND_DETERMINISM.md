# Content Identity and Determinism Blueprint

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/08_CONTENT_IDENTITY_AND_DETERMINISM.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Separate identities

Every artifact needs two distinct identifiers:

1. **Content Hash:** identity of semantic content.
2. **Instance ID:** identity of a particular observation or occurrence.

Never include the retrieval timestamp in Content Hash.

## 2. Canonicalization rules

- UTF-8 and Unicode NFC.
- Object keys sorted lexicographically.
- Sets converted to arrays sorted by a governing key.
- Chronological arrays preserve time order.
- Decimal values stored as normalized strings, not binary floating point.
- Timestamps use UTC `Z` when they are semantically part of content.
- Exclude operational fields: retrieval time, DB IDs, file paths, trace IDs, run IDs, hostnames, and durations.
- Algorithm: SHA-256.

## 3. Identity matrix

| Artifact | Included in content hash | Excluded from content hash |
|---|---|---|
| Universe | policy + normalized symbols and filters | observed_at, request latency |
| Market Snapshot | candles, components, source timestamps | fetch time, DB row ID |
| Strategy Config | rules, flags, and versions | author UI session |
| Research Evaluation | snapshot/config/result payload | persistence ID, created_at |
| Dataset | normalized partitions + transform version | download path |
| Backtest | inputs, trades, metrics, and policies | trial ID, runtime start |
| Event | prior hash + event payload + event time | DB auto ID |

## 4. Required determinism properties

- Same content with different retrieval time -> same content hash.
- Same content with different object-key order -> same hash.
- Reordered semantically unordered symbol set -> same normalized hash.
- Changed price, rule, or flag -> different hash.
- Same replay input, clock, and config -> byte-identical domain output.
- No random IDs inside canonical payload.
- No wall-clock reads inside strategy or backtest logic.

## 5. Collision and mismatch handling

- Same instance ID with a different content hash = P0 integrity failure.
- Referenced hash mismatch = reject the object; never repair it silently.
- Missing canonicalization version = invalid.
- Changing hash algorithm or canonicalization version requires migration and a dual-verification period.

## 6. Regression tests to implement

- retrieval timestamp mutation;
- key-order mutation;
- decimal formatting mutation (`1`, `1.0`, `1.000`);
- Unicode-normalization mutation;
- symbol-list order mutation;
- candle-order mutation must change hash or fail;
- hidden metadata injection must not change content hash;
- semantic-value mutation must change hash.
