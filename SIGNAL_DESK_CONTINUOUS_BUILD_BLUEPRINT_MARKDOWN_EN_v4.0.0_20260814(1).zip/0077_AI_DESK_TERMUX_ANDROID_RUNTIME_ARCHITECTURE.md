# 52 — Android / Termux Runtime Architecture

> **Source basis:** `blueprints/ai-trading-desk/source-material/52_TERMUX_ANDROID_RUNTIME_ARCHITECTURE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Goal

The complete application must be runnable on an Android phone using Termux.

The phone is a first-class deployment target, not an afterthought.

## Recommended compatibility architecture

```text
Android
└── Termux
    ├── Host shell / process manager
    ├── Node.js for frontend build/dev tools
    ├── browser opens localhost UI
    └── PRoot Ubuntu compatibility runtime
        ├── Python 3.12 virtual environment
        ├── FastAPI SIGNAL DESK backend
        ├── Agno AgentOS
        ├── AG-UI backend interface
        ├── SQLite DBs
        └── provider/search Python dependencies
```

## Why a compatibility runtime is recommended

Termux may ship a newer Python version than some AI dependency stacks are tested against.

Therefore the release must support two profiles:

### Profile A — Native Termux
Use only if every pinned dependency installs and all tests pass on the current native Termux Python.

### Profile B — Termux + Ubuntu/PRoot
Recommended compatibility profile:
- Ubuntu userland;
- pinned Python 3.12 virtual environment;
- Node may remain on Termux host or inside Ubuntu;
- all services bind to loopback.

Do not claim native Termux compatibility until it is actually tested.

## No Docker requirement

The phone release must NOT require Docker.

Docker-based examples may be used as upstream references, but the Android runbook must use ordinary processes.

## Process layout

Suggested:

```text
signaldesk-api      127.0.0.1:8000
agentos             127.0.0.1:7777
frontend            static build served by primary backend
```

Preferred production-on-phone option:
serve the built React frontend from the main FastAPI application so only one user-facing local URL is required.

## Startup controller

Provide one command:

```text
./scripts/phone-start.sh
```

Responsibilities:
- validate Termux/Ubuntu environment;
- activate venv;
- verify DB directories;
- load secrets safely;
- start AgentOS;
- start primary API;
- verify health endpoints;
- open/print local UI URL;
- write PID files;
- prevent duplicate schedulers.

Also provide:

```text
phone-stop.sh
phone-status.sh
phone-restart.sh
phone-doctor.sh
phone-backup.sh
phone-restore.sh
phone-update.sh
```

## Termux:Boot

Optional, disabled by default.

If enabled:
- start local services only;
- public tunnels remain disabled;
- do not run external writes automatically;
- verify one scheduler instance.

## Storage

Internal Termux home is preferred for databases and secrets.

Shared `/sdcard` storage should only receive explicit exports/backups, never live DB or API secrets.

## Battery / resource behavior

Phone mode must:
- cap scanner concurrency;
- cap agent concurrency;
- cap web search result count;
- cap model context/history;
- compact memory periodically;
- pause heavy backtests when battery/thermal policy requires;
- expose CPU/RAM/DB/queue health.

## Offline behavior

With no network:
- UI boots;
- DEMO works;
- local journal works;
- local memory works;
- local model works if configured and available;
- cloud AI/search clearly report unavailable;
- no fake LIVE data.

## V3 provider gateway on phone

Phone mode must support:
- Ollama Local or another verified local endpoint;
- cloud providers via outbound HTTPS;
- provider switching from Settings;
- LOCAL_ONLY routing;
- provider health;
- custom compatible endpoint validation.

All AI providers may be disabled while deterministic SIGNAL DESK remains operational.
