# 12 - Backend Architecture

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/12_BACKEND_ARCHITECTURE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Target stack
FastAPI + Pydantic v2 + SQLAlchemy 2 + Alembic + SQLite + APScheduler. Monetary/precision-sensitive domain values use Decimal-compatible representations.

## Domain ownership
- `market`: provider adapters, normalization, snapshots, features.
- `scanner`: staged universe scanning and rankings.
- `strategies`: registry, rule execution, drafts/versioning.
- `decisions`: card assembly, lifecycle, evidence references.
- `risk`: sizing, leverage, liquidation, locks, heat/correlation.
- `paper`: preview/confirm, orders, fills, positions, lifecycle.
- `journal`: append-only events and reconciliation.
- `analytics`: ledger-derived metrics.
- `ai`: agents, provider gateway, context, memory, tool gateway.
- `skills`: registry, drafts, testing, profiles, publish/rollback.
- `ops`: audit, alerts, health, backup/restore.

## Request execution
Request -> auth/CSRF -> schema validation -> application service -> deterministic domain service -> transaction -> audit/event -> response. Network/model calls must not hold a database write transaction open.

```mermaid
flowchart LR
  UI["React Web/PWA"] --> API["FastAPI REST + WebSocket"]
  API --> Domain["Deterministic Domain Services"]
  Domain --> DB["SQLite + Alembic"]
  Domain --> Market["Public Market Adapters"]
  Domain --> Scheduler["Scheduler / Jobs"]
  UI --> AgentUI["AI Desk / AG-UI"]
  AgentUI --> AgentRuntime["Agent Runtime"]
  AgentRuntime --> ToolGW["Tool Gateway"]
  ToolGW --> Domain
  AgentRuntime --> ModelRouter["Model Policy Router"]
  ModelRouter --> ProviderGW["AI Provider Gateway"]
  ProviderGW --> Models["Local / Cloud Models"]
```
