# 19 - Data Flow Architecture

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/19_DATA_FLOW_ARCHITECTURE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Market decision flow
```mermaid
flowchart LR
  P["Public Provider"] --> A["Adapter"] --> V["Validation + Normalization"] --> S["Immutable Snapshot"] --> F["Features/Structure"] --> SC["Scanner"] --> ST["Strategy"] --> ES["Evidence Score"] --> RT["Red Team"] --> R["Risk Gate"] --> D["Decision Card"] --> UI["UI"]
```

## Paper flow
```mermaid
sequenceDiagram
  participant U as Owner
  participant UI as UI
  participant API as Backend
  participant R as Risk
  participant P as Paper Engine
  participant J as Journal
  U->>UI: Confirm paper preview
  UI->>API: confirmation + preview hash
  API->>R: revalidate current risk
  R-->>API: PASS or VETO
  API->>P: create paper event only on PASS
  P->>J: append order/fill/position events
  J-->>API: reconciled account state
  API-->>UI: updated paper state
```

## AI flow
```mermaid
flowchart LR
  U["User Task"] --> C["Context Engine"] --> S["Supervisor"]
  S --> TG["Tool Gateway"] --> D["Deterministic Services"]
  S --> MR["Model Router"] --> PG["Provider Gateway"]
  D --> E["Evidence"]
  PG --> E
  E --> RT["Red Team when decision-related"] --> A["Answer + Trace"]
```
