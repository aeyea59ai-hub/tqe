# 04 - Complete Feature Catalog

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/04_COMPLETE_FEATURE_CATALOG.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

| ID | Feature | Category | Priority | UI | Modules | Rules |
| --- | --- | --- | --- | --- | --- | --- |
| F001 | Local Owner Authentication | Foundation | P0 | System | Auth/API/DB | First setup creates owner credential; writes require authenticated session and CSRF. |
| F002 | Runtime Profiles | Foundation | P0 | Global | Runtime/Config | No profile may silently masquerade as another profile. |
| F003 | Arabic/English RTL/LTR | Foundation | P1 | Global | Frontend/i18n | Arabic layout RTL; market symbols, prices and timestamps remain LTR. |
| F004 | Command Palette | UX | P2 | Global | Frontend | Read-only actions may execute directly; write actions open their normal confirmation flow. |
| F005 | Workspace Layout Preferences | UX | P2 | Market | Frontend/Storage | Corrupt preference data resets safely without affecting domain records. |
| F006 | Dynamic Futures Universe | Market | P0 | Market/Scan | Market Data | Eligibility is derived from provider metadata; delisted/ineligible instruments cannot publish. |
| F007 | Market Snapshot | Market | P0 | Market | Market Data/Domain | Critical fields must meet freshness/coherence rules. |
| F008 | Closed Candle Pipeline | Market | P0 | Market/Scan | Market Data | Forming candles may display but never enter authoritative calculations. |
| F009 | Candlestick Chart | Market | P1 | Market | Frontend/Chart | Chart visuals do not own calculations. |
| F010 | Indicator Engine | Market | P0 | Market | Domain | All values deterministic and versioned. |
| F011 | Market Structure | Market | P0 | Market | Domain | Confirmed-pivot rules must be non-repainting. |
| F012 | Funding Context | Derivatives | P1 | Market/Scan | Market Data/Domain | Funding is evidence, not standalone trade authority. |
| F013 | Open Interest Context | Derivatives | P1 | Market/Scan | Market Data/Domain | Stale OI cannot support a decision. |
| F014 | Liquidity & Depth | Derivatives | P1 | Market/Paper | Market Data/Domain | Insufficient depth blocks final paper approval when required. |
| F015 | Market Breadth & Heatmap | Market | P2 | Home/Market | Domain/Frontend | Derived from eligible universe and current snapshots. |
| F016 | Staged Scanner | Scanner | P0 | Scan | Scanner/Domain | Every exclusion reason must be visible and auditable. |
| F017 | Scanner Ranking | Scanner | P0 | Scan | Scanner/Domain | Same inputs/config produce same ordering. |
| F018 | Manual & Scheduled Scan | Scanner | P1 | Scan | Scheduler/Scanner | Only one effective scheduler instance per job. |
| F019 | Evidence Score | Decision | P0 | Scan/Decisions | Evidence Engine | Missing optional data cannot increase score; degraded cap enforced. |
| F020 | Decision Card | Decision | P0 | Decisions | Decision Engine/DB | Card pins versions, evidence, risk, provenance and integrity hash. |
| F021 | Decision Lifecycle | Decision | P0 | Decisions | Decision Engine | Invalid transitions rejected and audited. |
| F022 | Red Team R1-R6 | Decision | P0 | Decisions | Red Team | Hard objections are non-overridable. |
| F023 | Six-Agent Council | AI | P1 | AI/Decisions | AI Runtime | Agents are advisory; deterministic services own numbers and final hard gates. |
| F024 | Strategy Registry | Strategies | P0 | Strategies | Strategy Engine/DB | Research-only strategies cannot publish. |
| F025 | Primary Strategies | Strategies | P0 | Strategies | Strategy Engine | Numeric rules and versions are immutable once published. |
| F026 | Research Strategies | Strategies | P1 | Strategies | Strategy Engine | Status RESEARCH_ONLY; no publication/paper promotion without governance. |
| F027 | Strategy Draft & Validation | Strategies | P1 | Strategies | Strategy Engine | Published versions are immutable. |
| F028 | Backtesting | Research | P0 | Backtest | Backtest Engine | No lookahead; dataset manifest/cost model pinned. |
| F029 | Replay | Research | P1 | Replay | Replay Engine | Replay mode never labels data live. |
| F030 | Strategy Performance | Research | P1 | Analytics/Strategies | Analytics | Every metric shows sample size and cost assumptions. |
| F031 | Position Sizing | Risk | P0 | Paper/Decisions | Risk Engine | Decimal precision and exchange step constraints enforced. |
| F032 | Leverage Gate | Risk | P0 | Paper/Decisions | Risk Engine | LONG <=5x; SHORT <=3x under v1.0. |
| F033 | Liquidation Safety | Risk | P0 | Paper/Decisions | Risk Engine | Minimum liquidation distance = 3x stop distance or block. |
| F034 | Effective R Gate | Risk | P0 | Paper/Decisions | Risk Engine | Minimum 2.0 effective blended R. |
| F035 | Daily/Weekly Locks | Risk | P0 | Home/Paper | Risk Engine | Daily -2R; weekly -6R. |
| F036 | Loss Reducer | Risk | P0 | Paper | Risk Engine | Risk becomes 0.25% until next realized win. |
| F037 | Calibration Risk | Risk | P0 | Paper | Risk Engine | 0.25% risk through first 30 closed trades. |
| F038 | Correlation Gate | Risk | P0 | Paper/Risk | Risk Engine | Maximum two BTC-correlated positions under active policy. |
| F039 | Paper Preview & Confirmation | Paper | P0 | Paper | Paper Engine/API | Confirmation uses hash/version binding and cannot call exchange. |
| F040 | Paper Orders/Fills | Paper | P0 | Paper | Paper Engine/DB | 50% TP1, move to BE, 50% TP2; no real order path. |
| F041 | Paper Positions | Paper | P0 | Paper | Paper Engine/DB | Append-only financial events reconcile. |
| F042 | Manual Paper Close | Paper | P1 | Paper | Paper Engine | Close creates journaled event and updates locks in same cycle. |
| F043 | Journal Hash Chain | Journal | P0 | Journal/Audit | Journal/DB | Losses/rejections cannot be deleted; corrections append. |
| F044 | Portfolio & Risk View | Paper | P1 | Paper | Portfolio/Risk | Derived from journal/positions, not independent mutable totals. |
| F045 | Analytics V2 | Analytics | P1 | Analytics | Analytics | No synthetic outcome series. |
| F046 | Calibration Analytics | Analytics | P2 | Analytics | Analytics | Low sample warnings mandatory. |
| F047 | Data Quality Analytics | Analytics | P2 | Analytics | Analytics | Shows denominators and blocked percentage. |
| F048 | Alerts | Operations | P2 | System | Alerts/Scheduler | Dedup/cooldown required; external writes disabled in base release. |
| F049 | Daily Brief | Operations | P2 | Home/System | Brief/AI | Numeric facts come from deterministic services. |
| F050 | Provider Health | Operations | P1 | Home/System/AI | Providers | Health state must reflect actual checks, never assumed connectivity. |
| F051 | Audit Log | Operations | P0 | System | Audit/DB | Sensitive values redacted. |
| F052 | Backup & Restore | Operations | P1 | System | Backup/DB | Secrets excluded; restore validates before switch. |
| F053 | Methodology & Limitations | Operations | P2 | System | Docs/UI | No profitability promise. |
| F054 | AI Chat | AI | P1 | AI | AI Runtime | Read-only; numeric claims must be grounded or abstained. |
| F055 | Tool Gateway | AI | P0 | AI | Tool Gateway | Prompts cannot grant permissions. |
| F056 | AI Provider Gateway | AI | P1 | AI Providers | Provider Gateway | Provider can be disabled/deleted without changing agents/tools/memory. |
| F057 | Provider Routing Policies | AI | P1 | AI Providers | Provider Gateway | Privacy class constrains fallback. |
| F058 | Custom AI Provider | AI | P2 | AI Providers | Provider Gateway/Security | SSRF and capability validation required. |
| F059 | AI Memory | AI | P1 | AI Memory | Memory | Trading/journal truth stays in domain tables. |
| F060 | Knowledge Base | AI | P2 | AI Memory | Knowledge | Versioned source and freshness metadata. |
| F061 | Skill Registry | AI | P1 | AI Skills | Skill Control | Source packs immutable. |
| F062 | Skill Draft/Test/Publish/Rollback | AI | P1 | AI Skills | Skill Control | Edit creates draft; published version immutable. |
| F063 | Skill Traceability | AI | P1 | AI Traces | Skill Control/Audit | Exact version/hash pinned. |
| F064 | Agent Run Traces | AI | P1 | AI Traces | AI Runtime/Audit | Show structured execution facts only. |
| F065 | Agent Evaluations | AI | P2 | AI Traces | Evaluation | Cannot silently modify risk/strategy. |
| F066 | Web/News Research Adapter | AI | P2 | AI | Research Adapter | External text is untrusted and never market numeric authority. |
| F067 | Offline Demo | Runtime | P0 | Global | Runtime/Fixtures | No network dependency for DEMO. |
| F068 | Termux Runtime | Runtime | P1 | System | Runtime/Scripts | Loopback-only services; AI failure isolated. |
| F069 | Health/Doctor Tools | Runtime | P1 | System | Runtime/Ops | Read-only health checks. |
| F070 | Evidence Export | Operations | P1 | Audit/System | Export | No secrets; hashes included. |
