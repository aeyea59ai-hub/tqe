# ATM Canonical Rulebook - S01 v2.0.0-experimental

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/05_ATM_CANONICAL_RULEBOOK_V2.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

> These rules are a testable hypothesis, not a performance claim. Every calculation uses closed candles only.

## 1. Identity

| Field | Value |
|---|---|
| Strategy ID | `S01` |
| Version | `2.0.0-experimental` |
| Name | `ATM - Asymmetric Trend & Momentum` |
| Initial lifecycle | `NUMERICALLY_DEFINED` |
| Actionability | `RESEARCH_ONLY` |
| Enabled by default | `false` |
| Regime timeframe | `1D` |
| Setup timeframe | `4H` |
| Trigger timeframe | `15m` |

## 2. Indicator definitions

### EMA

- Smoothing factor: `2 / (period + 1)`.
- Seed: arithmetic mean of the first `period` valid closes.
- Do not use the value before warm-up is complete.

### ATR

- Standard True Range.
- Period 14.
- Wilder RMA smoothing.
- ATM must consume the shared Feature Engine ATR; it must not redefine ATR locally.

### Swings and CHoCH

- Pivot confirmation: `k=2` complete candles on each side.
- A swing high requires strict superiority; equal highs do not create a pivot.
- The pivot is not known until `pivot_index + k`.
- A level break requires a close beyond the level, not only a wick.
- Consume each structural level once.

## 3. Minimum history

| Timeframe | Minimum closed bars | Reason |
|---|---:|---|
| 1D | 250 | EMA200, slope, and ATR percentile |
| 4H | 320 | EMA96, swings, and stable warm-up |
| 15m | 100 | trigger and execution context |

Insufficient history returns `INSUFFICIENT_HISTORY`.

## 4. Momentum Score

Calculate on the latest closed 4H candle:

- EMA 8 versus 24.
- EMA 16 versus 48.
- EMA 32 versus 96.
- Divide each spread by ATR14(4H).
- Score is the arithmetic mean of the three normalized spreads.

Thresholds:

- LONG: score >= `+1.0`.
- SHORT: score <= `-1.5`.
- Otherwise: `NO_SETUP`.

## 5. Daily regime gate

### LONG

All conditions must pass:

1. Close(1D) > EMA200(1D).
2. EMA50 slope across 10 daily candles > 0.
3. Shared Regime Engine is not `RANGING`, `TRANSITION`, or `HIGH_VOLATILITY`.

Slope definition: current EMA minus EMA ten candles earlier, divided by daily ATR14. Only a positive sign is required; no additional fitted threshold is allowed in this version.

### SHORT

All conditions must pass:

1. Close(1D) < EMA200(1D).
2. EMA200 slope across 10 daily candles <= 0.
3. Confirmed CHoCH-DOWN on 4H within the latest 12 closed candles.
4. Shared Regime Engine is `TRENDING_DOWN`.

## 6. Volatility gate

- ATR% = ATR14(1D) / Close(1D).
- Compute percentile rank across the latest 180 valid daily values.

| Percentile | Result |
|---|---|
| <15 | `WAIT_EXPANSION`; no Research Trade |
| 15 to <90 | pass |
| >=90 | `HIGH_VOLATILITY_REJECT` |

Position-size volatility targeting is **disabled** in this version. Shared Risk Policy determines size.

## 7. Funding and crowding

- Funding z-score window: 30 calendar days.
- Calculate mean and standard deviation only from observations covering that window.
- Minimum coverage: 75% of expected funding intervals according to the versioned interval ledger.
- Standard deviation zero or inadequate coverage returns `FUNDING_Z_UNAVAILABLE`.

### LONG

- z > 3.0: reject.
- 2.0 < z <= 3.0: research risk scale = 0.50, never exceeding Risk Policy.

### SHORT

- z < -1.5: reject because of squeeze/crowding risk.

### Funding-cost veto

If conservative expected paid funding over the expected holding period - `168h` LONG and `72h` SHORT - is greater than `0.25R`, reject the hypothesis. Exactly `0.25R` passes this condition by itself.

## 8. Open Interest and Long/Short ratios

- OI is evidence-only in `v2.0.0`.
- OI hard gate: OFF.
- Top-trader ratios: OFF.
- Missing data must not be invented.
- Do not use these features in a multi-year promotion backtest without a valid Dataset Manifest covering the entire period.

## 9. Pullback and trigger

### Impulse leg

- LONG: latest confirmed swing low followed by a confirmed swing high, with the high newer than the low.
- SHORT: latest confirmed swing high followed by a confirmed swing low.
- No complete leg returns `NO_CONFIRMED_IMPULSE`.

### Pullback zone

- Fibonacci retracement from 38.2% to 61.8% of the impulse leg.
- EMA20(4H) must lie inside the zone; otherwise return `EMA20_NOT_IN_PULLBACK_ZONE`.
- No-chase: distance from price to EMA20 must not exceed `2.0 x ATR14(4H)`.

### 15m trigger

After price enters the zone:

- LONG: a 15m candle closes bullish and above the previous candle high.
- SHORT: a 15m candle closes bearish and below the previous candle low.
- A trigger may fire once per setup version.

### Research fill

- `NEXT_15M_OPEN_AFTER_TRIGGER`.
- This fill is for Backtest, Replay, and Shadow research only.
- Limit-entry feature: OFF.
- It cannot become a Paper Order before promotion.

### Expiry

The setup expires 12 closed 4H candles after the pullback zone forms if no trigger occurs.

## 10. Stop architecture

1. LONG raw stop = latest confirmed swing low - 0.6 x ATR14(4H).
2. SHORT raw stop = latest confirmed swing high + 0.6 x ATR14(4H).
3. If distance <1.2 x ATR, widen it to 1.2 x ATR.
4. If distance >3.5 x ATR, reject the setup.
5. Never widen the stop after entry.
6. Quantize prices to tick size after calculation, then revalidate geometry.

## 11. Exit model

`TRAILING_ONLY_RESEARCH_V1`:

- A hard stop always exists.
- Chandelier ATR22(4H):
  - LONG: highest high since entry - 3.0 x ATR22.
  - SHORT: lowest low since entry + 2.5 x ATR22.
- The trailing stop can move only in the protective direction.
- Time stop:
  - LONG: 168 hours.
  - SHORT: 72 hours.
  - If MFE has not reached 1R, exit research at the next 15m open.
- Daily regime reversal: exit at the first 15m open after the reversal becomes known from a closed 1D candle.
- Cumulative paid funding >0.3R: exit at the next 15m open.
- Partial exit of 40% at 2R: OFF.
- Macro event blackout: OFF.
- Fixed TP1/TP2: not used in the Research Evaluation.

## 12. Risk authority

ATM does not calculate risk fraction, leverage, or liquidation. It consumes active Signal Desk Risk Policy:

- LONG 0.50%; SHORT 0.35%.
- Calibration and losing-streak overrides come from the Risk Engine.
- Leverage caps: 5x LONG, 3x SHORT.
- Missing MMR data returns `LIQ_DATA_UNAVAILABLE`; no actionable decision is permitted.
- Do not satisfy minimum notional by increasing size. Reject when the conservative quantity does not meet exchange filters.

## 13. Same-bar policy

For backtest and paper research:

- Stop has priority over target or favorable trailing exit when the path inside the OHLC bar is ambiguous.
- If the fill and stop are both touched in the same candle, conservatively assume fill followed by stop.
- Never invent an intrabar ordering.
