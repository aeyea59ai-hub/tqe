# 06 - User Flows

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/06_USER_FLOWS.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

| ID | Flow | Steps | Success |
| --- | --- | --- | --- |
| FLOW001 | First local launch | Open app -> owner setup/login -> DEMO default -> Home loads deterministic fixtures -> health shown -> no cloud required | Usable local app with explicit DEMO label |
| FLOW002 | Find a market | Ctrl+K or symbol control -> search -> select symbol -> /market/:symbol -> snapshot/candles/features load -> stale/degraded state shown if needed | Single-symbol workspace |
| FLOW003 | Run scan | Scan -> Run -> universe/data/liquidity/regime/features/strategy/derivatives/trade-plan/risk/evidence/red-team stages -> ranking table -> open candidate inspector | Ranked auditable candidates and exclusions |
| FLOW004 | Inspect decision | Decision row -> detail -> geometry -> evidence -> red team -> risk -> provenance -> lifecycle -> related strategy/backtest | Complete auditable decision understanding |
| FLOW005 | Create paper position | Eligible decision -> paper preview -> preview hash -> owner confirm -> paper order -> fill lifecycle -> position -> journal -> portfolio/risk same-cycle update | Paper-only position; no exchange write |
| FLOW006 | Paper TP1 to BE | Position open -> TP1 touch -> 50% fill -> fees/slippage/funding journaled -> stop moved to cost-adjusted BE -> risk/portfolio refreshed | BE-protected partial position |
| FLOW007 | Backtest strategy | Strategy detail -> Backtest -> dataset/time/cost config -> run -> manifest/hash -> metrics/trades/equity/OOS panels -> compare with promotion gates | Reproducible evidence artifact |
| FLOW008 | Replay strategy | Strategy -> Replay -> choose dataset -> step clock -> inspect feature/rule/risk state -> compare resulting decisions | Deterministic historical walkthrough |
| FLOW009 | AI market question | AI Desk -> context resolves current symbol/page -> Supervisor selects skills/tools -> deterministic tool calls -> specialists -> Evidence -> Red Team if decision-related -> answer + trace | Grounded answer with tool/skill/provider trace |
| FLOW010 | Change AI provider | AI Providers -> select/add provider -> test endpoint/model/capabilities -> enable -> routing policy -> future AI run selects it if policy allows | Provider changed without changing agents/tools/memory |
| FLOW011 | Edit a skill safely | AI Skills -> skill detail -> Create Draft -> edit -> validate -> tests -> impact -> publish -> profile atomic switch -> trace pins version -> rollback available | Controlled skill change |
| FLOW012 | Provider outage | Health check fails -> provider state degraded/offline -> allowed fallback evaluated -> LOCAL_ONLY blocks cloud fallback -> AI shows unavailable if needed -> deterministic app remains functional | Failure isolated and truthful |
| FLOW013 | Backup and restore | System -> Backup -> atomic DB/config export -> checksums -> restore validate -> integrity/schema/reconcile -> explicit confirm -> switch -> health checks | Recoverable local state without secrets in backup |
