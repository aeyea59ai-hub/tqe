# Skill Control Plane database model

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/06_SKILL_DATABASE_SCHEMA.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

Recommended logical tables:

```text
skill_sources
- id
- pack_id
- source_path
- source_sha256
- imported_at
- immutable=true

skill_versions
- id
- slug
- semver
- status
- content
- content_sha256
- classification
- created_from_version_id
- created_at
- published_at
- published_by

skill_drafts
- id
- slug
- base_version_id
- content
- content_sha256
- validation_status
- created_by
- updated_at

skill_installations
- slug
- active_version_id
- enabled
- activation_mode
- protected

skill_profiles
- id
- name
- version
- active

skill_profile_bindings
- profile_id
- slug
- version_id
- state

skill_agent_bindings
- version_id
- agent_id
- activation_condition

skill_tool_bindings
- version_id
- tool_id
- permission_class
- confirmation_required

skill_dependencies
- version_id
- depends_on_slug
- required

skill_test_runs
- id
- version_id
- content_sha256
- suite
- status
- evidence_path
- executed_at

skill_evaluations
- id
- version_id
- scenario_set
- score
- findings

skill_audit_events
- id
- event_type
- slug
- version_id
- actor
- timestamp
- metadata
```

## Integrity constraints

- published content cannot be updated;
- active_version_id references PUBLISHED only;
- test hash must equal publish hash;
- protected skills cannot be disabled through normal API;
- historical decisions pin version IDs.
