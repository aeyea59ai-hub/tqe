# Source Authority and Conflict Resolution

## Precedence

1. Current explicit owner decisions.
2. Fresh source code, configuration, migrations, tests and reproducible evidence.
3. This continuous-build blueprint.
4. Approved active strategy, risk and data-policy versions.
5. Historical reports and legacy prototypes as reference.

## Conflict handling

Conflicts are recorded with the competing statements, evidence, selected resolution, affected requirements, implementation impact, migration impact, test impact and rollback impact. The resolution that best preserves current source truth, owner intent, deterministic authority, safety and backward compatibility becomes the working decision.

## Unknown values

Unknown numeric behavior remains a disabled feature flag, an explicit configuration field without an active value, or a non-actionable research state. Unknown values are never filled with plausible-looking market numbers or performance claims.
