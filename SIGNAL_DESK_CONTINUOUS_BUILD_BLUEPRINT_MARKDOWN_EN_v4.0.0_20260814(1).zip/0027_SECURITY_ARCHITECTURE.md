# 23 - Security Architecture

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/23_SECURITY_ARCHITECTURE.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Hard prohibitions
- No live order route or signed exchange client.
- No withdrawal/transfer capability.
- No private exchange credentials.
- No prompt-based permission elevation.
- No raw secrets returned to frontend.

## Controls
Local owner authentication, HttpOnly session, CSRF on writes, loopback-only binding, input schema validation, ORM/parameterized DB access, output escaping, security headers, provider URL validation, secret redaction, audit events, append-only journal integrity, backup verification, dependency/secret/forbidden-surface scans.

## Custom provider SSRF control
Validate protocol, DNS resolution, resolved IP, redirects, TLS, port and response size. Explicit loopback is allowed for local AI. Cloud metadata/link-local/private LAN targets are rejected unless a future owner policy explicitly authorizes a narrow endpoint class.

## AI prompt injection
External research text is data only. It cannot alter system instructions, grant tools, modify risk or change skill permissions. Model output is schema/evidence validated before paper confirmation can be offered.
