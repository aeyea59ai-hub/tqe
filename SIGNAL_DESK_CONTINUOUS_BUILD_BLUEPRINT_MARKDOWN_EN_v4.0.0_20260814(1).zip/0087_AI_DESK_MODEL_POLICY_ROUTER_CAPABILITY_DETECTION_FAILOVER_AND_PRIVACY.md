# 63 — Model Policy Router, Capability Detection, Failover, and Privacy

> **Source basis:** `blueprints/ai-trading-desk/source-material/63_MODEL_POLICY_ROUTER_CAPABILITY_DETECTION_FAILOVER_AND_PRIVACY.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Routing policies

Support:

```text
AUTO
BEST_QUALITY
FASTEST
LOWEST_COST
LOCAL_ONLY
CLOUD_ONLY
PRIVACY_FIRST
MANUAL
STRICT_STRUCTURED
```

## Capability detection

Every model has a capability record:

```json
{
  "text": true,
  "vision": false,
  "tools": true,
  "streaming": true,
  "structured_output": true,
  "reasoning": true,
  "files": false,
  "max_context": 128000
}
```

Do not route a task to a model lacking required capabilities.

## Task requirements

Examples:

### Chart image analysis
```text
requires:
VISION = true
```

### Tool-using market research
```text
requires:
TOOLS = true
STREAMING = preferred
```

### Evidence Agent
```text
requires:
STRUCTURED_OUTPUT = true
LOW_TEMPERATURE = preferred
```

## Role policies

Recommended defaults:

```text
Supervisor      -> AUTO / BEST_QUALITY
Research        -> CLOUD or AUTO
Market Analyst  -> AUTO
Strategy        -> BEST_QUALITY
Evidence        -> STRICT_STRUCTURED
Red Team        -> DIFFERENT_MODEL_PREFERRED
```

Using an independent provider/model for Red Team is preferred where feasible to reduce correlated model failure.

## Privacy classes

Every task receives:

```text
PUBLIC
INTERNAL
PRIVATE
SENSITIVE
```

Example policy:

```text
PRIVATE JOURNAL
→ LOCAL_ONLY

PUBLIC MARKET NEWS
→ CLOUD_ALLOWED

SECRETS
→ NEVER_SEND_TO_MODEL
```

## Failover

Configurable chain:

```text
PRIMARY
→ FALLBACK_1
→ FALLBACK_2
→ LOCAL
```

Failover records:
- failed provider;
- failure reason;
- selected fallback;
- data/privacy policy check.

Never fail over a LOCAL_ONLY task to cloud.

## Routing score

AUTO may consider:
- capability match;
- privacy;
- health;
- latency;
- cost;
- quality tier;
- context size;
- tool support;
- historical reliability.

Trading-domain facts never depend on model routing.
