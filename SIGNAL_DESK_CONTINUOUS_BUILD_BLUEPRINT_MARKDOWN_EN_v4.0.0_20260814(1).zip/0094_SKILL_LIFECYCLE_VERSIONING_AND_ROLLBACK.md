# Skill lifecycle, versioning, and rollback

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/01_SKILL_LIFECYCLE_VERSIONING_AND_ROLLBACK.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## States

```text
IMPORTED
→ CLASSIFIED
→ DRAFT
→ VALIDATED
→ TESTED
→ PUBLISHED
→ ACTIVE / DISABLED
→ DEPRECATED
```

A published version is immutable.

## Editing

Pressing **Edit** performs:

`Clone Published Version → Draft`.

The current active version keeps running until the new draft passes every mandatory gate and is published.

## Publish transaction

Publishing must be atomic:

1. verify expected current version;
2. verify tests belong to the draft hash;
3. verify impact analysis;
4. write immutable published version;
5. update selected profile binding;
6. append audit event;
7. preserve previous version for rollback.

## Rollback

Rollback changes the active profile pointer to a prior published version.

It never deletes:
- the failed/new version;
- historical run references;
- test results;
- decisions generated under older versions.

## Deletion

Published versions referenced by runs/decisions are never hard-deleted.

Use `DEPRECATED` or `TOMBSTONED`.

Drafts with no references may be deleted.

## Historical reproducibility

Every agent run/decision records:
- skill slug;
- exact skill version;
- content SHA-256;
- active profile;
- model/provider;
- tool versions;
- policy versions.
