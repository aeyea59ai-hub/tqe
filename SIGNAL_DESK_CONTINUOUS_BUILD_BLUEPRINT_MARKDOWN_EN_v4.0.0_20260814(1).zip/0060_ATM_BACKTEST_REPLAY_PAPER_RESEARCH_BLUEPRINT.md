# Backtest, Replay, and Paper Research Blueprint

> **Source basis:** `ATM_EXPERIMENTAL_INTEGRATION/14_BACKTEST_REPLAY_PAPER_RESEARCH_BLUEPRINT.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## 1. Same-core requirement

Backtest and Replay use the same:

- indicator definitions;
- structure detection;
- ATM evaluator;
- Risk Policy;
- exit lifecycle;
- precision rules.

No separate simplified implementation may contradict runtime behavior.

## 2. Research periods

Baseline target:

- Full available price period: January 2021 through the last completed month before the run.
- OOS: final chronological 40%, excluded from tuning.
- Walk-forward: six months training and two months testing, rolling.
- Separate LONG and SHORT reports.
- Minimum 150 total closed trades; otherwise record insufficient sample.

Lock final dates in the Backtest Request. Never write predetermined performance values.

## 3. Execution assumptions

- closed bars only;
- trigger becomes known only after close;
- fill at next 15m open;
- versioned fees, funding, and slippage;
- conservative same-bar ordering;
- preserve delisted symbols and history;
- warn when a historical universe cannot prevent survivorship bias.

## 4. Cost scenarios

- base documented fee model;
- 2x fees;
- 3x slippage;
- adverse funding;
- combined stress.

Any promotion artifact must evaluate expectancy after costs, not gross result.

## 5. Metrics

- trade count and explicit win-rate definition;
- expectancy in R;
- profit factor;
- maximum drawdown in R and percent;
- Sharpe and Sortino with explicit frequency;
- exposure time;
- LONG/SHORT attribution;
- symbol, regime, and year attribution;
- tail loss and gap/slippage sensitivity;
- parameter count and Deflated Sharpe where applicable.

## 6. Replay

- Pin input snapshot, dataset, and config hashes.
- Use replay clock only.
- Repeated runs must produce identical outputs.
- UI distinguishes observed time from replay time.

## 7. Paper Research

ATM v2 does not enter the Paper Order engine initially. After deterministic trailing-only lifecycle support and promotion to `PAPER_ELIGIBLE`:

- begin with BTCUSDT and ETHUSDT only;
- require at least 60 closed signals;
- never attribute manual sandbox outcomes to ATM;
- no automatic universe expansion.
