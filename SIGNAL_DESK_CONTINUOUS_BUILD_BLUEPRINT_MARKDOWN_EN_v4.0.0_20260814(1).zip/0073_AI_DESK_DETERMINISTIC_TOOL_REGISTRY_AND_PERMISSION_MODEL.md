# 48 — Deterministic Tool Registry and Permission Model

> **Source basis:** `blueprints/ai-trading-desk/source-material/48_DETERMINISTIC_TOOL_REGISTRY_AND_PERMISSION_MODEL.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

## Core principle

Agents receive **tools**, not direct database or engine authority.

Every tool:
- has a typed schema;
- validates input;
- returns structured output;
- records audit metadata;
- enforces user/session permissions;
- has timeout and size limits;
- cannot expose secrets.

## Market tools — SAFE_READ

```text
scan_market()
analyze_symbol(symbol)
get_candles(symbol, timeframe, limit)
get_market_snapshot(symbol)
get_regime(symbol?)
get_funding(symbol)
get_open_interest(symbol)
get_order_book(symbol, depth)
get_liquidity(symbol)
get_market_breadth()
get_heatmap(mode)
```

## Strategy tools — SAFE_READ / COMPUTE

```text
list_strategies()
get_strategy(strategy_id, version?)
run_strategy(strategy_id, symbol, snapshot_id?)
run_backtest(strategy_id, symbol, period, config?)
run_replay(strategy_id, symbol, replay_id)
get_strategy_performance(strategy_id)
compare_strategies(strategy_ids, scope)
```

## Risk tools — SAFE_READ / COMPUTE

```text
check_risk(decision_or_plan_id)
calculate_trade_plan(candidate_id, paper_equity, risk_pct)
calculate_position_size(...)
calculate_liquidation_safety(...)
get_portfolio_heat()
get_risk_locks()
explain_risk_veto(decision_id)
```

Agents may call these. They may not reproduce the arithmetic and claim it as authoritative.

## History / evidence tools — SAFE_READ

```text
search_journal(query, filters)
get_previous_decisions(symbol, limit)
get_decision(decision_id)
get_decision_evidence(decision_id)
get_audit_events(entity_id)
search_agent_runs(query)
search_memory(query)
search_knowledge(query)
```

## Research tools — EXTERNAL_READ

```text
web_search(query, recency?, domains?)
news_search(query, recency?, domains?)
fetch_research_source(source_id)
```

Research results must include provenance.

## Paper write tool — HUMAN_CONFIRMATION_REQUIRED

```text
create_paper_signal(decision_id, amount_or_risk)
close_paper_position(position_id, reason)
cancel_paper_order(order_id)
```

The agent can propose invocation.

The UI must show:
- exact action;
- symbol;
- side;
- paper amount/risk;
- authoritative entry/stop/targets;
- Risk Gate status.

The user confirms before the tool executes.

## Admin-only tools

Not exposed to ordinary agents:

```text
set_provider_secret()
change_risk_policy()
promote_strategy()
delete_user_memory()
restore_backup()
change_network_binding()
```

## Forbidden tools

Never implement in base release:

```text
place_live_order()
cancel_live_order()
withdraw()
transfer()
set_exchange_private_key_for_trading()
disable_risk_gate()
override_stop()
override_position_size()
```
