# Baseline and Target Work Items

## Baseline

The available Signal Desk lineage includes a React/Vite/TypeScript frontend, a FastAPI/Pydantic/SQLAlchemy/Alembic/SQLite/APScheduler backend, strategy/risk/paper domains, automated tests and historical QA evidence. It is not treated as a finished release.

## Target work

- preserve verified existing behavior while correcting root causes;
- make migrations historically immutable and reproducible;
- complete frontend dependency restoration, type checking, unit tests, production/offline builds and browser acceptance;
- complete backend property, integration, migration, security and reliability coverage;
- complete full-universe public market-data behavior and provider resilience;
- integrate ATM as an immutable experimental Research-only strategy version;
- implement the evidence-bound AI Trading Desk and provider gateway;
- implement the Skill Control Plane with versioning, permissions, testing and audit;
- complete API, database, state-machine, UI, security, CI/CD, backup, rollback and release capabilities;
- implement semantic verification and targeted mutation proof;
- produce clean source, local release, offline preview, evidence and rollback artifacts.

## Status interpretation

Earlier U7/U8 labels are historical evidence. This package converts every unresolved item into an implementation or verification task and keeps the build moving through all independent work.
