# 28 - Repository and Module Map

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/28_REPOSITORY_AND_MODULE_MAP.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

```text
signal-desk/
  apps/
    web/
      src/app/
      src/shell/
      src/pages/
      src/features/
      src/components/
      src/api/
      src/state/
      src/i18n/
      src/theme/
    api/
      app/main.py
      app/api/
      app/domain/market/
      app/domain/scanner/
      app/domain/strategies/
      app/domain/decisions/
      app/domain/risk/
      app/domain/paper/
      app/domain/journal/
      app/domain/analytics/
      app/ai/
      app/skills/
      app/ops/
      app/storage/
      migrations/
  packages/
    contracts/
    schemas/
    design-tokens/
    strategy-definitions/
    skill-contracts/
  config/
    policies/
    strategies/
    runtime/
  tests/
    unit/
    property/
    integration/
    e2e/
    security/
    phone/
  scripts/
  docs/
  evidence/
```

Ownership is domain-first. Frontend utilities must not duplicate backend financial/domain calculations.
