# 33 - Requirements Traceability Matrix

> **Source basis:** `blueprints/full-history-authoritative-reconstruction/source-material/BLUEPRINT/33_REQUIREMENTS_TRACEABILITY_MATRIX.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

| Requirement | Feature | UI | Module | API | Data | Tests |
| --- | --- | --- | --- | --- | --- | --- |
| REQ-001 | F001 | System | Auth/API/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-002 | F002 | Global | Runtime/Config | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-003 | F003 | Global | Frontend/i18n | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-004 | F004 | Global | Frontend | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-005 | F005 | Market | Frontend/Storage | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-006 | F006 | Market/Scan | Market Data | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-007 | F007 | Market | Market Data/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-008 | F008 | Market/Scan | Market Data | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-009 | F009 | Market | Frontend/Chart | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-010 | F010 | Market | Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-011 | F011 | Market | Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-012 | F012 | Market/Scan | Market Data/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-013 | F013 | Market/Scan | Market Data/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-014 | F014 | Market/Paper | Market Data/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-015 | F015 | Home/Market | Domain/Frontend | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-016 | F016 | Scan | Scanner/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-017 | F017 | Scan | Scanner/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-018 | F018 | Scan | Scheduler/Scanner | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-019 | F019 | Scan/Decisions | Evidence Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-020 | F020 | Decisions | Decision Engine/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-021 | F021 | Decisions | Decision Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-022 | F022 | Decisions | Red Team | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-023 | F023 | AI/Decisions | AI Runtime | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-024 | F024 | Strategies | Strategy Engine/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-025 | F025 | Strategies | Strategy Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-026 | F026 | Strategies | Strategy Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-027 | F027 | Strategies | Strategy Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-028 | F028 | Backtest | Backtest Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-029 | F029 | Replay | Replay Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-030 | F030 | Analytics/Strategies | Analytics | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-031 | F031 | Paper/Decisions | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-032 | F032 | Paper/Decisions | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-033 | F033 | Paper/Decisions | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-034 | F034 | Paper/Decisions | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-035 | F035 | Home/Paper | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-036 | F036 | Paper | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-037 | F037 | Paper | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-038 | F038 | Paper/Risk | Risk Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-039 | F039 | Paper | Paper Engine/API | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-040 | F040 | Paper | Paper Engine/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-041 | F041 | Paper | Paper Engine/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-042 | F042 | Paper | Paper Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-043 | F043 | Journal/Audit | Journal/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-044 | F044 | Paper | Portfolio/Risk | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-045 | F045 | Analytics | Analytics | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-046 | F046 | Analytics | Analytics | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-047 | F047 | Analytics | Analytics | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-048 | F048 | System | Alerts/Scheduler | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-049 | F049 | Home/System | Brief/AI | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-050 | F050 | Home/System/AI | Providers | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-051 | F051 | System | Audit/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-052 | F052 | System | Backup/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-053 | F053 | System | Docs/UI | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-054 | F054 | AI | AI Runtime | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-055 | F055 | AI | Tool Gateway | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-056 | F056 | AI Providers | Provider Gateway | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-057 | F057 | AI Providers | Provider Gateway | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-058 | F058 | AI Providers | Provider Gateway/Security | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-059 | F059 | AI Memory | Memory | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-060 | F060 | AI Memory | Knowledge | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-061 | F061 | AI Skills | Skill Control | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-062 | F062 | AI Skills | Skill Control | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-063 | F063 | AI Traces | Skill Control/Audit | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-064 | F064 | AI Traces | AI Runtime/Audit | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-065 | F065 | AI Traces | Evaluation | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-066 | F066 | AI | Research Adapter | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-067 | F067 | Global | Runtime/Fixtures | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-068 | F068 | System | Runtime/Scripts | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-069 | F069 | System | Runtime/Ops | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-070 | F070 | Audit/System | Export | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-001 | F019 | Scan/Decisions | Evidence Engine | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-002 | F007 | Market | Market Data/Domain | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-003 | F068 | System | Runtime/Scripts | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-004 | F003 | Global | Frontend/i18n | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-005 | F056 | AI Providers | Provider Gateway | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
| REQ-NFR-006 | F051 | System | Audit/DB | See matching domain APIs | See matching domain tables | P0/P1 matching category in TEST_MATRIX |
