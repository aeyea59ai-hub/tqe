# Skill Manager UI

> **Source basis:** `blueprints/skill-control-plane/source-material/skill_control_plane/02_SKILL_MANAGER_UI_SPEC.md`  
> **Document class:** Engineering specification / reference.  
> **Build behavior:** Implement continuously; validate each completed slice; continue with all independent work.

Add:

`AI Trading Desk → Skills`

## Main screen

Summary cards:
- Installed
- Core
- Enabled
- Conditional
- Disabled
- Drafts
- Protected
- Failed Tests

Filters:
- category;
- classification;
- agent;
- activation;
- status;
- hardening tier;
- protected;
- tool binding.

## Skill row

Show:
- name;
- badge: ENGINE / AI / HYBRID / QA / SYSTEM;
- version;
- status;
- agents;
- activation;
- test state;
- protected state.

## Skill detail tabs

### Overview
Purpose, class, category, state, dependencies, consumers.

### Instructions
Published instructions read-only.
`Edit Draft` button creates a new draft.

### Tools & Permissions
Allowed tools and risk class.
Root permissions cannot be expanded by prompt editing.

### Agents
Agent bindings and activation conditions.

### Context
Required context and maximum context budget.

### Tests
Last executed tests, hash, PASS/FAIL/BLOCKED, evidence.

### Impact
Agents/routes/skills/tools affected by publishing this draft.

### History
Versions, hashes, publisher, date, change note.

### Audit
Enable/disable/publish/rollback/configuration events.

## Buttons

Normal skill:
`Create Draft | Test | Publish | Disable | Duplicate | Export | Rollback`

Protected skill:
`View | Test | History`

System policy changes live in a separate owner-only area, not the normal editor.
