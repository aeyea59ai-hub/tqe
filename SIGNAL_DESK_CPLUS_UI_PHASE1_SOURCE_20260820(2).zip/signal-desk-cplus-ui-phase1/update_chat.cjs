const fs = require('fs');
let content = fs.readFileSync('src/lib/aiChatEngine.ts', 'utf8');

content = content.replace(
  /const ai = new GoogleGenAI\(\{[\s\S]*?\}\);/g,
  `import { AIProviderFactory } from './aiProviderGateway';`
);

const callRegex = /const response = await ai\.models\.generateContent\(\{[\s\S]*?\}\);/g;

const newCall = `
    const provider = await AIProviderFactory.getEligibleProvider(false);
    if (!provider) throw new Error("AI_UNAVAILABLE: No eligible AI provider configured.");
    
    // Simplification for gateway: map config options internally if needed.
    const response = await provider.chat(fullPrompt);
`;

content = content.replace(callRegex, newCall);

content = content.replace(/return response\.text \|\| ''/g, 'return response.output_text || \'\'');

fs.writeFileSync('src/lib/aiChatEngine.ts', content);
