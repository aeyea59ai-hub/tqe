const fs = require('fs');
let content = fs.readFileSync('src/lib/aiCouncilEngine.ts', 'utf8');

// Update roles array
content = content.replace(
  "{ id: 'manager', name: 'Manager', role: 'Oversees discussion and extracts final financial decision', allowedStances: ['APPROVED', 'CONDITIONAL', 'REJECTED', 'DATA_UNAVAILABLE'] },",
  "{ id: 'manager', name: 'Manager', role: 'Oversees discussion and extracts final financial decision', allowedStances: ['APPROVED', 'CONDITIONAL', 'REJECTED', 'DATA_UNAVAILABLE'] },\n  { id: 'user-mimic', name: 'User Mimic Agent', role: 'Mimics the user\\'s personal trading style and risk appetite', allowedStances: ['BULLISH', 'BEARISH', 'NEUTRAL'] },"
);

// Update opinions generation fallback
content = content.replace(
  "You MUST output EXACTLY 4 AGENTS in the \\\"opinions\\\" array. Use the specific allowed stances for each agent:",
  "You MUST output EXACTLY 5 AGENTS in the \\\"opinions\\\" array. Use the specific allowed stances for each agent:"
);

content = content.replace(
  "4. Manager (id: \\\"manager\\\"): \\\"APPROVED\\\" | \\\"CONDITIONAL\\\" | \\\"REJECTED\\\" | \\\"DATA_UNAVAILABLE\\\"",
  "4. Manager (id: \\\"manager\\\"): \\\"APPROVED\\\" | \\\"CONDITIONAL\\\" | \\\"REJECTED\\\" | \\\"DATA_UNAVAILABLE\\\"\n5. User Mimic Agent (id: \\\"user-mimic\\\"): \\\"BULLISH\\\" | \\\"BEARISH\\\" | \\\"NEUTRAL\\\""
);

content = content.replace(
  "... (all 4 agents)",
  "... (all 5 agents)"
);

content = content.replace(
  "opinions: AgentOpinion[]; // All 4 agents",
  "opinions: AgentOpinion[]; // All 5 agents"
);

content = content.replace(
  "    {\n      agentId: 'manager',",
  "    {\n      agentId: 'user-mimic',\n      agentName: 'User Mimic Agent',\n      role: 'Mimics the user\\'s personal trading style and risk appetite',\n      stance: isCounterTrend ? 'NEUTRAL' : (direction === 'LONG' ? 'BULLISH' : 'BEARISH'),\n      confidence: 85,\n      keyEvidence: ['Matches historical user trade setups'],\n      objections: [],\n      reasoning: 'This setup aligns perfectly with your historical preference for momentum breakouts.',\n    },\n    {\n      agentId: 'manager',"
);

fs.writeFileSync('src/lib/aiCouncilEngine.ts', content);
