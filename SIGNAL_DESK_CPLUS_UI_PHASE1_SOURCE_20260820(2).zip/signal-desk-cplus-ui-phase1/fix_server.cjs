const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

// Remove the wrongly placed imports
content = content.replace("import { AIProviderGateway } from './src/lib/aiProviderGateway';", "");
content = content.replace("import { db } from './src/lib/db';", "");

// Prepend them to the top of the file
const topImports = `
import { AIProviderGateway } from './src/lib/aiProviderGateway.js';
import { db } from './src/lib/db.js';
`;
content = topImports + content;

fs.writeFileSync('server.ts', content);
