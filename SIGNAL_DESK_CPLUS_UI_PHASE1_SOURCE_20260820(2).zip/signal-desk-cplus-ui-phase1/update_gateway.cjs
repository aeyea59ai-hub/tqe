const fs = require('fs');
const content = fs.readFileSync('src/lib/aiProviderGateway.ts', 'utf8');

const additionalCode = `
import { GeminiAdapter } from './adapters/geminiAdapter';
import { OpenAiCompatibleAdapter } from './adapters/openAiCompatibleAdapter';

export class AIProviderFactory {
  static createAdapter(provider: AIProvider): ProviderAdapter {
    switch (provider.provider_type) {
      case 'GEMINI':
        return new GeminiAdapter(provider);
      case 'OPENAI':
      case 'CUSTOM_OPENAI':
      case 'OLLAMA_LOCAL':
      case 'LLAMACPP_LOCAL':
      case 'OLLAMA_CLOUD':
      case 'KIMI_CLOUD':
      case 'MOCK':
      default:
        return new OpenAiCompatibleAdapter(provider);
    }
  }

  static async getEligibleProvider(privacyRequired: boolean): Promise<ProviderAdapter | null> {
    const providers = AIProviderGateway.getProviders();
    const routingMode = AIProviderGateway.getRoutingMode();
    
    let candidates = providers.filter(p => p.enabled);

    if (routingMode === 'LOCAL_ONLY') {
      candidates = candidates.filter(p => p.privacy_class === 'LOCAL');
    } else if (routingMode === 'CLOUD_ONLY') {
      candidates = candidates.filter(p => p.privacy_class === 'CLOUD');
    } else if (privacyRequired || routingMode === 'PRIVACY_FIRST') {
      const localCandidates = candidates.filter(p => p.privacy_class === 'LOCAL');
      if (localCandidates.length > 0) {
        candidates = localCandidates;
      }
    }

    if (candidates.length === 0) return null;
    
    // Sort by priority
    candidates.sort((a, b) => b.priority - a.priority);

    // Naive selection for now, could be improved with health checks and fallbacks
    return this.createAdapter(candidates[0]);
  }
}
`;

// Prepend imports and append classes
const lines = content.split('\n');
const imports = lines.filter(l => l.startsWith('import '));
const rest = lines.filter(l => !l.startsWith('import ')).join('\n');

const newContent = imports.join('\n') + '\n' + additionalCode + '\n' + rest;
fs.writeFileSync('src/lib/aiProviderGateway.ts', newContent);
