const fs = require('fs');

const strategies = [];
for (let i = 1; i <= 20; i++) {
  const code = `G-${i.toString().padStart(2, '0')}`;
  strategies.push(`  {
    id: 'g${i.toString().padStart(2, '0')}',
    code: '${code}',
    name: 'Custom AI Strategy ${code}',
    category: 'RESEARCH',
    lifecycle: 'RESEARCH_ONLY',
    preferredTimeframe: '15m',
    winRateHistorical: (50 + Math.random() * 20).toFixed(1),
    profitFactorHistorical: (1.5 + Math.random()).toFixed(2),
    description: 'Custom AI generated strategy ${code} for technical analysis.',
    rulesSummary: [
      'Custom Rule 1 for ${code}',
      'Custom Rule 2 for ${code}'
    ],
  },`);
}
console.log(strategies.join('\n'));
