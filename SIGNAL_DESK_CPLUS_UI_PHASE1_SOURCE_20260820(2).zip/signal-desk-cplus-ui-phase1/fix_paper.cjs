const fs = require('fs');
const content = fs.readFileSync('src/lib/paperEngine.ts', 'utf8');

const regex = /export function loadPaperAccount\(\): AccountState \{[\s\S]*?return INITIAL_ACCOUNT_STATE;\n\}/;

const replacement = `export function loadPaperAccount(): AccountState {
  try {
    const data = localStorage.getItem(PAPER_STORAGE_KEY);
    if (data) {
      const parsed = JSON.parse(data);
      if (parsed && typeof parsed === 'object') {
        const state: any = { ...INITIAL_ACCOUNT_STATE };
        for (const key in INITIAL_ACCOUNT_STATE) {
          if (parsed[key] !== undefined && parsed[key] !== null && typeof parsed[key] === typeof (INITIAL_ACCOUNT_STATE as any)[key]) {
            state[key] = parsed[key];
          }
        }
        // Specific backward compatibility fallbacks
        state.equity = parsed.equity ?? parsed.balance ?? INITIAL_ACCOUNT_STATE.equity;
        state.balance = parsed.balance ?? INITIAL_ACCOUNT_STATE.balance;
        state.freeMargin = parsed.freeMargin ?? parsed.availableBalance ?? INITIAL_ACCOUNT_STATE.freeMargin;
        state.totalPnlUsd = parsed.totalPnlUsd ?? INITIAL_ACCOUNT_STATE.totalPnlUsd;
        
        return state as AccountState;
      }
    }
  } catch (err) {
    console.error('Failed to load paper account state from localStorage:', err);
  }
  return INITIAL_ACCOUNT_STATE;
}`;

const newContent = content.replace(regex, replacement);
fs.writeFileSync('src/lib/paperEngine.ts', newContent);
