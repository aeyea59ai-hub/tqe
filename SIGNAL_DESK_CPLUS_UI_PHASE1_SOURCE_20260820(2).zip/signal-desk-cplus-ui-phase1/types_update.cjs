const fs = require('fs');
const content = fs.readFileSync('src/types/index.ts', 'utf8');
const newTypes = `
export type ProviderType = 'OLLAMA_LOCAL' | 'LLAMACPP_LOCAL' | 'OLLAMA_CLOUD' | 'KIMI_CLOUD' | 'OPENAI' | 'GEMINI' | 'ANTHROPIC' | 'CUSTOM_OPENAI' | 'MOCK';
export type RoutingMode = 'AUTO' | 'MANUAL' | 'LOCAL_ONLY' | 'CLOUD_ONLY' | 'PRIVACY_FIRST' | 'QUALITY_FIRST' | 'SPEED_FIRST' | 'COST_FIRST';
export type PrivacyClass = 'LOCAL' | 'CLOUD';
export type ProviderHealth = 'HEALTHY' | 'UNHEALTHY' | 'UNREACHABLE_FROM_CURRENT_RUNTIME' | 'UNKNOWN';

export interface AIProvider {
  id: string;
  provider_type: ProviderType;
  display_name: string;
  enabled: boolean;
  priority: number;
  base_url?: string;
  model: string;
  secret_ref?: string;
  routing_eligibility: string;
  privacy_class: PrivacyClass;
  timeout_seconds: number;
  max_retries: number;
  streaming_enabled: boolean;
  supports_chat: boolean;
  supports_tools: boolean;
  supports_json_schema: boolean;
  supports_vision: boolean;
  supports_embeddings: boolean;
  context_window?: number;
  max_output_tokens?: number;
  health_status: ProviderHealth;
  last_health_check_utc?: string;
  last_error_code?: string;
  last_error_message_redacted?: string;
  average_latency_ms: number;
  created_at_utc: string;
  updated_at_utc: string;
  version: number;
}

export interface AIProviderResponse {
  provider_id: string;
  model: string;
  request_id: string;
  output_text: string;
  structured_output?: any;
  input_tokens?: number;
  output_tokens?: number;
  latency_ms: number;
  finish_reason: string;
  routing_reason: string;
  warnings?: string[];
  provider_error_code?: string;
}
`;
fs.writeFileSync('src/types/index.ts', content + newTypes);
