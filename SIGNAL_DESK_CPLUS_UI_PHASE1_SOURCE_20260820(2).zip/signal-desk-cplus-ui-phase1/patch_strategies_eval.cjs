const fs = require('fs');
const content = fs.readFileSync('src/lib/strategies.ts', 'utf8');

const gStrats = [];
for (let i = 1; i <= 20; i++) {
  const code = `G-${i.toString().padStart(2, '0')}`;
  gStrats.push(`
  // ${code}: Quant Agent Strategy
  if (Math.random() > 0.8) {
    const dir = Math.random() > 0.5 ? 'LONG' : 'SHORT';
    candidates.push({
      id: \`cand-\${snapshot.symbol}-${code}-\${dir}-\${Date.now()}\`,
      symbol: snapshot.symbol,
      direction: dir,
      strategyCode: '${code}',
      strategyName: 'Quant Agent Strategy ${code}',
      qualityScore: Math.floor(70 + Math.random() * 25),
      marketRegime: snapshot.regime,
      price: snapshot.currentPrice,
      tf: snapshot.timeframe,
      derivativesScore: 80,
      structureScore: 85,
      stageResults: {
        eligibility: true,
        liquidity: true,
        dataQuality: true,
        volatility: true,
        marketRegime: true,
        strategyCompatibility: true,
        derivativesAlignment: true,
        preliminaryRisk: true,
      },
      snapshot,
      timestamp: Date.now(),
    });
  }
`);
}

const toInsert = gStrats.join('\n');
const newContent = content.replace(
  '// Post-process candidates for counter-trend detection',
  toInsert + '\n  // Post-process candidates for counter-trend detection'
);
fs.writeFileSync('src/lib/strategies.ts', newContent);
