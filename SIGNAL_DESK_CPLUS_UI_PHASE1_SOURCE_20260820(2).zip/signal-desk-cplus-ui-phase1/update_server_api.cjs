const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

const additionalRoutes = `
import { AIProviderGateway } from './src/lib/aiProviderGateway';
import { db } from './src/lib/db';

app.get('/api/v1/ai/providers', (req, res) => {
  try {
    const providers = AIProviderGateway.getProviders();
    res.json({ success: true, providers });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/v1/ai/providers', (req, res) => {
  try {
    const id = AIProviderGateway.addProvider(req.body);
    res.json({ success: true, id });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.delete('/api/v1/ai/providers/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM ai_providers WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.patch('/api/v1/ai/providers/:id', (req, res) => {
  // Simplified for mvp - in reality, dynamic SQL builder or individual fields
  try {
    const p = req.body;
    db.prepare(\`UPDATE ai_providers SET 
      display_name = ?, enabled = ?, priority = ?, base_url = ?, model = ?,
      secret_ref = ?, privacy_class = ?, timeout_seconds = ?, max_retries = ?, updated_at_utc = ?
      WHERE id = ?\`).run(
      p.display_name, p.enabled ? 1 : 0, p.priority, p.base_url, p.model,
      p.secret_ref, p.privacy_class, p.timeout_seconds, p.max_retries, new Date().toISOString(), req.params.id
    );
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/v1/ai/routing', (req, res) => {
  res.json({ success: true, routing_mode: AIProviderGateway.getRoutingMode() });
});

app.patch('/api/v1/ai/routing', (req, res) => {
  try {
    const mode = req.body.routing_mode;
    db.prepare("UPDATE ai_routing_policy SET routing_mode = ? WHERE id = 'default'").run(mode);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});
`;

// Insert the new routes right before `app.listen`
content = content.replace(/(app\.listen\()/g, additionalRoutes + '\n$1');

fs.writeFileSync('server.ts', content);
