const fs = require('fs');
let content = fs.readFileSync('src/components/QuantAgentsLive.tsx', 'utf8');

content = content.replace(
  "'Simulated Trading Analyst' | 'Risk Control Analyst' | 'Manager'",
  "'Simulated Trading Analyst' | 'Risk Control Analyst' | 'Manager' | 'User Mimic Agent'"
);

content = content.replace(
  "// Simulated Trading Analyst proposes a trade\n      const direction = Math.random() > 0.5 ? 'LONG' : 'SHORT';",
  `// Simulated Trading Analyst or User Mimic Agent proposes a trade
      const direction = Math.random() > 0.5 ? 'LONG' : 'SHORT';
      const isMimic = Math.random() > 0.5;
      const proposingAgent = isMimic ? 'User Mimic Agent' : 'Simulated Trading Analyst';`
);

content = content.replace(
  "addLog(\n        'Simulated Trading Analyst', \n        'Scanned Opportunity', \n        `Found ${direction} setup for ${target.symbol} using ${strategy.code}. Current Price: $${target.lastPrice.toFixed(2)}`,\n        'info'\n      );",
  `addLog(
        proposingAgent, 
        isMimic ? 'User Style Match' : 'Scanned Opportunity', 
        isMimic ? \`Mimicking your historical trading style: Found \${direction} setup for \${target.symbol} using \${strategy.code}.\` : \`Found \${direction} setup for \${target.symbol} using \${strategy.code}. Current Price: $\${target.lastPrice.toFixed(2)}\`,
        'info'
      );`
);

fs.writeFileSync('src/components/QuantAgentsLive.tsx', content);
