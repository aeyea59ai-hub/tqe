const fs = require('fs');
let content = fs.readFileSync('src/components/Header.tsx', 'utf8');

// We need to add the Settings icon to lucide-react import
if (!content.includes('Settings')) {
  content = content.replace('import { Play,', 'import { Play, Settings,');
}

// Find a place to inject the button, e.g., next to the Audit Log button
const auditBtnRegex = /<button\s+onClick=\{\(\) => onNavigateTab\('audit'\)\}[\s\S]*?<\/button>/;

const newBtn = `
          <button
            onClick={() => onNavigateTab('settings')}
            className="p-2 text-slate-400 hover:text-slate-100 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors border border-slate-700 hover:border-slate-600"
            title="AI Providers Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
`;

content = content.replace(auditBtnRegex, (match) => newBtn + '\n' + match);

fs.writeFileSync('src/components/Header.tsx', content);
