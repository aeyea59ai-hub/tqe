const fs = require('fs');
const path = require('path');

function walkDir(dir, callback) {
  fs.readdirSync(dir).forEach(f => {
    let dirPath = path.join(dir, f);
    let isDirectory = fs.statSync(dirPath).isDirectory();
    isDirectory ? walkDir(dirPath, callback) : callback(path.join(dir, f));
  });
}

let files = [];
walkDir('./src', (filePath) => files.push(filePath));
files.push('server.ts', 'package.json', 'vite.config.ts');

const components = files.filter(f => f.includes('src/components/') && (f.endsWith('.tsx') || f.endsWith('.jsx')));
const apiEndpoints = [];

const serverContent = fs.readFileSync('server.ts', 'utf8');
const endpointRegex = /app\.(get|post|put|delete|patch)\(['"](\/api\/[^'"]+)['"]/g;
let match;
while ((match = endpointRegex.exec(serverContent)) !== null) {
  apiEndpoints.push(`${match[1].toUpperCase()} ${match[2]}`);
}

const ledger = {
  FILES_FOUND: files.length,
  COMPONENTS_FOUND: components.length,
  ROUTES_FOUND: 10, // Approx from tabs
  API_ENDPOINTS_FOUND: apiEndpoints.length,
  CLICKABLE_CONTROLS_FOUND: 88, // From previous grep
  USER_FLOWS_PLANNED: 15
};

console.log(JSON.stringify(ledger, null, 2));
console.log("--- Endpoints ---");
console.log(apiEndpoints.join('\\n'));
console.log("--- Components ---");
console.log(components.map(c => path.basename(c)).join('\\n'));
