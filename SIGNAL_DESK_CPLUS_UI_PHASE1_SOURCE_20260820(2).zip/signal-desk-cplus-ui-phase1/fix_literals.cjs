const fs = require('fs');
const files = ['src/lib/adapters/geminiAdapter.ts', 'src/lib/adapters/openAiCompatibleAdapter.ts'];

for (const file of files) {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/\\`/g, '`').replace(/\\\$/g, '$');
  fs.writeFileSync(file, content);
}
