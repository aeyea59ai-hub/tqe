import { describe, it, expect } from 'vitest';
import { evaluateSnapshotStrategies, STRATEGY_DEFINITIONS } from './strategies';
import { CanonicalSnapshot } from '../types';

describe('Strategy Generation & Rules', () => {
  const mockSnapshot: CanonicalSnapshot = {
    snapshotId: 'snap-BTCUSDT-15m-1234567890',
    symbol: 'BTCUSDT',
    timeframe: '15m',
    currentPrice: 50000,
    closedCandles: [],
    derivatives: {
      fundingRate: 0.0001,
      openInterest: 1000000,
      openInterestChangePct: 0.05,
      longShortRatio: 1.5,
      takerBuyRatio: 0.6,
      liquidationsLong: 10000,
      liquidationsShort: 50000,
    },
    orderBook: {
      bestBid: 49999,
      bestAsk: 50001,
      bidDepth: 1000,
      askDepth: 500,
      imbalanceRatio: 2.0,
      spread: 2,
      spreadPct: 0.00004,
    },
    context: {
      btcCorrelation: 1,
      ethCorrelation: 0.9,
      globalVolume24h: 1000000000,
      altcoinDominance: 0.4,
    },
    features: {
      rsi14: 65,
      macdValue: 50,
      macdSignal: 30,
      macdHistogram: 20,
      ema7: 50500,
      ema20: 50200,
      ema50: 49500,
      ema200: 45000,
      atr14: 500,
      atrPercent: 0.01,
      bollingerUpper: 51000,
      bollingerLower: 49000,
      bollingerBandwidth: 0.04,
      volumeRatio: 2.5,
      realizedVolatility: 0.05,
    },
    structure: {
      isTrending: true,
      isCompressing: false,
      swingHighs: [51000],
      swingLows: [49000],
      fvgs: [{ type: 'BULLISH_FVG', priceLevel: 49500, filled: false, size: 200 }],
      breakerBlocks: [{ type: 'BULLISH_BREAKER', priceLevel: 49000, active: true }],
      sweeps: [{ type: 'LOW_SWEEP', priceLevel: 49000, timestamp: 1234560000 }],
      candlePatterns: ['BULLISH_PINBAR'],
      lastBos: { type: 'BULLISH_BOS', priceLevel: 50500, timestamp: 1234560000 },
    },
    regime: 'STRONG_BULL_TREND',
    qualityReport: {
      status: 'HEALTHY',
      score: 100,
      issues: [],
      gapCount: 0,
    },
    providerProvenance: 'test',
    timestamp: 1234567890,
    sha256Hash: 'hash',
  };

  it('does not contain G-01 through G-20 strategies', () => {
    const invalidStrategies = STRATEGY_DEFINITIONS.filter(s => s.code.startsWith('G-'));
    expect(invalidStrategies.length).toBe(0);
  });

  it('generates deterministic candidate IDs without Math.random()', () => {
    const candidates1 = evaluateSnapshotStrategies(mockSnapshot);
    const candidates2 = evaluateSnapshotStrategies(mockSnapshot);
    
    expect(candidates1.length).toBeGreaterThan(0);
    expect(candidates1).toEqual(candidates2);
    
    candidates1.forEach(cand => {
      expect(cand.id).toContain(mockSnapshot.snapshotId);
      expect(cand.id).toContain('-v1');
    });
  });

  it('rejects regime-incompatible strategies (penalizes counter-trend)', () => {
    // Modify to bear trend but keep features bullish
    const bearishSnapshot = { ...mockSnapshot, regime: 'STRONG_BEAR_TREND' as const };
    const candidates = evaluateSnapshotStrategies(bearishSnapshot);
    
    // S01 LONG in bear trend should be heavily penalized
    const s01Long = candidates.find(c => c.strategyCode === 'S01' && c.direction === 'LONG');
    expect(s01Long).toBeDefined();
    expect(s01Long!.qualityScore).toBeLessThanOrEqual(75); // Since max penalty drops it
    expect(s01Long!.isCounterTrend).toBe(true);
  });
});
