const fs = require('fs');
let content = fs.readFileSync('src/lib/aiCouncilEngine.ts', 'utf8');

content = content.replace(
  /const ai = new GoogleGenAI\(\{[\s\S]*?\}\);/g,
  `import { AIProviderFactory } from './aiProviderGateway';`
);

// We find the try/catch block and replace it.
const tryCatchRegex = /let response;\s*try\s*\{[\s\S]*?response = await ai\.models\.generateContent\(\{[\s\S]*?\}\);\s*\}\s*catch\s*\(modelErr\)\s*\{[\s\S]*?response = await ai\.models\.generateContent\(\{[\s\S]*?\}\);\s*\}/g;

const newCall = `
    let response;
    try {
      const provider = await AIProviderFactory.getEligibleProvider(true);
      if (!provider) throw new Error("AI_UNAVAILABLE: No eligible AI provider configured.");
      
      // In the future we will use provider.chat, but for now we format the prompt string from contentsPayload
      const promptStr = typeof contentsPayload === 'string' ? contentsPayload : JSON.stringify(contentsPayload);
      response = await provider.chat(promptStr);
    } catch (modelErr) {
      console.warn('Primary Provider call failed:', modelErr);
      // Fallback is currently unhandled for secondary provider, bubbling up error
      throw modelErr;
    }
`;

content = content.replace(tryCatchRegex, newCall);

content = content.replace(/const responseText = response\.text;/g, 'const responseText = response.output_text;');

fs.writeFileSync('src/lib/aiCouncilEngine.ts', content);
