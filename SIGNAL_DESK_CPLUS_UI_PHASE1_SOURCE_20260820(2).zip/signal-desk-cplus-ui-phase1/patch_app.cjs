const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Add import
content = content.replace("import { DashboardHome } from './components/DashboardHome';", "import { DashboardHome } from './components/DashboardHome';\nimport { SettingsProviders } from './components/SettingsProviders';");

// Add Tab condition
const settingsTab = `
        {/* Tab Settings */}
        {activeTab === 'settings' && (
          <SettingsProviders />
        )}
`;
content = content.replace("{/* Tab 6: Real-Time Agents */}", settingsTab + "\n        {/* Tab 6: Real-Time Agents */}");

fs.writeFileSync('src/App.tsx', content);
